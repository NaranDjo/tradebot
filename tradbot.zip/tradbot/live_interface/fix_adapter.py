"""
FIX protocol adapter v4.0.
Interface for FIX protocol communication with exchanges.
"""

import asyncio
import json
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
import time

# Try to import FIX libraries
try:
    import quickfix as fix
    from quickfix import (
        Message, FieldMap, SessionID, SessionSettings, 
        FileStoreFactory, SocketInitiator, Application
    )
    FIX_AVAILABLE = True
except ImportError:
    FIX_AVAILABLE = False
    print("QuickFIX not available. Install with: pip install quickfix")
    print("Using simulated FIX adapter")


@dataclass
class FIXConfig:
    """FIX protocol configuration."""
    sender_comp_id: str
    target_comp_id: str
    host: str
    port: int
    fix_version: str = "FIX.4.4"
    heartbeat_interval: int = 30
    reset_on_logon: bool = True
    reset_on_logout: bool = False
    reset_on_disconnect: bool = False
    file_store_path: str = "./fix_store"
    ssl_enabled: bool = False
    ssl_cert_path: Optional[str] = None
    ssl_key_path: Optional[str] = None
    
    def to_dict(self) -> Dict:
        """Convert to dictionary for QuickFIX config."""
        return {
            'ConnectionType': 'initiator',
            'ReconnectInterval': 30,
            'SenderCompID': self.sender_comp_id,
            'TargetCompID': self.target_comp_id,
            'SocketConnectHost': self.host,
            'SocketConnectPort': self.port,
            'StartTime': '00:00:00',
            'EndTime': '23:59:59',
            'HeartBtInt': self.heartbeat_interval,
            'ResetOnLogon': 'Y' if self.reset_on_logon else 'N',
            'ResetOnLogout': 'Y' if self.reset_on_logout else 'N',
            'ResetOnDisconnect': 'Y' if self.reset_on_disconnect else 'N',
            'FileStorePath': self.file_store_path,
            'UseDataDictionary': 'Y',
            'DataDictionary': 'spec/FIX44.xml',
            'ValidateFieldsOutOfOrder': 'N',
            'ValidateFieldsHaveValues': 'N',
            'ValidateUserDefinedFields': 'N',
            'SSLEnable': 'Y' if self.ssl_enabled else 'N',
            'SSLServerName': self.host if self.ssl_enabled else '',
            'SSLCertificateFile': self.ssl_cert_path if self.ssl_enabled else '',
            'SSLKeyFile': self.ssl_key_path if self.ssl_enabled else ''
        }


@dataclass
class FIXMessage:
    """FIX message wrapper."""
    msg_type: str  // 'NewOrderSingle', 'ExecutionReport', etc.
    fields: Dict[str, Any]
    timestamp: float = field(default_factory=time.time)
    sequence_number: Optional[int] = None
    
    def to_quickfix(self) -> Optional[Message]:
        """Convert to QuickFIX Message."""
        if not FIX_AVAILABLE:
            return None
        
        msg = Message()
        msg.getHeader().setField(fix.MsgType(self.msg_type))
        
        for tag, value in self.fields.items():
            try:
                tag_int = int(tag) if isinstance(tag, str) and tag.isdigit() else tag
                if isinstance(tag_int, int):
                    if isinstance(value, str):
                        msg.setField(fix.StringField(tag_int, value))
                    elif isinstance(value, int):
                        msg.setField(fix.IntField(tag_int, value))
                    elif isinstance(value, float):
                        msg.setField(fix.DoubleField(tag_int, value))
                    elif isinstance(value, bool):
                        msg.setField(fix.BoolField(tag_int, value))
            except Exception as e:
                logging.warning(f"Failed to set field {tag}: {e}")
        
        return msg
    
    @classmethod
    def from_quickfix(cls, msg: Message) -> 'FIXMessage':
        """Create from QuickFIX Message."""
        fields = {}
        
        for i in range(1, msg.fieldCount() + 1):
            try:
                field = msg.getField(i)
                fields[str(field.getTag())] = field.getValue()
            except:
                pass
        
        msg_type = msg.getHeader().getField(35).getValue() if msg.getHeader().isSetField(35) else "UNKNOWN"
        
        return cls(
            msg_type=msg_type,
            fields=fields,
            timestamp=time.time()
        )


class FIXApplication(Application):
    """QuickFIX Application implementation."""
    
    def __init__(self, adapter: 'FIXAdapter'):
        super().__init__()
        self.adapter = adapter
        self.logged_in = False
    
    def onCreate(self, sessionID):
        """Called when session is created."""
        logging.info(f"FIX session created: {sessionID}")
        self.adapter.on_session_created(sessionID)
    
    def onLogon(self, sessionID):
        """Called when logon is successful."""
        logging.info(f"FIX session logon: {sessionID}")
        self.logged_in = True
        self.adapter.on_logon(sessionID)
    
    def onLogout(self, sessionID):
        """Called when logout occurs."""
        logging.info(f"FIX session logout: {sessionID}")
        self.logged_in = False
        self.adapter.on_logout(sessionID)
    
    def toAdmin(self, message, sessionID):
        """Called before sending admin message."""
        self.adapter.to_admin(message, sessionID)
    
    def fromAdmin(self, message, sessionID):
        """Called on incoming admin message."""
        self.adapter.from_admin(message, sessionID)
    
    def toApp(self, message, sessionID):
        """Called before sending app message."""
        self.adapter.to_app(message, sessionID)
    
    def fromApp(self, message, sessionID):
        """Called on incoming app message."""
        fix_msg = FIXMessage.from_quickfix(message)
        self.adapter.from_app(fix_msg, sessionID)


class FIXAdapter:
    """
    FIX protocol adapter for institutional exchanges.
    
    Supports FIX 4.4 protocol for order entry and execution reporting.
    """
    
    def __init__(self, config: FIXConfig):
        self.config = config
        self.session_id = None
        self.initiator = None
        self.application = FIXApplication(self)
        self.connected = False
        self.sequence_numbers = {}
        
        # Message queues
        self.incoming_queue = asyncio.Queue()
        self.outgoing_queue = asyncio.Queue()
        self.execution_reports = {}
        
        # Callbacks
        self.on_execution_report = None
        self.on_order_reject = None
        self.on_position_update = None
        
        # Statistics
        self.stats = {
            'messages_sent': 0,
            'messages_received': 0,
            'orders_sent': 0,
            'executions_received': 0,
            'rejects_received': 0,
            'last_message_time': None,
            'avg_roundtrip_ms': 0.0
        }
        
        # Start message processor
        self._processor_task = asyncio.create_task(self._process_messages())
    
    def connect(self):
        """Connect to FIX server."""
        if not FIX_AVAILABLE:
            logging.warning("FIX not available, using simulated adapter")
            self.connected = True
            return True
        
        try:
            # Create settings
            settings = SessionSettings()
            dictionary = settings.get()
            
            # Add session settings
            session_id = SessionID(
                self.config.fix_version,
                self.config.sender_comp_id,
                self.config.target_comp_id
            )
            
            session_settings = self.config.to_dict()
            for key, value in session_settings.items():
                dictionary.setString(key, str(value))
            
            # Create store factory
            store_factory = FileStoreFactory(settings)
            
            # Create initiator
            self.initiator = SocketInitiator(
                self.application, 
                store_factory, 
                settings
            )
            
            # Start initiator
            self.initiator.start()
            self.connected = True
            logging.info(f"FIX adapter started for {self.config.target_comp_id}")
            
            return True
        
        except Exception as e:
            logging.error(f"Failed to start FIX adapter: {e}")
            self.connected = False
            return False
    
    def disconnect(self):
        """Disconnect from FIX server."""
        if self.initiator:
            self.initiator.stop()
            self.connected = False
            logging.info("FIX adapter stopped")
    
    async def send_new_order_single(self, order: Dict) -> Optional[str]:
        """
        Send NewOrderSingle message.
        
        Args:
            order: Order details
            
        Returns:
            Order ID (ClOrdID) or None if failed
        """
        # Generate ClOrdID
        cl_ord_id = f"{self.config.sender_comp_id}_{int(time.time() * 1000)}"
        
        # Build FIX message
        fix_msg = self._build_new_order_single(order, cl_ord_id)
        
        if not fix_msg:
            return None
        
        # Send message
        success = await self._send_message(fix_msg)
        
        if success:
            self.stats['orders_sent'] += 1
            return cl_ord_id
        else:
            return None
    
    def _build_new_order_single(self, order: Dict, cl_ord_id: str) -> Optional[FIXMessage]:
        """Build NewOrderSingle FIX message."""
        try:
            # Required fields for NewOrderSingle
            fields = {
                '11': cl_ord_id,  # ClOrdID
                '55': order.get('symbol', ''),  # Symbol
                '54': '1' if order.get('side', '').upper() == 'BUY' else '2',  # Side (1=Buy, 2=Sell)
                '40': self._get_order_type_code(order.get('order_type', 'LIMIT')),  # OrdType
                '38': str(order.get('quantity', 0)),  # OrderQty
                '44': str(order.get('price', 0)) if order.get('price') else '',  # Price
                '59': '0',  # TimeInForce (0=Day)
                '60': datetime.utcnow().strftime('%Y%m%d-%H:%M:%S'),  # TransactTime
            }
            
            # Optional fields
            if order.get('account'):
                fields['1'] = order['account']  # Account
            
            if order.get('time_in_force'):
                fields['59'] = self._get_time_in_force_code(order['time_in_force'])
            
            if order.get('stop_price'):
                fields['99'] = str(order['stop_price'])  # StopPx
            
            # Add exchange-specific fields if needed
            if self.config.target_comp_id == 'BINANCE':
                fields['207'] = 'BNB'  # SecurityExchange for Binance
            
            return FIXMessage(msg_type='D', fields=fields)  // 'D' = NewOrderSingle
        
        except Exception as e:
            logging.error(f"Failed to build NewOrderSingle: {e}")
            return None
    
    async def send_order_cancel_request(self, orig_cl_ord_id: str, 
                                       symbol: str, side: str) -> Optional[str]:
        """
        Send OrderCancelRequest message.
        
        Args:
            orig_cl_ord_id: Original ClOrdID to cancel
            symbol: Symbol
            side: 'BUY' or 'SELL'
            
        Returns:
            New ClOrdID for cancel request
        """
        cl_ord_id = f"CANCEL_{orig_cl_ord_id}_{int(time.time() * 1000)}"
        
        fields = {
            '11': cl_ord_id,  # ClOrdID
            '41': orig_cl_ord_id,  # OrigClOrdID
            '55': symbol,  # Symbol
            '54': '1' if side.upper() == 'BUY' else '2',  # Side
            '60': datetime.utcnow().strftime('%Y%m%d-%H:%M:%S'),  # TransactTime
        }
        
        fix_msg = FIXMessage(msg_type='F', fields=fields)  // 'F' = OrderCancelRequest
        
        success = await self._send_message(fix_msg)
        
        return cl_ord_id if success else None
    
    async def send_order_cancel_replace_request(self, orig_cl_ord_id: str,
                                               new_order: Dict) -> Optional[str]:
        """
        Send OrderCancelReplaceRequest message.
        
        Args:
            orig_cl_ord_id: Original ClOrdID to replace
            new_order: New order details
            
        Returns:
            New ClOrdID for replace request
        """
        cl_ord_id = f"REPLACE_{orig_cl_ord_id}_{int(time.time() * 1000)}"
        
        fields = {
            '11': cl_ord_id,  # ClOrdID
            '41': orig_cl_ord_id,  # OrigClOrdID
            '55': new_order.get('symbol', ''),  # Symbol
            '54': '1' if new_order.get('side', '').upper() == 'BUY' else '2',  # Side
            '38': str(new_order.get('quantity', 0)),  # OrderQty
            '44': str(new_order.get('price', 0)) if new_order.get('price') else '',  # Price
            '60': datetime.utcnow().strftime('%Y%m%d-%H:%M:%S'),  # TransactTime
        }
        
        fix_msg = FIXMessage(msg_type='G', fields=fields)  // 'G' = OrderCancelReplaceRequest
        
        success = await self._send_message(fix_msg)
        
        return cl_ord_id if success else None
    
    async def send_mass_quote(self, quotes: List[Dict]) -> Optional[str]:
        """
        Send MassQuote message (for market making).
        
        Args:
            quotes: List of quote dictionaries
            
        Returns:
            Quote ID or None if failed
        """
        quote_id = f"QUOTE_{int(time.time() * 1000)}"
        
        fields = {
            '131': quote_id,  # QuoteID
            '60': datetime.utcnow().strftime('%Y%m%d-%H:%M:%S'),  # TransactTime
        }
        
        # Add quote entries (simplified)
        for i, quote in enumerate(quotes, 1):
            fields[f' {i}'] = quote.get('symbol', '')  // QuoteEntryID (simplified)
            fields[f' {i}'] = str(quote.get('bid_price', 0))  // BidPx
            fields[f' {i}'] = str(quote.get('bid_size', 0))  // BidSize
            fields[f' {i}'] = str(quote.get('ask_price', 0))  // OfferPx
            fields[f' {i}'] = str(quote.get('ask_size', 0))  // OfferSize
        
        fix_msg = FIXMessage(msg_type='i', fields=fields)  // 'i' = MassQuote
        
        success = await self._send_message(fix_msg)
        
        return quote_id if success else None
    
    async def request_positions(self, account: str) -> bool:
        """
        Send RequestForPositions message.
        
        Args:
            account: Account number
            
        Returns:
            True if request sent successfully
        """
        pos_req_id = f"POSREQ_{int(time.time() * 1000)}"
        
        fields = {
            '710': pos_req_id,  // PosReqID
            '724': '0',  // PosReqType (0=Positions)
            '1': account,  // Account
            '55': '*',  // Symbol (wildcard for all)
            '60': datetime.utcnow().strftime('%Y%m%d-%H:%M:%S'),  // TransactTime
        }
        
        fix_msg = FIXMessage(msg_type='AN', fields=fields)  // 'AN' = RequestForPositions
        
        return await self._send_message(fix_msg)
    
    async def _send_message(self, fix_msg: FIXMessage) -> bool:
        """Send FIX message."""
        if not self.connected:
            logging.warning("Cannot send message: not connected")
            return False
        
        try:
            # Add to outgoing queue
            await self.outgoing_queue.put(fix_msg)
            self.stats['messages_sent'] += 1
            self.stats['last_message_time'] = time.time()
            
            return True
        
        except Exception as e:
            logging.error(f"Failed to send message: {e}")
            return False
    
    async def _process_messages(self):
        """Process incoming and outgoing messages."""
        while True:
            try:
                # Check for outgoing messages
                if not self.outgoing_queue.empty():
                    fix_msg = await self.outgoing_queue.get()
                    
                    if FIX_AVAILABLE and self.initiator:
                        # Send via QuickFIX
                        quickfix_msg = fix_msg.to_quickfix()
                        if quickfix_msg:
                            # Get session ID
                            if not self.session_id:
                                self.session_id = SessionID(
                                    self.config.fix_version,
                                    self.config.sender_comp_id,
                                    self.config.target_comp_id
                                )
                            
                            # Send message
                            fix.Session.sendToTarget(quickfix_msg, self.session_id)
                    
                    else:
                        # Simulate response for testing
                        await self._simulate_response(fix_msg)
                
                # Check for incoming messages
                if not self.incoming_queue.empty():
                    fix_msg = await self.incoming_queue.get()
                    await self._handle_incoming_message(fix_msg)
                
                # Small sleep to prevent busy waiting
                await asyncio.sleep(0.001)
            
            except asyncio.CancelledError:
                break
            except Exception as e:
                logging.error(f"Error in message processor: {e}")
                await asyncio.sleep(1)
    
    async def _simulate_response(self, fix_msg: FIXMessage):
        """Simulate FIX responses for testing."""
        # Simulate exchange response
        msg_type = fix_msg.msg_type
        
        if msg_type == 'D':  // NewOrderSingle
            // Simulate execution report
            cl_ord_id = fix_msg.fields.get('11')
            if cl_ord_id:
                exec_report = FIXMessage(
                    msg_type='8',  // ExecutionReport
                    fields={
                        '37': f"EXEC_{cl_ord_id}",  // OrderID
                        '11': cl_ord_id,  // ClOrdID
                        '17': f"EXECID_{int(time.time() * 1000)}",  // ExecID
                        '150': '0',  // ExecType (0=New)
                        '39': '0',  // OrdStatus (0=New)
                        '55': fix_msg.fields.get('55', ''),  // Symbol
                        '54': fix_msg.fields.get('54', '1'),  // Side
                        '38': fix_msg.fields.get('38', '0'),  // OrderQty
                        '44': fix_msg.fields.get('44', '0'),  // Price
                        '14': '0',  // CumQty (0 for new)
                        '6': '0',  // AvgPx (0 for new)
                        '60': datetime.utcnow().strftime('%Y%m%d-%H:%M:%S'),
                    }
                )
                
                // Queue for processing
                await self.incoming_queue.put(exec_report)
        
        elif msg_type == 'F':  // OrderCancelRequest
            // Simulate cancel response
            cl_ord_id = fix_msg.fields.get('11')
            orig_cl_ord_id = fix_msg.fields.get('41')
            
            if cl_ord_id and orig_cl_ord_id:
                exec_report = FIXMessage(
                    msg_type='8',  // ExecutionReport
                    fields={
                        '37': f"ORDER_{orig_cl_ord_id}",  // OrderID
                        '11': cl_ord_id,  // ClOrdID
                        '41': orig_cl_ord_id,  // OrigClOrdID
                        '17': f"CANCEL_{int(time.time() * 1000)}",  // ExecID
                        '150': '4',  // ExecType (4=Canceled)
                        '39': '4',  // OrdStatus (4=Canceled)
                        '55': fix_msg.fields.get('55', ''),  // Symbol
                        '54': fix_msg.fields.get('54', '1'),  // Side
                        '38': '0',  // OrderQty
                        '44': '0',  // Price
                        '14': '0',  // CumQty
                        '6': '0',  // AvgPx
                        '60': datetime.utcnow().strftime('%Y%m%d-%H:%M:%S'),
                    }
                )
                
                await self.incoming_queue.put(exec_report)
    
    async def _handle_incoming_message(self, fix_msg: FIXMessage):
        """Handle incoming FIX message."""
        self.stats['messages_received'] += 1
        
        msg_type = fix_msg.msg_type
        
        if msg_type == '8':  // ExecutionReport
            await self._handle_execution_report(fix_msg)
        
        elif msg_type == '9':  // OrderCancelReject
            await self._handle_order_cancel_reject(fix_msg)
        
        elif msg_type == 'AP':  // PositionReport
            await self._handle_position_report(fix_msg)
        
        elif msg_type == 'BD':  // News
            await self._handle_news(fix_msg)
        
        elif msg_type == '3':  // Reject
            await self._handle_reject(fix_msg)
        
        else:
            logging.debug(f"Received unhandled FIX message type: {msg_type}")
    
    async def _handle_execution_report(self, fix_msg: FIXMessage):
        """Handle ExecutionReport message."""
        self.stats['executions_received'] += 1
        
        // Extract fields
        exec_type = fix_msg.fields.get('150', '')
        ord_status = fix_msg.fields.get('39', '')
        cl_ord_id = fix_msg.fields.get('11', '')
        exec_id = fix_msg.fields.get('17', '')
        symbol = fix_msg.fields.get('55', '')
        side = 'BUY' if fix_msg.fields.get('54') == '1' else 'SELL'
        order_qty = float(fix_msg.fields.get('38', 0))
        cum_qty = float(fix_msg.fields.get('14', 0))
        avg_px = float(fix_msg.fields.get('6', 0))
        leaves_qty = float(fix_msg.fields.get('151', 0))
        
        // Create execution report
        exec_report = {
            'timestamp': datetime.utcnow().isoformat(),
            'cl_ord_id': cl_ord_id,
            'exec_id': exec_id,
            'exec_type': exec_type,
            'ord_status': ord_status,
            'symbol': symbol,
            'side': side,
            'order_qty': order_qty,
            'cum_qty': cum_qty,
            'avg_px': avg_px,
            'leaves_qty': leaves_qty,
            'raw_message': fix_msg.fields
        }
        
        // Store for later reference
        self.execution_reports[exec_id] = exec_report
        
        // Call callback if set
        if self.on_execution_report:
            await self.on_execution_report(exec_report)
        
        logging.info(f"ExecutionReport: {cl_ord_id} {symbol} {side} "
                    f"{cum_qty}/{order_qty} @ {avg_px} ({ord_status})")
    
    async def _handle_order_cancel_reject(self, fix_msg: FIXMessage):
        """Handle OrderCancelReject message."""
        self.stats['rejects_received'] += 1
        
        cl_ord_id = fix_msg.fields.get('11', '')
        orig_cl_ord_id = fix_msg.fields.get('41', '')
        cxl_rej_response_to = fix_msg.fields.get('434', '')  // 1=OrderCancelRequest, 2=OrderCancelReplaceRequest
        cxl_rej_reason = fix_msg.fields.get('102', '')  // Reject reason code
        
        reject_report = {
            'timestamp': datetime.utcnow().isoformat(),
            'cl_ord_id': cl_ord_id,
            'orig_cl_ord_id': orig_cl_ord_id,
            'response_to': cxl_rej_response_to,
            'reason': cxl_rej_reason,
            'text': fix_msg.fields.get('58', ''),  // Text
            'raw_message': fix_msg.fields
        }
        
        if self.on_order_reject:
            await self.on_order_reject(reject_report)
        
        logging.warning(f"OrderCancelReject: {cl_ord_id} reason={cxl_rej_reason}")
    
    async def _handle_position_report(self, fix_msg: FIXMessage):
        """Handle PositionReport message."""
        pos_maint_rpt_id = fix_msg.fields.get('721', '')
        account = fix_msg.fields.get('1', '')
        symbol = fix_msg.fields.get('55', '')
        long_qty = float(fix_msg.fields.get('704', 0))
        short_qty = float(fix_msg.fields.get('705', 0))
        avg_buy_price = float(fix_msg.fields.get('707', 0))
        avg_sell_price = float(fix_msg.fields.get('708', 0))
        
        position_report = {
            'timestamp': datetime.utcnow().isoformat(),
            'pos_maint_rpt_id': pos_maint_rpt_id,
            'account': account,
            'symbol': symbol,
            'long_qty': long_qty,
            'short_qty': short_qty,
            'net_qty': long_qty - short_qty,
            'avg_buy_price': avg_buy_price,
            'avg_sell_price': avg_sell_price,
            'raw_message': fix_msg.fields
        }
        
        if self.on_position_update:
            await self.on_position_update(position_report)
        
        logging.info(f"PositionReport: {symbol} Net={long_qty - short_qty}")
    
    async def _handle_news(self, fix_msg: FIXMessage):
        """Handle News message."""
        headline = fix_msg.fields.get('148', '')
        text = fix_msg.fields.get('58', '')
        urgency = fix_msg.fields.get('61', '')  // '0'=Normal, '1'=Flash, '2'=Background
        
        news_report = {
            'timestamp': datetime.utcnow().isoformat(),
            'headline': headline,
            'text': text,
            'urgency': urgency,
            'raw_message': fix_msg.fields
        }
        
        logging.info(f"News: {headline[:50]}...")
    
    async def _handle_reject(self, fix_msg: FIXMessage):
        """Handle Reject message."""
        ref_seq_num = fix_msg.fields.get('45', '')
        text = fix_msg.fields.get('58', '')
        session_reject_reason = fix_msg.fields.get('373', '')
        
        reject_report = {
            'timestamp': datetime.utcnow().isoformat(),
            'ref_seq_num': ref_seq_num,
            'text': text,
            'reason': session_reject_reason,
            'raw_message': fix_msg.fields
        }
        
        logging.error(f"Reject: {text} (reason: {session_reject_reason})")
    
    def on_session_created(self, session_id):
        """Called when FIX session is created."""
        self.session_id = session_id
        logging.info(f"FIX session created: {session_id}")
    
    def on_logon(self, session_id):
        """Called when logon is successful."""
        logging.info(f"FIX session logged on: {session_id}")
        self.connected = True
    
    def on_logout(self, session_id):
        """Called when logout occurs."""
        logging.info(f"FIX session logged out: {session_id}")
        self.connected = False
        self.session_id = None
    
    def to_admin(self, message, session_id):
        """Called before sending admin message."""
        // Can modify admin messages here if needed
        pass
    
    def from_admin(self, message, session_id):
        """Called on incoming admin message."""
        // Handle admin messages (Heartbeat, TestRequest, ResendRequest, etc.)
        msg_type = message.getHeader().getField(35).getValue()
        
        if msg_type == '0':  // Heartbeat
            pass
        elif msg_type == '1':  // TestRequest
            pass
        elif msg_type == '2':  // ResendRequest
            pass
        elif msg_type == '5':  // Logout
            pass
        elif msg_type == 'A':  // Logon
            pass
    
    def to_app(self, message, session_id):
        """Called before sending app message."""
        // Can modify application messages here if needed
        pass
    
    def from_app(self, fix_msg: FIXMessage, session_id):
        """Called on incoming app message."""
        // Queue for async processing
        asyncio.create_task(self.incoming_queue.put(fix_msg))
    
    def _get_order_type_code(self, order_type: str) -> str:
        """Get FIX order type code."""
        order_type_map = {
            'MARKET': '1',
            'LIMIT': '2',
            'STOP': '3',
            'STOP_LIMIT': '4',
            'MARKET_ON_CLOSE': '5',
            'WITH_OR_WITHOUT': '6',
            'LIMIT_OR_BETTER': '7',
            'LIMIT_WITH_OR_WITHOUT': '8',
            'ON_BASIS': '9',
            'ON_CLOSE': 'A',
            'LIMIT_ON_CLOSE': 'B',
            'FOREX_MARKET': 'C',
            'PREVIOUSLY_QUOTED': 'D',
            'PREVIOUSLY_INDICATED': 'E',
            'FOREX_LIMIT': 'F',
            'FOREX_SWAP': 'G',
            'FOREX_PREVIOUSLY_QUOTED': 'H',
            'FUNARI': 'I',
            'MARKET_IF_TOUCHED': 'J',
            'MARKET_WITH_LEFTOVER': 'K',
            'PREVIOUS_FUND_VALUATION_POINT': 'L',
            'NEXT_FUND_VALUATION_POINT': 'M',
            'PEGGED': 'P'
        }
        return order_type_map.get(order_type.upper(), '2')  // Default to LIMIT
    
    def _get_time_in_force_code(self, tif: str) -> str:
        """Get FIX time in force code."""
        tif_map = {
            'DAY': '0',
            'GTC': '1',
            'OPG': '2',
            'IOC': '3',
            'FOK': '4',
            'GTX': '5',  // Good Till Crossing
            'GTD': '6',  // Good Till Date
        }
        return tif_map.get(tif.upper(), '0')  // Default to DAY
    
    def get_statistics(self) -> Dict:
        """Get FIX adapter statistics."""
        return {
            **self.stats,
            'connected': self.connected,
            'session_id': str(self.session_id) if self.session_id else None,
            'queue_sizes': {
                'incoming': self.incoming_queue.qsize(),
                'outgoing': self.outgoing_queue.qsize()
            },
            'execution_reports_count': len(self.execution_reports),
            'config': {
                'target_comp_id': self.config.target_comp_id,
                'host': self.config.host,
                'port': self.config.port
            }
        }
    
    async def wait_for_execution_report(self, cl_ord_id: str, 
                                       timeout_seconds: float = 10.0) -> Optional[Dict]:
        """
        Wait for execution report for specific ClOrdID.
        
        Args:
            cl_ord_id: ClOrdID to wait for
            timeout_seconds: Timeout in seconds
            
        Returns:
            Execution report or None if timeout
        """
        start_time = time.time()
        
        while time.time() - start_time < timeout_seconds:
            // Check existing reports
            for exec_id, report in self.execution_reports.items():
                if report['cl_ord_id'] == cl_ord_id:
                    return report
            
            await asyncio.sleep(0.1)
        
        return None