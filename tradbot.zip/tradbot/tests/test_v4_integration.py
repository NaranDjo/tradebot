"""
Integration tests for v4.0 system.
"""

import pytest
import numpy as np
from datetime import datetime, timedelta
import pandas as pd

from core.execution_latency.exchange_latency import ExchangeLatencyModel, ExchangeTier, ProtocolType
from core.execution_latency.network_latency import NetworkTopology
from core.execution_latency.queue_model import VirtualOrderBook, MatchingAlgorithm
from core.adverse_selection.toxicity_model import VPINCalculator
from core.refined_execution.latency_aware_engine import LatencyAwareExecutionEngine, LatencyAwareOrder
from core.refined_execution.clocks import MultiClockSystem
from core.strategy_decay.half_life_model import HalfLifeModel, SignalObservation
from core.simulation.latency_aware_backtest import LatencyAwareBacktest


class TestV4Integration:
    """Integration tests for v4.0 system."""
    
    @pytest.fixture
    def exchange_latency_model(self):
        return ExchangeLatencyModel(
            exchange="binance",
            tier=ExchangeTier.INSTITUTIONAL,
            protocol=ProtocolType.FIX
        )
    
    @pytest.fixture
    def network_topology(self):
        return NetworkTopology("nyc", "sg")
    
    @pytest.fixture
    def order_book(self):
('Degraded', 'degraded')
    ]
    
    results = {}
    
    for scenario_name, scenario_key in scenarios:
        print(f"\n  Running {scenario_name} scenario...")
        
        backtest = LatencyAwareBacktest(
            historical_data=data,
            exchange="binance",
            client_location="nyc",
            exchange_location="sg",
            tier=ExchangeTier.INSTITUTIONAL,
            protocol=ProtocolType.FIX
        )
        
        result = backtest.run_backtest(strategy, latency_scenario=scenario_key)
        results[scenario_name] = result
        
        # Print summary
        metrics = result['metrics']
        print(f"    Total PnL: ${metrics['total_pnl']:.2f}")
        print(f"    Sharpe Ratio: {metrics['sharpe_ratio']:.2f}")
        print(f"    Max Drawdown: {metrics['max_drawdown']:.2%}")
        print(f"    Latency Impact: ${metrics['latency_impact_pnl']:.2f}")
    
    # 4. Generate comprehensive report
    print("\n📈 Generating performance report...")
    generate_report(results)
    
    # 5. Optimization recommendations
    print("\n💡 Optimization Recommendations:")
    for scenario_name, result in results.items():
        if 'recommendations' in result:
            print(f"\n  {scenario_name} scenario:")
            for rec in result['recommendations'][:3]:  # Top 3
                print(f"    • {rec}")
    
    print("\n🎯 v4.0 System execution complete!")


def load_historical_data():
    """Load sample historical data."""
    # In production, load from database or CSV
    dates = pd.date_range(start='2024-01-01', periods=5000, freq='1min')
    data = pd.DataFrame({
        'timestamp': dates,
        'open': 50000 + np.random.randn(5000).cumsum() * 100,
        'high': 50000 + np.random.randn(5000).cumsum() * 100 + 50,
        'low': 50000 + np.random.randn(5000).cumsum() * 100 - 50,
        'close': 50000 + np.random.randn(5000).cumsum() * 100,
        'volume': np.random.randint(100, 10000, 5000)
    })
    return data


class MyTradingStrategy:
    """Example trading strategy."""
    
    def generate_signal(self, data, portfolio):
        """Generate trading signals."""
        if len(data) < 50:
            return None
        
        # Simple RSI strategy
        close_prices = data['close'].values
        
        # Calculate RSI
        delta = np.diff(close_prices)
        gain = np.where(delta > 0, delta, 0)
        loss = np.where(delta < 0, -delta, 0)
        
        avg_gain = np.mean(gain[-14:])
        avg_loss = np.mean(loss[-14:])
        
        if avg_loss == 0:
            rsi = 100
        else:
            rs = avg_gain / avg_loss
            rsi = 100 - (100 / (1 + rs))
        
        # Generate signals
        current_position = portfolio['positions'].get('BTCUSDT', {}).get('size', 0)
        
        if rsi < 30 and current_position <= 0:
            return {
                'action': 'BUY',
                'symbol': 'BTCUSDT',
                'size': 0.1,  # 0.1 BTC
                'order_type': 'MARKET',
                'signal_strength': 30 - rsi  # Stronger signal when further from threshold
            }
        elif rsi > 70 and current_position > 0:
            return {
                'action': 'SELL',
                'symbol': 'BTCUSDT',
                'size': min(0.1, current_position),
                'order_type': 'MARKET',
                'signal_strength': rsi - 70
            }
        
        return None


def generate_report(results):
    """Generate comprehensive performance report."""
    import matplotlib.pyplot as plt
    
    # Compare scenarios
    scenarios = list(results.keys())
    pnl_values = [r['metrics']['total_pnl'] for r in results.values()]
    sharpe_values = [r['metrics']['sharpe_ratio'] for r in results.values()]
    
    # Create comparison chart
    fig, axes = plt.subplots(2, 1, figsize=(12, 8))
    
    # PnL comparison
    axes[0].bar(scenarios, pnl_values, color=['green', 'blue', 'red'])
    axes[0].set_title('Total PnL by Latency Scenario')
    axes[0].set_ylabel('PnL ($)')
    axes[0].
grid(True, alpha=0.3)
    
    # Sharpe ratio comparison
    axes[1].bar(scenarios, sharpe_values, color=['green', 'blue', 'red'])
    axes[1].set_title('Sharpe Ratio by Latency Scenario')
    axes[1].set_ylabel('Sharpe Ratio')
    axes[1].grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('latency_scenario_comparison.png', dpi=150)
    plt.close()
    
    print("  Report saved: latency_scenario_comparison.png")


if __name__ == "__main__":
    main()
