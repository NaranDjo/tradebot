# config/symbols.py
"""
Торговые символы для Bybit (без BTC, ETH, MATIC).
Только дешёвые актуальные альткойны.
"""

BYBIT_CHEAP_ALTS = [
    # Мем-коины и популярные дешёвые альты
    'DOGE/USDT',    # Dogecoin ~$0.15 - высокая ликвидность, мем
    'SHIB/USDT',    # Shiba Inu ~$0.00001 - очень дешёвый, популярный
    'XRP/USDT',     # Ripple ~$0.60 - высокая ликвидность, легальный статус
    'ADA/USDT',     # Cardano ~$0.50 - технологичный, активная разработка
    'TRX/USDT',     # Tron ~$0.10 - дешёвый, высокая активность
    'DOT/USDT',     # Polkadot ~$7.00 - Web3 инфраструктура
    'AVAX/USDT',    # Avalanche ~$35.00 - L1 конкурент
    'LINK/USDT',    # Chainlink ~$15.00 - оракулы, критическая инфраструктура
    'ATOM/USDT',    # Cosmos ~$10.00 - межсетевое взаимодействие
    'ALGO/USDT',    # Algorand ~$0.20 - технологичный, дешёвый
]

# Дополнительные варианты если какие-то недоступны
BACKUP_ALTS = [
    'VET/USDT',     # VeChain ~$0.03 - очень дешёвый, supply chain
    'FIL/USDT',     # Filecoin ~$5.00 - децентрализованное хранение
    'THETA/USDT',   # Theta ~$1.00 - децентрализованное видео
    'XTZ/USDT',     # Tezos ~$1.00 - смарт-контракты
    'EOS/USDT',     # EOS ~$0.80 - дешёвый, когда-то был топом
    'AAVE/USDT',    # Aave ~$100 - DeFi лидер (дороговато)
    'UNI/USDT',     # Uniswap ~$7.00 - DEX лидер
    'SUSHI/USDT',   # SushiSwap ~$1.50 - DeFi, дешёвый
    'CRV/USDT',     # Curve ~$0.60 - stablecoin DEX
    'APE/USDT',     # ApeCoin ~$1.50 - NFT/meta
]

# Символы для ИСКЛЮЧЕНИЯ
EXCLUDED_SYMBOLS = [
    'BTC/USDT',     # Bitcoin - слишком дорогой
    'ETH/USDT',     # Ethereum - слишком дорогой  
    'MATIC/USDT',   # Polygon - исключаем по требованию
    'BNB/USDT',     # Binance Coin - может быть дорогим
    'SOL/USDT',     # Solana - дорогой
    'LTC/USDT',     # Litecoin - не очень актуальный
    'BCH/USDT',     # Bitcoin Cash - неактуальный
    'XMR/USDT',     # Monero - приватность, может быть проблемным
]


def get_affordable_symbols(max_price: float = 10.0, min_volume: float = 100000) -> list:
    """
    Получить список доступных символов по критериям.
    
    Args:
        max_price: Максимальная цена в USDT
        min_volume: Минимальный дневной объём в USDT
        
    Returns:
        Список символов
    """
    # Для простоты возвращаем предопределённый список
    # В реальности можно динамически получать с биржи
    affordable = []
    
    for symbol in BYBIT_CHEAP_ALTS:
        if symbol not in EXCLUDED_SYMBOLS:
            affordable.append(symbol)
    
    # Возвращаем первые 10 подходящих
    return affordable[:10]