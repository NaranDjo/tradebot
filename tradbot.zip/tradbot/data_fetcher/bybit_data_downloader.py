#!/usr/bin/env python3
"""
Script to download Bybit historical data for cheap altcoins (NO BTC/ETH/MATIC).
"""

import asyncio
import argparse
from datetime import datetime
import json
from data_fetcher.bybit_data_downloader import BybitDataDownloader


async def main():
    parser = argparse.ArgumentParser(description='Download Bybit historical data (NO BTC/ETH/MATIC)')
    parser.add_argument('--max-price', type=float, default=10.0,
                       help='Maximum coin price in USDT (default: 10)')
    parser.add_argument('--min-volume', type=float, default=100000,
                       help='Minimum daily volume in USDT (default: 100,000)')
    parser.add_argument('--timeframes', nargs='+', 
                       default=['5m', '15m', '30m', '1h', '4h'],
                       help='Timeframes to download')
    parser.add_argument('--start', default='2022-01-01',
                       help='Start date (YYYY-MM-DD)')
    parser.add_argument('--end', default='2026-02-01',
                       help='End date (YYYY-MM-DD)')
    parser.add_argument('--exclude', nargs='+',
                       default=['BTC/USDT', 'ETH/USDT', 'MATIC/USDT'],
                       help='Symbols to exclude')
    
    args = parser.parse_args()
    
    print("=" * 60)
    print("BYBIT DATA DOWNLOADER - CHEAP ALTCOINS ONLY")
    print("(NO BTC, NO ETH, NO MATIC)")
    print("=" * 60)
    print(f"Period: {args.start} to {args.end}")
    print(f"Timeframes: {args.timeframes}")
    print(f"Max price: ${args.max_price}")
    print(f"Min volume: ${args.min_volume:,.0f}")
    print(f"Excluding: {args.exclude}")
    print("=" * 60)
    
    # Initialize downloader
    downloader = BybitDataDownloader(cache_dir='./data/bybit')
    
    # Get cheap altcoins (excluding BTC/ETH/MATIC)
    print("\n🔍 Finding cheap altcoins...")
    symbols = downloader.get_cheap_altcoins(
        max_price=args.max_price,
        exclude=args.exclude
    )
    
    if not symbols:
        print("❌ No symbols found! Using default list...")
        symbols = [
            'DOGE/USDT', 'SHIB/USDT', 'XRP/USDT', 'ADA/USDT',
            'TRX/USDT', 'DOT/USDT', 'AVAX/USDT', 'LINK/USDT',
            'ATOM/USDT', 'ALGO/USDT'
        ]
    
    print(f"✅ Selected {len(symbols)} symbols:")
    for i, symbol in enumerate(symbols, 1):
        print(f"  {i:2d}. {symbol}")
    
    # Download data
    print(f"\n📥 Downloading data for {len(symbols)} symbols...")
    
    all_data = await downloader.download_multiple_symbols(
        symbols=symbols,
        timeframes=args.timeframes,
        start_date=args.start,
        end_date=args.end
    )
    
    # Generate report
    print("\n" + "=" * 60)
    print("DOWNLOAD COMPLETE - SUMMARY")
    print("=" * 60)
    
    total_candles = 0
    for symbol in symbols:
        print(f"\n{symbol}:")
        for timeframe in args.timeframes:
            if symbol in all_data and timeframe in all_data[symbol]:
                df = all_data[symbol][timeframe]
                candles = len(df)
                total_candles += candles
                if candles > 0:
                    print(f"  {timeframe}: {candles:6d} candles, "
                          f"{df.index[0].date()} to {df.index[-1].date()}")
                else:
                    print(f"  {timeframe}: No data")
    
    print(f"\n📊 Total candles downloaded: {total_candles:,}")
    print(f"📁 Data saved to: ./data/bybit/")
    
    # Save metadata
    metadata = {
        'downloaded_at': datetime.now().isoformat(),
        'symbols': symbols,
        'excluded': args.exclude,
        'timeframes': args.timeframes,
        'start_date': args.start,
        'end_date': args.end,
        'max_price': args.max_price,
        'min_volume': args.min_volume,
        'total_candles': total_candles,
        'data_location': './data/bybit/'
    }
    
    with open('./data/bybit/metadata.json', 'w') as f:
        json.dump(metadata, f, indent=2)
    cache_file = f"data_{symbol}_{start_date}_{end_date}.csv"
if os.path.exists(cache_file):
    df = pd.read_csv(cache_file, parse_dates=['timestamp'])
else:
    # Скачать и сохранить
    df.to_csv(cache_file)

    print(f"\n📝 Metadata saved to: ./data/bybit/metadata.json")
    print("\n✅ Data download complete! Ready for backtesting.")
    
    # Show sample of first symbol
    if symbols and symbols[0] in all_data and '1h' in all_data[symbols[0]]:
        df = all_data[symbols[0]]['1h']
        if not df.empty:
            print(f"\n📈 Sample data for {symbols[0]} (1h):")
            print(f"  First candle: {df.index[0]}, Price: ${df.iloc[0]['close']:.4f}")
            print(f"  Last candle:  {df.index[-1]}, Price: ${df.iloc[-1]['close']:.4f}")
            print(f"  Price change: {((df.iloc[-1]['close'] - df.iloc[0]['close']) / df.iloc[0]['close'] * 100):+.2f}%")


if __name__ == "__main__":
    asyncio.run(main())