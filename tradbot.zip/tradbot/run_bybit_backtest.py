#!/usr/bin/env python3
"""
Main backtest script for cheap altcoins (NO BTC/ETH/MATIC).
"""

import asyncio
import pandas as pd
import numpy as np
from datetime import datetime
import matplotlib.pyplot as plt
import json
import argparse
from pathlib import Path

from data_fetcher.bybit_data_downloader import BybitDataDownloader
from strategies.small_cap_strategy import SmallCapStrategy


class CheapAltsBacktest:
    """Backtest runner for cheap altcoins only."""
    
    def __init__(self, data_dir: str = "./data/bybit"):
        self.data_dir = Path(data_dir)
        self.downloader = BybitDataDownloader(cache_dir=data_dir)
        
        # Конфигурация стратегии для дешёвых альтов
        from strategies.small_cap_strategy import SmallCapStrategyConfig
        
        self.config = SmallCapStrategyConfig(
            initial_capital=100.0,
            max_position_size_pct=0.20,  # 20% на сделку
            max_open_positions=3,        # Макс 3 позиции одновременно
            stop_loss_pct=0.05,          # 5% стоп-лосс
            take_profit_pct=0.12,        # 12% тейк-профит
            rsi_oversold=28.0,           # Более агрессивно для альтов
            rsi_overbought=72.0,
            volume_multiplier=1.8,       # Больше внимания к объёму
            min_order_size=5.0           # Минимум $5 на Bybit
        )
        
        self.strategy = SmallCapStrategy(self.config)
    
    async def run_backtest(self,
                          symbols: list = None,
                          timeframe: str = '1h',
                          start_date: str = '2022-01-01',
                          end_date: str = '2026-02-01',
                          initial_capital: float = 100.0) -> dict:
        """
        Run backtest for cheap altcoins.
        """
        print("=" * 70)
        print("CHEAP ALTCOINS BACKTEST (NO BTC/ETH/MATIC)")
        print("=" * 70)
        
        # Если символы не указаны, получить дешёвые альты
        if symbols is None:
            print("📊 Selecting cheap altcoins...")
            symbols = self.downloader.get_cheap_altcoins(
                max_price=10.0,
                exclude=['BTC/USDT', 'ETH/USDT', 'MATIC/USDT']
            )[:8]  # Берём топ-8 для разнообразия
        
        print(f"💰 Initial capital: ${initial_capital}")
        print(f"📈 Timeframe: {timeframe}")
        print(f"📅 Period: {start_date} to {end_date}")
        print(f"🪙 Trading {len(symbols)} symbols:")
        for i, sym in enumerate(symbols, 1):
            print(f"   {i:2d}. {sym}")
        print("=" * 70)
        
        # Загрузить данные
        all_data = {}
        for symbol in symbols:
            print(f"📥 Loading {symbol}...")
            try:
                df = await self.downloader.download_data(
                    symbol, timeframe, start_date, end_date
                )
                if not df.empty:
                    all_data[symbol] = df
                    print(f"   ✅ {len(df)} candles loaded")
                else:
                    print(f"   ❌ No data for {symbol}")
            except Exception as e:
                print(f"   ❌ Error loading {symbol}: {e}")
        
        if not all_data:
            print("❌ No data loaded!")
            return {}
        
        # Основной цикл бэктеста
        print(f"\n🚀 Running backtest...")
        
        # Получить все таймстемпы
        all_timestamps = set()
        for df in all_data.values():
            all_timestamps.update(df.index)
        
        all_timestamps = sorted(all_timestamps)
        print(f"   Total timesteps: {len(all_timestamps)}")
        
        # История портфеля
        portfolio_history = []
        current_cash = initial_capital
        positions = {}
        
        for i, timestamp in enumerate(all_timestamps):
            if i % 1000 == 0:
                progress = (i / len(all_timestamps)) * 100
                print(f"   Progress: {i:6d}/{len(all_timestamps)} ({progress:5.1f}%)")
            
            # Текущие цены
            current_prices = {}
            for symbol, df in all_data.items():
                if timestamp in df.index:
                    current_prices[symbol] = df.loc[timestamp, 'close']
            
            # Проверить стоп-лоссы
            self.strategy.check_stop_losses(current_prices)
            
            # Сгенерировать сигналы и исполнить сделки
            for symbol in all_data.keys():
                if symbol in current_prices:
                    # Данные до текущего момента
                    df = all_data[symbol]
                    df_up_to_now = df[df.index <= timestamp]
                    
                    if len(df_up_to_now) < 50:
                        continue
                    
                    # Сигнал
                    signal = self.strategy.calculate_signals(df_up_to_now, symbol)
                    
                    # Текущая стоимость портфеля
                    portfolio_value = current_cash
                    for pos_symbol, pos in positions.items():
                        if pos_symbol in current_prices:
                            portfolio_value += pos['size'] * current_prices[pos_symbol]
                    
                    # Исполнить сделку
                    trade = self.strategy.execute_trade(signal, portfolio_value)
                    
                    if trade:
                        # Обновить портфель
                        if trade['action'] == 'BUY':
                            if current_cash >= trade['size_usd']:
                                current_cash -= trade['size_usd']
                                positions[symbol] = {
                                    'size': trade['size_usd'] / trade['price'],
                                    'entry_price': trade['price'],
                                    'size_usd': trade['size_usd']
                                }
                        
                        elif trade['action'] == 'SELL':
                            if symbol in positions:
                                position = positions.pop(symbol)
                                pnl = position['size'] * (trade['price'] - position['entry_price'])
                                current_cash += position['size_usd'] + pnl
            
            # Рассчитать общую стоимость
            total_value = current_cash
            for symbol, position in positions.items():
                if symbol in current_prices:
                    total_value += position['size'] * current_prices[symbol]
            
            # Записать историю
            portfolio_history.append({
                'timestamp': timestamp,
                'total_value': total_value,
                'cash': current_cash,
                'positions_value': total_value - current_cash,
                'n_positions': len(positions)
            })
        
        # Генерация результатов
        results = self._generate_results(portfolio_history, all_timestamps)
        
        print(f"\n{'='*70}")
        print("BACKTEST COMPLETE 📊")
        print(f"{'='*70}")
        print(f"Initial capital:   ${initial_capital:10.2f}")
        print(f"Final portfolio:   ${results['final_value']:10.2f}")
        print(f"Total return:      {results['total_return_pct']:10.2f}%")
        print(f"Max drawdown:      {results['max_drawdown_pct']:10.2f}%")
        print(f"Sharpe ratio:      {results['sharpe_ratio']:10.2f}")
        print(f"Total trades:      {results['total_trades']:10d}")
        print(f"Win rate:          {results['win_rate']:10.1f}%")
        print(f"Profit factor:     {results['profit_factor']:10.2f}")
        print(f"{'='*70}")
        
        return results
    
    def _generate_results(self, portfolio_history, timestamps):
        """Генерация результатов бэктеста."""
        if not portfolio_history:
            return {}
        
        df = pd.DataFrame(portfolio_history)
        df.set_index('timestamp', inplace=True)
        
        # Базовая статистика
        initial = df['total_value'].iloc[0]
        final = df['total_value'].iloc[-1]
        total_return = (final - initial) / initial * 100
        
        # Максимальная просадка
        rolling_max = df['total_value'].cummax()
        drawdown = (df['total_value'] - rolling_max) / rolling_max * 100
        max_dd = drawdown.min()
        
        # Sharpe ratio
        returns = df['total_value'].pct_change().dropna()
        if len(returns) > 1 and returns.std() > 0:
            # Предполагаем часовые данные
            sharpe = (returns.mean() / returns.std()) * np.sqrt(365 * 24)
        else:
            sharpe = 0.0
        
        # Статистика сделок
        trades = self.strategy.trade_history
        total_trades = len(trades)
        
        if total_trades > 0:
            winning = [t for t in trades if t.get('pnl', 0) > 0]
            losing = [t for t in trades if t.get('pnl', 0) < 0]
            
            win_rate = len(winning) / total_trades * 100
            avg_win = np.mean([t.get('pnl_pct', 0) for t in winning]) * 100 if winning else 0
            avg_loss = np.mean([t.get('pnl_pct', 0) for t in losing]) * 100 if losing else 0
            
            total_win = sum(t.get('pnl', 0) for t in winning)
            total_loss = abs(sum(t.get('pnl', 0) for t in losing))
            
            profit_factor = total_win / total_loss if total_loss > 0 else float('inf')
        else:
            win_rate = avg_win = avg_loss = profit_factor = 0.0
        
        return {
            'portfolio_history': df,
            'trade_history': trades,
            'initial_value': initial,
            'final_value': final,
            'total_return_pct': total_return,
            'max_drawdown_pct': max_dd,
            'sharpe_ratio': sharpe,
            'total_trades': total_trades,
            'win_rate': win_rate,
            'avg_win_pct': avg_win,
            'avg_loss_pct': avg_loss,
            'profit_factor': profit_factor,
            'config': self.config
        }
    
    def plot_results(self, results: dict, save_path: str = None):
        """Построение графиков результатов."""
        if not results:
            return
        
        df = results['portfolio_history']
        
        fig, axes = plt.subplots(2, 2, figsize=(14, 10))
        
        # 1. Стоимость портфеля
        ax1 = axes[0, 0]
        ax1.plot(df.index, df['total_value'], 'b-', linewidth=2, label='Portfolio')
        ax1.axhline(y=results['initial_value'], color='r', linestyle='--', 
                   label=f'Initial (${results["initial_value"]:.0f})')
        ax1.set_title(f'Portfolio Value - Final: ${results["final_value"]:.2f} '
                     f'({results["total_return_pct"]:.1f}%)', fontsize=12)
        ax1.set_ylabel('USD ($)', fontsize=10)
        ax1.legend()
        ax1.grid(True, alpha=0.3)
        
        # 2. Просадка
        ax2 = axes[0, 1]
        rolling_max = df['total_value'].cummax()
        drawdown = (df['total_value'] - rolling_max) / rolling_max * 100
        ax2.fill_between(df.index, drawdown, 0, color='red', alpha=0.3)
        ax2.plot(df.index, drawdown, 'r-', linewidth=1)
        ax2.set_title(f'Drawdown - Max: {results["max_drawdown_pct"]:.1f}%', fontsize=12)
        ax2.set_ylabel('Drawdown (%)', fontsize=10)
        ax2.grid(True, alpha=0.3)
        
        # 3. Распределение сделок
        ax3 = axes[1, 0]
        if results['total_trades'] > 0:
            trade_returns = [t.get('pnl_pct', 0) * 100 for t in results['trade_history'] 
                           if 'pnl_pct' in t]
            ax3.hist(trade_returns, bins=30, alpha=0.7, color='green', edgecolor='black')
            ax3.axvline(x=0, color='black', linestyle='--', linewidth=1)
            ax3.set_title(f'Trade Returns (Win Rate: {results["win_rate"]:.1f}%)', fontsize=12)
            ax3.set_xlabel('Return (%)', fontsize=10)
            ax3.set_ylabel('Frequency', fontsize=10)
            ax3.grid(True, alpha=0.3)
        
        # 4. Ежемесячная доходность
        ax4 = axes[1, 1]
        monthly = df['total_value'].resample('ME').last().pct_change() * 100
        colors = ['green' if x > 0 else 'red' for x in monthly]
        ax4.bar(monthly.index.strftime('%Y-%m'), monthly, color=colors, alpha=0.7)
        ax4.set_title('Monthly Returns', fontsize=12)
        ax4.set_xlabel('Month', fontsize=10)
        ax4.set_ylabel('Return (%)', fontsize=10)
        ax4.tick_params(axis='x', rotation=45)
        ax4.grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
            print(f"📊 Plot saved to {save_path}")
        
        plt.show()
    
    def save_results(self, results: dict, output_dir: str = "./results"):
        """Сохранение результатов."""
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Сохранить историю портфеля
        portfolio_file = output_path / f"portfolio_{timestamp}.csv"
        results['portfolio_history'].to_csv(portfolio_file)
        
        # Сохранить историю сделок
        trades_file = output_path / f"trades_{timestamp}.csv"
        if results['trade_history']:
            trades_df = pd.DataFrame(results['trade_history'])
            trades_df.to_csv(trades_file, index=False)
        
        # Сохранить сводку
        summary = {
            'timestamp': timestamp,
            'initial_capital': results['initial_value'],
            'final_value': results['final_value'],
            'total_return_pct': results['total_return_pct'],
            'max_drawdown_pct': results['max_drawdown_pct'],
            'sharpe_ratio': results['sharpe_ratio'],
            'total_trades': results['total_trades'],
            'win_rate': results['win_rate'],
            'avg_win_pct': results['avg_win_pct'],
            'avg_loss_pct': results['avg_loss_pct'],
            'profit_factor': results['profit_factor'],
            'strategy_config': vars(results.get('config', {}))
        }
        
        summary_file = output_path / f"summary_{timestamp}.json"
        with open(summary_file, 'w') as f:
            json.dump(summary, f, indent=2)
        
        print(f"\n💾 Results saved to {output_path}/")
        print(f"   📈 Portfolio: {portfolio_file.name}")
        print(f"   📊 Trades: {trades_file.name}")
        print(f"   📋 Summary: {summary_file.name}")
        
        return summary


async def main():
    """Основная функция."""
    parser = argparse.ArgumentParser(
        description='Backtest cheap altcoins strategy (NO BTC/ETH/MATIC)'
    )
    parser.add_argument('--capital', type=float, default=100.0,
                       help='Initial capital in USD (default: 100)')
    parser.add_argument('--timeframe', default='1h',
                       choices=['5m', '15m', '30m', '1h', '4h'],
                       help='Trading timeframe (default: 1h)')
    parser.add_argument('--start', default='2022-01-01',
                       help='Start date (YYYY-MM-DD)')
    parser.add_argument('--end', default='2026-02-01',
                       help='End date (YYYY-MM-DD)')
    parser.add_argument('--symbols', nargs='+',
                       help='Specific symbols to trade (default: auto-select)')
    parser.add_argument('--max-price', type=float, default=10.0,
                       help='Maximum coin price (default: 10)')
    parser.add_argument('--plot', action='store_true',
                       help='Show results plot')
    parser.add_argument('--save', action='store_true',
                       help='Save results to files')
    parser.add_argument('--download-only', action='store_true',
                       help='Only download data, no backtest')
    
    args = parser.parse_args()
    
    runner = CheapAltsBacktest()
    
    if args.download_only:
        # Только загрузка данных
        from data_fetcher.bybit_data_downloader import BybitDataDownloader
        downloader = BybitDataDownloader()
        
        symbols = downloader.get_cheap_altcoins(
            max_price=args.max_price,
            exclude=['BTC/USDT', 'ETH/USDT', 'MATIC/USDT']
        )[:8]
        
        print(f"Downloading data for {len(symbols)} symbols...")
        await downloader.download_multiple_symbols(
            symbols=symbols,
            timeframes=[args.timeframe],
            start_date=args.start,
            end_date=args.end
        )
        
        print("✅ Data download complete!")
        return
    
    # Запуск бэктеста
    results = await runner.run_backtest(
        symbols=args.symbols,
        timeframe=args.timeframe,
        start_date=args.start,
        end_date=args.end,
        initial_capital=args.capital
    )
    
    # Визуализация
    if args.plot and results:
        runner.plot_results(results, save_path='./results/backtest_plot.png')
    
    # Сохранение
    if args.save and results:
        runner.save_results(results)
    
    return results


if __name__ == "__main__":
    asyncio.run(main())