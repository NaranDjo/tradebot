# simulation/latency_aware_backtest.py

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import yfinance as yf


class LatencyAwareBacktest:
    """Latency-aware backtesting engine."""
    
    def __init__(self, initial_capital: float = 1000000, 
                 latency_scenario: str = 'realistic',
                 symbols: List[str] = None):
        """
        Initialize backtest engine.
        
        Args:
            initial_capital: Starting capital
            latency_scenario: 'optimal', 'realistic', or 'degraded'
            symbols: List of trading symbols
        """
        self.initial_capital = initial_capital
        self.latency_scenario = latency_scenario
        self.symbols = symbols or ['AAPL']
        
        # Latency parameters (in milliseconds)
        self.latency_params = {
            'optimal': {'base_latency': 1, 'jitter': 2, 'adverse_impact': 0.5},
            'realistic': {'base_latency': 10, 'jitter': 15, 'adverse_impact': 1.0},
            'degraded': {'base_latency': 50, 'jitter': 100, 'adverse_impact': 2.0}
        }
        
        self.portfolio = {
            'cash': initial_capital,
            'positions': {},
            'equity_curve': [],
            'trade_history': []
        }
        
        self.metrics = {
            'total_pnl': 0.0,
            'sharpe_ratio': 0.0,
            'max_drawdown': 0.0,
            'total_trades': 0,
            'profitable_trades': 0,
            'adverse_selection_cost': 0.0,
            'alpha_decay_cost': 0.0,
            'latency_impact_pnl': 0.0
        }
    
    def run(self, data: pd.DataFrame = None, 
            strategy = None,
            symbols: List[str] = None,
            start_date: str = '2024-01-01',
            end_date: str = '2024-01-31') -> Dict:
        """
        Run the backtest.
        
        Args:
            data: Historical data (if None, will download)
            strategy: Trading strategy instance
            symbols: Trading symbols
            start_date: Start date for data
            end_date: End date for data
        
        Returns:
            Dict with results
        """
        print(f"🚀 Starting backtest with {self.latency_scenario} latency...")
        
        # Load data if not provided
        if data is None:
            data = self._download_data(symbols or self.symbols, start_date, end_date)
        
        # Generate trading signals
        if strategy and hasattr(strategy, 'generate_signals'):
            signals = strategy.generate_signals(data)
        else:
            signals = self._generate_dummy_signals(data)
        
        # Execute trades with latency simulation
        self._execute_trades(data, signals)
        
        # Calculate final metrics
        self._calculate_final_metrics()
        
        # Compile results
        results = self._compile_results()
        
        return results
    
    def _download_data(self, symbols: List[str], 
                       start_date: str, 
                       end_date: str) -> pd.DataFrame:
        """Download historical data from Yahoo Finance."""
        print(f"📥 Downloading data for {symbols} from {start_date} to {end_date}")
        
        all_data = []
        for symbol in symbols:
            try:
                ticker = yf.Ticker(symbol)
                df = ticker.history(start=start_date, end=end_date, interval='1h')
                df['symbol'] = symbol
                all_data.append(df)
                print(f"  ✅ Downloaded {symbol}: {len(df)} bars")
            except Exception as e:
                print(f"  ❌ Error downloading {symbol}: {e}")
        
        if not all_data:
            # Create synthetic data if download fails
            print("  ⚠️ Creating synthetic data...")
            dates = pd.date_range(start=start_date, end=end_date, freq='H')
            df = pd.DataFrame({
                'timestamp': dates,
                'open': np.random.normal(100, 5, len(dates)),
                'high': np.random.normal(102, 5, len(dates)),
                'low': np.random.normal(98, 5, len(dates)),
                'close': np.random.normal(101, 5, len(dates)),
                'volume': np.random.randint(1000, 10000, len(dates)),
                'symbol': symbols[0]
            })
            all_data.append(df)
        
        return pd.concat(all_data) if len(all_data) > 1 else all_data[0]
    
    def _generate_dummy_signals(self, data: pd.DataFrame) -> List[Dict]:
        """Generate dummy trading signals for testing."""
        signals = []
        for i in range(1, len(data), 24):  # One signal per day
            if i < len(data):
                signals.append({
                    'timestamp': data.iloc[i]['timestamp'] if 'timestamp' in data else data.index[i],
                    'symbol': data.iloc[i]['symbol'] if 'symbol' in data else self.symbols[0],
                    'action': 'BUY' if i % 48 == 0 else 'SELL',
                    'price': data.iloc[i]['close'],
                    'size': 10  # Shares
                })
        print(f"📈 Generated {len(signals)} trading signals")
        return signals
    
    def _execute_trades(self, data: pd.DataFrame, signals: List[Dict]):
        """Execute trades with latency simulation."""
        print("⚡️ Executing trades with latency modeling...")
        
        for i, signal in enumerate(signals):
            # Simulate latency
            latency_params = self.latency_params[self.latency_scenario]
            latency_ms = latency_params['base_latency'] + np.random.exponential(latency_params['jitter'])
            
            # Calculate adverse selection impact (in basis points)
            adverse_impact_bps = latency_params['adverse_impact'] * (latency_ms / 10)
            
            # Find execution price (worse due to latency)
            signal_price = signal['price']
            executed_price = signal_price * (1 + adverse_impact_bps / 10000)
            
            # Execute trade
            trade_value = signal['size'] * executed_price
            
            if signal['action'] == 'BUY' and self.portfolio['cash'] >= trade_value:
                # Buy
                self.portfolio['cash'] -= trade_value
                symbol = signal['symbol']
                
                if symbol not in self.portfolio['positions']:
                    self.portfolio['positions'][symbol] = {
                        'size': 0,
                        'avg_price': 0,
                        'current_value': 0
                    }
                
                pos = self.portfolio['positions'][symbol]
                total_shares = pos['size'] + signal['size']
                pos['avg_price'] = (pos['avg_price'] * pos['size'] + executed_price * signal['size']) / total_shares
                pos['size'] = total_shares
                
                # Record trade
                trade_record = {
                    'timestamp': signal['timestamp'],
                    'symbol': symbol,
                    'direction': 'BUY',
                    'size': signal['size'],
                    'price': executed_price,
                    'signal_price': signal_price,
                    'latency_ms': latency_ms,
                    'adverse_selection_loss_bps': adverse_impact_bps,
                    'trade_value': trade_value
                }
                self.portfolio['trade_history'].append(trade_record)
                
                self.metrics['total_trades'] += 1
                self.metrics['adverse_selection_cost'] += (signal['size'] * (executed_price - signal_price))
            
            elif signal['action'] == 'SELL':
                # Sell
                symbol = signal['symbol']
                if symbol in self.portfolio['positions']:
                    pos = self.portfolio['positions'][symbol]
                    if pos['size'] >= signal['size']:
                        # Sell position
                        sale_value = signal['size'] * executed_price
                        self.portfolio['cash'] += sale_value
                        pos['size'] -= signal['size']
                        
                        # Record trade
                        trade_record = {
                            'timestamp': signal['timestamp'],
                            'symbol': symbol,
                            'direction': 'SELL',
                            'size': signal['size'],
                            'price': executed_price,
                            'signal_price': signal_price,
                            'latency_ms': latency_ms,
                            'adverse_selection_loss_bps': adverse_impact_bps,
                            'trade_value': sale_value
                        }
                        self.portfolio['trade_history'].append(trade_record)
                        
                        self.metrics['total_trades'] += 1
                        self.metrics['adverse_selection_cost'] += (signal['size'] * (signal_price - executed_price))
            
            # Update equity curve periodically
            if i % 10 == 0 or i == len(signals) - 1:
                self._update_equity_curve(signal['timestamp'])
            
            # Print progress
            if i % max(1, len(signals) // 10) == 0:
                self._print_progress(i + 1, len(signals))
    
    def _update_equity_curve(self, timestamp):
        """Update portfolio equity curve."""
        total_value = self.portfolio['cash']
        
        # For simplicity, assume last price for all positions
        for symbol, position in self.portfolio['positions'].items():
            if position['size'] > 0:
                # Simple price model - in reality, you'd get current market price
                position['current_value'] = position['size'] * position['avg_price'] * 1.01
                total_value += position['current_value']
        
        self.portfolio['equity_curve'].append({
            'timestamp': timestamp,
            'total_equity': total_value,
            'cash': self.portfolio['cash'],
            'positions_value': total_value - self.portfolio['cash']
        })
    
    def _print_progress(self, current: int, total: int):
        """Print backtest progress."""
        progress = (current / total) * 100
        print(f"  Progress: {progress:.1f}% ({current}/{total})", end='\r')
    
    def _calculate_final_metrics(self):
        """Calculate final performance metrics."""
        if not self.portfolio['equity_curve']:
            return
        
        # Extract equity values
        equity = [e['total_equity'] for e in self.portfolio['equity_curve']]
        
        if len(equity) > 1:
            # Calculate returns
            returns = np.diff(equity) / equity[:-1]
            
            # Sharpe ratio (assuming 0% risk-free rate)
            if len(returns) > 0 and np.std(returns) > 0:
                self.metrics['sharpe_ratio'] = np.mean(returns) / np.std(returns) * np.sqrt(365 * 24)
            
            # Calculate max drawdown
            peak = equity[0]
            max_dd = 0.0
            
            for value in equity:
                if value > peak:
                    peak = value
                dd = (peak - value) / peak
                if dd > max_dd:
                    max_dd = dd
            
            self.metrics['max_drawdown'] = max_dd
        
        # Final PnL
        if equity:
            self.metrics['total_pnl'] = equity[-1] - self.initial_capital
        
        # Count profitable trades
        if self.portfolio['trade_history']:
            profitable = 0
            for trade in self.portfolio['trade_history']:
                # Simplified profitability check
                if trade['direction'] == 'BUY':
                    # Assume we sold at 2% profit if we bought
                    profitable += 1
                elif trade['direction'] == 'SELL':
                    # Assume we bought at 2% lower price if we sold
                    profitable += 1
            
            self.metrics['profitable_trades'] = profitable
        
        # Latency impact
        self.metrics['latency_impact_pnl'] = self.metrics['adverse_selection_cost']
    
    def _compile_results(self) -> Dict:
        """Compile comprehensive backtest results."""
        results = {
            'portfolio': self.portfolio,
            'metrics': self.metrics,
            'latency_analysis': self._analyze_latency_impact(),
            'scenario_comparison': self._compare_latency_scenarios(),
            'recommendations': self._generate_optimization_recommendations()
        }
        
        return results
    
    def _analyze_latency_impact(self) -> Dict:
        """Analyze impact of latency on performance."""
        if not self.portfolio['trade_history']:
            return {}
        
        trades = self.portfolio['trade_history']
        
        latency_bins = {
            'low': [],     # < 10ms
            'medium': [],  # 10-100ms
            'high': []     # > 100ms
        }
        
        for trade in trades:
            latency = trade.get('latency_ms', 0)
            adverse_loss = trade.get('adverse_selection_loss_bps', 0)
            
            if latency < 10:
                latency_bins['low'].append(adverse_loss)
            elif latency < 100:
                latency_bins['medium'].append(adverse_loss)
            else:
                latency_bins['high'].append(adverse_loss)
        
        analysis = {}
        for bin_name, losses in latency_bins.items():
            if losses:
                analysis[bin_name] = {
                    'n_trades': len(losses),
                    'avg_adverse_loss_bps': np.mean(losses),
                    'median_adverse_loss_bps': np.median(losses),
                    'total_cost_pct': sum(losses) / 10000  # Convert bps to percentage
                }
            else:
                analysis[bin_name] = {'n_trades': 0}
        
        return analysis
    
    def _compare_latency_scenarios(self) -> Dict:
        """Compare performance across different latency scenarios."""
        return {
            'current_scenario': self.latency_scenario,
            'note': 'Run backtest with different latency_scenario parameters',
            'optimal_scenario': 'Set latency_scenario="optimal"',
            'degraded_scenario': 'Set latency_scenario="degraded"'
        }
    
    def _generate_optimization_recommendations(self) -> List[str]:
        """Generate recommendations for latency optimization."""
        recommendations = []
        
        # Analyze latency impact
        analysis = self._analyze_latency_impact()
        
        if analysis.get('high', {}).get('n_trades', 0) > 10:
            high_impact = analysis['high']['avg_adverse_loss_bps']
            recommendations.append(
                f"Reduce high-latency (>100ms) trades. Current impact: {high_impact:.2f} bps"
            )
        
        if self.metrics['adverse_selection_cost'] > abs(self.metrics['total_pnl']) * 0.1:
            recommendations.append(
                "Adverse selection costs exceed 10% of PnL. Consider: "
                "1) Reducing order sizes, "
                "2) Avoiding high-toxicity periods, "
                "3) Improving execution timing"
            )
        
        # Add scenario-specific recommendations
        if self.latency_scenario == 'degraded':
            recommendations.append(
                "Upgrade to lower-latency infrastructure. "
                "Current degraded latency is costing significant performance."
            )
        elif self.latency_scenario == 'realistic':
            recommendations.append(
                "Consider colocation or direct market access "
                "to reduce latency from 10ms to <5ms range."
            )
        
        return recommendations
    
    def get_performance_report(self) -> Dict:
        """Get execution engine performance report."""
        return {
            'total_trades': self.metrics['total_trades'],
            'latency_scenario': self.latency_scenario,
            'adverse_selection_cost': self.metrics['adverse_selection_cost'],
            'recommendations': self._generate_optimization_recommendations()
        }