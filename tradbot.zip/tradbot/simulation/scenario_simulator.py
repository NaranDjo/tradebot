"""
Scenario simulation engine v4.0.
Simulates different market scenarios for stress testing.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, field
from datetime import datetime, timedelta
import asyncio
from enum import Enum
import warnings
warnings.filterwarnings('ignore')


class ScenarioType(Enum):
    """Types of market scenarios."""
    NORMAL = "normal"  # Normal market conditions
    HIGH_VOLATILITY = "high_volatility"
    FLASH_CRASH = "flash_crash"
    LIQUIDITY_CRISIS = "liquidity_crisis"
    NEWS_EVENT = "news_event"
    ORDER_FLOW_IMBALANCE = "order_flow_imbalance"
    CIRCUIT_BREAKER = "circuit_breaker"
    EXCHANGE_OUTAGE = "exchange_outage"
    NETWORK_LATENCY_SPIKE = "network_latency_spike"
    ADVERSE_SELECTION = "adverse_selection"


@dataclass
class ScenarioParameters:
    """Parameters for scenario simulation."""
    scenario_type: ScenarioType
    duration_minutes: float = 60.0
    severity: float = 1.0  # 1.0 = normal severity, >1.0 = more severe
    
    # Market parameters
    base_volatility: float = 0.02  # 2% daily volatility
    base_spread_bps: float = 2.0  # 2 bps spread
    base_volume: float = 1_000_000  # Base volume
    
    # Event timing
    event_start_delay_minutes: float = 5.0
    event_duration_minutes: float = 10.0
    recovery_duration_minutes: float = 45.0
    
    # Specific parameters per scenario
    custom_parameters: Dict[str, Any] = field(default_factory=dict)


class MarketScenarioSimulator:
    """
    Simulates different market scenarios for stress testing.
    
    Generates realistic market data under various stress conditions
    to test strategy robustness.
    """
    
    def __init__(self, base_price: float = 100.0, seed: int = 42):
        self.base_price = base_price
        self.seed = seed
        np.random.seed(seed)
        
        # Scenario history
        self.scenario_history: List[Dict] = []
        
        # Market state
        self.current_price = base_price
        self.current_volatility = 0.02
        self.current_spread_bps = 2.0
        self.current_volume = 1_000_000
        
        # Order book simulation
        self.bid_prices = []
        self.ask_prices = []
        self.bid_sizes = []
        self.ask_sizes = []
        
        # Event tracking
        self.active_scenario: Optional[ScenarioType] = None
        self.scenario_start_time: Optional[datetime] = None
        self.scenario_end_time: Optional[datetime] = None
        
    def generate_scenario_data(self, scenario: ScenarioParameters,
                              n_points: int = 1000) -> pd.DataFrame:
        """
        Generate market data for a scenario.
        
        Args:
            scenario: Scenario parameters
            n_points: Number of data points to generate
            
        Returns:
            DataFrame with market data
        """
        # Calculate time parameters
        total_seconds = scenario.duration_minutes * 60
        timestamps = np.linspace(0, total_seconds, n_points)
        
        # Generate base price path (geometric brownian motion)
        base_prices = self._generate_base_price_path(
            n_points, scenario.base_volatility
        )
        
        # Apply scenario effects
        scenario_prices = self._apply_scenario_effects(
            base_prices, timestamps, scenario
        )
        
        # Generate volumes
        volumes = self._generate_volume_series(
            timestamps, scenario
        )
        
        # Generate spreads
        spreads = self._generate_spread_series(
            timestamps, scenario
        )
        
        # Generate order book data
        order_book_data = self._generate_order_book_data(
            scenario_prices, timestamps, scenario
        )
        
        # Create DataFrame
        df = pd.DataFrame({
            'timestamp': [datetime.now() + timedelta(seconds=float(t)) 
                         for t in timestamps],
            'price': scenario_prices,
            'volume': volumes,
            'spread_bps': spreads,
            'bid_price': order_book_data['bid_prices'],
            'ask_price': order_book_data['ask_prices'],
            'bid_size': order_book_data['bid_sizes'],
            'ask_size': order_book_data['ask_sizes'],
            'scenario_intensity': order_book_data['intensity']
        })
        
        # Store scenario info
        scenario_record = {
            'timestamp': datetime.now(),
            'scenario_type': scenario.scenario_type.value,
            'severity': scenario.severity,
            'duration_minutes': scenario.duration_minutes,
            'data_points': n_points,
            'price_range': (min(scenario_prices), max(scenario_prices)),
            'max_drawdown': self._calculate_max_drawdown(scenario_prices),
            'volatility_actual': np.std(np.diff(scenario_prices) / scenario_prices[:-1]) 
                               * np.sqrt(252) if len(scenario_prices) > 1 else 0.0
        }
        
        self.scenario_history.append(scenario_record)
        
        return df
    
    def _generate_base_price_path(self, n_points: int, 
                                 volatility: float) -> np.ndarray:
        """Generate base price path using geometric brownian motion."""
        dt = 1.0 / (252 * 24 * 60)  // 1-minute intervals
        returns = np.random.normal(
            0, 
            volatility * np.sqrt(dt), 
            n_points - 1
        )
        
        # Start from base price
        price_path = np.zeros(n_points)
        price_path[0] = self.base_price
        
        # Cumulative product of returns
        for i in range(1, n_points):
            price_path[i] = price_path[i-1] * (1 + returns[i-1])
        
        return price_path
    
    def _apply_scenario_effects(self, base_prices: np.ndarray,
                               timestamps: np.ndarray,
                               scenario: ScenarioParameters) -> np.ndarray:
        """Apply scenario-specific effects to price path."""
        scenario_type = scenario.scenario_type
        severity = scenario.severity
        
        # Convert timestamps to minutes
        timestamps_minutes = timestamps / 60.0
        
        # Event timing
        event_start = scenario.event_start_delay_minutes
        event_end = event_start + scenario.event_duration_minutes
        recovery_end = event_end + scenario.recovery_duration_minutes
        
        # Initialize scenario prices
        scenario_prices = base_prices.copy()
        
        # Apply scenario effects
        if scenario_type == ScenarioType.NORMAL:
            # No additional effects
            pass
        
        elif scenario_type == ScenarioType.HIGH_VOLATILITY:
            # Increase volatility during event
            for i, t in enumerate(timestamps_minutes):
                if event_start <= t < event_end:
                    # Add extra volatility
                    extra_vol = 0.05 * severity  // Additional 5% volatility per severity unit
                    shock = np.random.normal(0, extra_vol / np.sqrt(252 * 24 * 60))
                    scenario_prices[i] *= (1 + shock)
        
        elif scenario_type == ScenarioType.FLASH_CRASH:
            # Rapid price drop followed by recovery
            for i, t in enumerate(timestamps_minutes):
                if event_start <= t < event_end:
                    # Crash phase
                    time_in_event = t - event_start
                    event_progress = time_in_event / scenario.event_duration_minutes
                    
                    # Sharp drop (up to 20% per severity unit)
                    drop_magnitude = -0.20 * severity * (1 - np.exp(-5 * event_progress))
                    scenario_prices[i] *= (1 + drop_magnitude)
                
                elif event_end <= t < recovery_end:
                    # Recovery phase
                    time_in_recovery = t - event_end
                    recovery_progress = time_in_recovery / scenario.recovery_duration_minutes
                    
                    # Partial recovery (not full recovery)
                    recovery_magnitude = 0.15 * severity * (1 - np.exp(-2 * recovery_progress))
                    scenario_prices[i] *= (1 + recovery_magnitude)
        
        elif scenario_type == ScenarioType.LIQUIDITY_CRISIS:
            # Widen spreads and reduce volume
            for i, t in enumerate(timestamps_minutes):
                if event_start <= t < recovery_end:
                    # Gradually worsen then improve
                    if t < event_end:
                        crisis_progress = (t - event_start) / scenario.event_duration_minutes
                        intensity = crisis_progress * severity
                    else:
                        recovery_progress = (t - event_end) / scenario.recovery_duration_minutes
                        intensity = (1 - recovery_progress) * severity
                    
                    # Price impact from lack of liquidity
                    impact = np.random.normal(0, 0.01 * intensity / np.sqrt(252 * 24 * 60))
                    scenario_prices[i] *= (1 + impact)
        
        elif scenario_type == ScenarioType.NEWS_EVENT:
            # Sudden price jump on news
            for i, t in enumerate(timestamps_minutes):
                if event_start <= t < event_end:
                    # News impact (positive or negative)
                    news_direction = np.random.choice([-1, 1])
                    news_magnitude = 0.10 * severity  // 10% move per severity unit
                    
                    # Immediate jump then some reversion
                    time_in_event = t - event_start
                    jump = news_direction * news_magnitude * np.exp(-2 * time_in_event)
                    scenario_prices[i] *= (1 + jump)
        
        elif scenario_type == ScenarioType.ORDER_FLOW_IMBALANCE:
            # Sustained buying or selling pressure
            imbalance_direction = np.random.choice([-1, 1])
            
            for i, t in enumerate(timestamps_minutes):
                if event_start <= t < event_end:
                    # Sustained pressure
                    pressure = imbalance_direction * 0.001 * severity  // 0.1% per minute per severity
                    scenario_prices[i] *= (1 + pressure)
        
        elif scenario_type == ScenarioType.CIRCUIT_BREAKER:
            # Trading halt and resumed with gap
            halt_start = event_start
            halt_end = event_start + 5.0  // 5-minute halt
            
            for i, t in enumerate(timestamps_minutes):
                if halt_start <= t < halt_end:
                    # Freeze price during halt
                    scenario_prices[i] = scenario_prices[i-1] if i > 0 else scenario_prices[i]
                elif t >= halt_end and i > 0:
                    # Gap down/up after halt
                    gap_direction = np.random.choice([-1, 1])
                    gap_size = 0.05 * severity  // 5% gap per severity unit
                    scenario_prices[i] *= (1 + gap_direction * gap_size)
        
        elif scenario_type == ScenarioType.EXCHANGE_OUTAGE:
            # No price updates during outage
            outage_start = event_start
            outage_end = event_start + 15.0  // 15-minute outage
            
            for i, t in enumerate(timestamps_minutes):
                if outage_start <= t < outage_end:
                    # Freeze price
                    scenario_prices[i] = scenario_prices[i-1] if i > 0 else scenario_prices[i]
        
        elif scenario_type == ScenarioType.NETWORK_LATENCY_SPIKE:
            # Increased noise and delayed reactions
            for i, t in enumerate(timestamps_minutes):
                if event_start <= t < event_end:
                    # Add noise
                    noise = np.random.normal(0, 0.002 * severity)
                    scenario_prices[i] *= (1 + noise)
        
        elif scenario_type == ScenarioType.ADVERSE_SELECTION:
            # Toxic flow - prices move against traders
            for i, t in enumerate(timestamps_minutes):
                if event_start <= t < event_end:
                    # Adverse moves
                    if i > 0:
                        # Price tends to move opposite to recent trend
                        recent_trend = scenario_prices[i-1] - scenario_prices[max(0, i-5)]
                        adverse_move = -0.2 * recent_trend / scenario_prices[i-1] * severity
                        scenario_prices[i] *= (1 + adverse_move)
        
        # Ensure prices stay positive
        scenario_prices = np.maximum(0.01, scenario_prices)
        
        return scenario_prices
    
    def _generate_volume_series(self, timestamps: np.ndarray,
                               scenario: ScenarioParameters) -> np.ndarray:
        """Generate volume series for scenario."""
        timestamps_minutes = timestamps / 60.0
        n_points = len(timestamps)
        
        # Base volume with some randomness
        base_volume = scenario.base_volume
        volumes = np.random.lognormal(
            mean=np.log(base_volume),
            sigma=0.3,
            size=n_points
        )
        
        # Apply scenario effects
        scenario_type = scenario.scenario_type
        event_start = scenario.event_start_delay_minutes
        event_end = event_start + scenario.event_duration_minutes
        recovery_end = event_end + scenario.recovery_duration_minutes
        
        for i, t in enumerate(timestamps_minutes):
            if scenario_type == ScenarioType.HIGH_VOLATILITY:
                if event_start <= t < event_end:
                    # Volume spikes with volatility
                    volumes[i] *= (1 + 2.0 * scenario.severity)
            
            elif scenario_type == ScenarioType.FLASH_CRASH:
                if event_start <= t < event_end:
                    # Extreme volume during crash
                    volumes[i] *= (1 + 5.0 * scenario.severity)
            
            elif scenario_type == ScenarioType.LIQUIDITY_CRISIS:
                if event_start <= t < recovery_end:
                    # Volume dries up
                    volumes[i] *= 0.1  // 90% reduction
            
            elif scenario_type == ScenarioType.NEWS_EVENT:
                if event_start <= t < event_end:
                    # Volume spikes on news
                    volumes[i] *= (1 + 3.0 * scenario.severity)
            
            elif scenario_type == ScenarioType.ORDER_FLOW_IMBALANCE:
                if event_start <= t < event_end:
                    # Sustained high volume
                    volumes[i] *= (1 + 1.5 * scenario.severity)
            
            elif scenario_type in [ScenarioType.CIRCUIT_BREAKER, 
                                  ScenarioType.EXCHANGE_OUTAGE]:
                halt_start = event_start
                halt_end = event_start + 5.0 if scenario_type == ScenarioType.CIRCUIT_BREAKER \
                          else event_start + 15.0
                
                if halt_start <= t < halt_end:
                    # No volume during halt/outage
                    volumes[i] = 0.0
                elif t >= halt_end:
                    # Volume surge after resumption
                    volumes[i] *= (1 + 2.0 * scenario.severity)
        
        return volumes
    
    def _generate_spread_series(self, timestamps: np.ndarray,
                               scenario: ScenarioParameters) -> np.ndarray:
        """Generate spread series for scenario."""
        timestamps_minutes = timestamps / 60.0
        n_points = len(timestamps)
        
        # Base spread with some randomness
        base_spread = scenario.base_spread_bps
        spreads = np.random.lognormal(
            mean=np.log(base_spread),
            sigma=0.2,
            size=n_points
        )
        
        # Apply scenario effects
        scenario_type = scenario.scenario_type
        event_start = scenario.event_start_delay_minutes
        event_end = event_start + scenario.event_duration_minutes
        recovery_end = event_end + scenario.recovery_duration_minutes
        
        for i, t in enumerate(timestamps_minutes):
            if scenario_type == ScenarioType.HIGH_VOLATILITY:
                if event_start <= t < event_end:
                    # Spreads widen with volatility
                    spreads[i] *= (1 + 0.5 * scenario.severity)
            
            elif scenario_type == ScenarioType.FLASH_CRASH:
                if event_start <= t < event_end:
                    # Extreme spread widening
                    spreads[i] *= (1 + 2.0 * scenario.severity)
            
            elif scenario_type == ScenarioType.LIQUIDITY_CRISIS:
                if event_start <= t < recovery_end:
                    # Severe spread widening
                    if t < event_end:
                        crisis_progress = (t - event_start) / scenario.event_duration_minutes
                        multiplier = 1 + 4.0 * crisis_progress * scenario.severity
                    else:
                        recovery_progress = (t - event_end) / scenario.recovery_duration_minutes
                        multiplier = 1 + 4.0 * (1 - recovery_progress) * scenario.severity
                    spreads[i] *= multiplier
            
            elif scenario_type == ScenarioType.NEWS_EVENT:
                if event_start <= t < event_end:
                    # Temporary spread widening
                    spreads[i] *= (1 + 0.3 * scenario.severity)
        
        return spreads
    
    def _generate_order_book_data(self, prices: np.ndarray,
                                 timestamps: np.ndarray,
                                 scenario: ScenarioParameters) -> Dict:
        """Generate order book data for scenario."""
        n_points = len(prices)
        
        bid_prices = np.zeros(n_points)
        ask_prices = np.zeros(n_points)
        bid_sizes = np.zeros(n_points)
        ask_sizes = np.zeros(n_points)
        intensity = np.zeros(n_points)
        
        timestamps_minutes = timestamps / 60.0
        event_start = scenario.event_start_delay_minutes
        event_end = event_start + scenario.event_duration_minutes
        recovery_end = event_end + scenario.recovery_duration_minutes
        
        for i in range(n_points):
            # Base bid-ask spread
            spread_bps = self._generate_spread_series(
                np.array([timestamps[i]]), scenario
            )[0]
            
            # Convert to price units
            spread_price = prices[i] * spread_bps / 10000
            
            # Bid and ask prices
            bid_prices[i] = prices[i] - spread_price / 2
            ask_prices[i] = prices[i] + spread_price / 2
            
            # Base sizes
            base_size = 1000.0
            
            # Scenario intensity
            t = timestamps_minutes[i]
            if event_start <= t < event_end:
                intensity[i] = (t - event_start) / scenario.event_duration_minutes
            elif event_end <= t < recovery_end:
                intensity[i] = 1 - (t - event_end) / scenario.recovery_duration_minutes
            else:
                intensity[i] = 0.0
            
            # Apply scenario effects to sizes
            if scenario.scenario_type == ScenarioType.LIQUIDITY_CRISIS:
                # Reduce sizes during crisis
                size_multiplier = max(0.1, 1 - 0.9 * intensity[i] * scenario.severity)
            elif scenario.scenario_type == ScenarioType.FLASH_CRASH:
                # Reduce sizes during crash
                size_multiplier = max(0.2, 1 - 0.8 * intensity[i] * scenario.severity)
            else:
                size_multiplier = 1.0
            
            bid_sizes[i] = base_size * size_multiplier * np.random.lognormal(0, 0.3)
            ask_sizes[i] = base_size * size_multiplier * np.random.lognormal(0, 0.3)
        
        return {
            'bid_prices': bid_prices,
            'ask_prices': ask_prices,
            'bid_sizes': bid_sizes,
            'ask_sizes': ask_sizes,
            'intensity': intensity
        }
    
    def _calculate_max_drawdown(self, prices: np.ndarray) -> float:
        """Calculate maximum drawdown from price series."""
        if len(prices) < 2:
            return 0.0
        
        peak = prices[0]
        max_dd = 0.0
        
        for price in prices:
            if price > peak:
                peak = price
            
            dd = (peak - price) / peak
            if dd > max_dd:
                max_dd = dd
        
        return max_dd
    
    async def run_live_scenario(self, scenario: ScenarioParameters,
                               callback=None, update_interval_seconds: float = 1.0):
        """
        Run scenario in real-time simulation.
        
        Args:
            scenario: Scenario parameters
            callback: Callback function for market data updates
            update_interval_seconds: Time between updates
        """
        self.active_scenario = scenario.scenario_type
        self.scenario_start_time = datetime.now()
        
        # Generate data for the scenario
        total_updates = int(scenario.duration_minutes * 60 / update_interval_seconds)
        timestamps = np.linspace(0, scenario.duration_minutes * 60, total_updates)
        
        # Generate price path
        prices = self._generate_base_price_path(total_updates, scenario.base_volatility)
        prices = self._apply_scenario_effects(prices, timestamps, scenario)
        
        # Generate other data
        volumes = self._generate_volume_series(timestamps, scenario)
        spreads = self._generate_spread_series(timestamps, scenario)
        order_book_data = self._generate_order_book_data(prices, timestamps, scenario)
        
        # Run simulation
        for i in range(total_updates):
            # Update market state
            self.current_price = prices[i]
            self.current_volatility = scenario.base_volatility * (1 + 0.5 * (i / total_updates))
            self.current_spread_bps = spreads[i]
            self.current_volume = volumes[i]
            
            # Update order book
            self.bid_prices = [order_book_data['bid_prices'][i]]
            self.ask_prices = [order_book_data['ask_prices'][i]]
            self.bid_sizes = [order_book_data['bid_sizes'][i]]
            self.ask_sizes = [order_book_data['ask_sizes'][i]]
            
            # Prepare market data update
            market_data = {
                'timestamp': datetime.now(),
                'price': self.current_price,
                'volume': self.current_volume,
                'spread_bps': self.current_spread_bps,
                'bid_price': self.bid_prices[0] if self.bid_prices else None,
                'ask_price': self.ask_prices[0] if self.ask_prices else None,
                'bid_size': self.bid_sizes[0] if self.bid_sizes else None,
                'ask_size': self.ask_sizes[0] if self.ask_sizes else None,
                'scenario_intensity': order_book_data['intensity'][i],
                'scenario_type': scenario.scenario_type.value,
                'scenario_progress': i / total_updates
            }
            
            # Call callback if provided
            if callback:
                await callback(market_data)
            
            # Wait for next update
            await asyncio.sleep(update_interval_seconds)
        
        # End scenario
        self.active_scenario = None
        self.scenario_end_time = datetime.now()
        
        # Generate scenario report
        report = self.generate_scenario_report(scenario, prices, volumes, spreads)
        
        return report
    
    def generate_scenario_report(self, scenario: ScenarioParameters,
                                prices: np.ndarray, volumes: np.ndarray,
                                spreads: np.ndarray) -> Dict:
        """Generate comprehensive scenario report."""
        returns = np.diff(prices) / prices[:-1]
        
        report = {
            'scenario': {
                'type': scenario.scenario_type.value,
                'severity': scenario.severity,
                'duration_minutes': scenario.duration_minutes,
                'event_start_delay': scenario.event_start_delay_minutes,
                'event_duration': scenario.event_duration_minutes,
                'recovery_duration': scenario.recovery_duration_minutes
            },
            'market_statistics': {
                'initial_price': float(prices[0]),
                'final_price': float(prices[-1]),
                'total_return': float((prices[-1] - prices[0]) / prices[0]),
                'max_price': float(np.max(prices)),
                'min_price': float(np.min(prices)),
                'avg_price': float(np.mean(prices)),
                'volatility_annualized': float(np.std(returns) * np.sqrt(252 * 24 * 60) 
                                              if len(returns) > 1 else 0.0),
                'max_drawdown': float(self._calculate_max_drawdown(prices)),
                'sharpe_ratio': float(np.mean(returns) / np.std(returns) * np.sqrt(252 * 24 * 60)
                                     if len(returns) > 1 and np.std(returns) > 0 else 0.0)
            },
            'volume_statistics': {
                'avg_volume': float(np.mean(volumes)),
                'max_volume': float(np.max(volumes)),
                'min_volume': float(np.min(volumes)),
                'volume_volatility': float(np.std(volumes) / np.mean(volumes) 
                                          if np.mean(volumes) > 0 else 0.0)
            },
            'liquidity_statistics': {
                'avg_spread_bps': float(np.mean(spreads)),
                'max_spread_bps': float(np.max(spreads)),
                'min_spread_bps': float(np.min(spreads)),
                'spread_volatility': float(np.std(spreads) / np.mean(spreads) 
                                          if np.mean(spreads) > 0 else 0.0)
            },
            'event_analysis': self._analyze_scenario_events(prices, volumes, spreads, scenario),
            'risk_metrics': self._calculate_scenario_risk_metrics(prices, returns),
            'recommendations': self._generate_scenario_recommendations(scenario, prices, spreads)
        }
        
        return report
    
    def _analyze_scenario_events(self, prices: np.ndarray, volumes: np.ndarray,
                                spreads: np.ndarray, scenario: ScenarioParameters) -> Dict:
        """Analyze specific events within the scenario."""
        event_start_idx = int(len(prices) * 
                            (scenario.event_start_delay_minutes / scenario.duration_minutes))
        event_end_idx = int(len(prices) * 
                          ((scenario.event_start_delay_minutes + scenario.event_duration_minutes) / 
                           scenario.duration_minutes))
        
        # Pre-event period
        pre_prices = prices[:event_start_idx]
        pre_volumes = volumes[:event_start_idx]
        pre_spreads = spreads[:event_start_idx]
        
        # Event period
        event_prices = prices[event_start_idx:event_end_idx]
        event_volumes = volumes[event_start_idx:event_end_idx]
        event_spreads = spreads[event_start_idx:event_end_idx]
        
        # Post-event period
        post_prices = prices[event_end_idx:]
        post_volumes = volumes[event_end_idx:]
        post_spreads = spreads[event_end_idx:]
        
        return {
            'pre_event': {
                'price_change': float((pre_prices[-1] - pre_prices[0]) / pre_prices[0]) 
                              if len(pre_prices) > 1 else 0.0,
                'volatility': float(np.std(np.diff(pre_prices) / pre_prices[:-1]) * np.sqrt(252 * 24 * 60)
                                  if len(pre_prices) > 1 else 0.0),
                'avg_volume': float(np.mean(pre_volumes)) if len(pre_volumes) > 0 else 0.0,
                'avg_spread_bps': float(np.mean(pre_spreads)) if len(pre_spreads) > 0 else 0.0
            },
            'event': {
                'price_change': float((event_prices[-1] - event_prices[0]) / event_prices[0]) 
                              if len(event_prices) > 1 else 0.0,
                'max_intra_event_drawdown': float(self._calculate_max_drawdown(event_prices)) 
                                          if len(event_prices) > 0 else 0.0,
                'volatility': float(np.std(np.diff(event_prices) / event_prices[:-1]) * np.sqrt(252 * 24 * 60)
                                  if len(event_prices) > 1 else 0.0),
                'volume_multiplier': float(np.mean(event_volumes) / np.mean(pre_volumes)) 
                                   if len(pre_volumes) > 0 and np.mean(pre_volumes) > 0 else 1.0,
                'spread_multiplier': float(np.mean(event_spreads) / np.mean(pre_spreads)) 
                                   if len(pre_spreads) > 0 and np.mean(pre_spreads) > 0 else 1.0
            },
            'recovery': {
                'recovery_percentage': float((post_prices[-1] - event_prices[-1]) / 
                                           (event_prices[0] - event_prices[-1]) * 100 
                                           if len(post_prices) > 0 and len(event_prices) > 0 
                                           and event_prices[0] != event_prices[-1] else 0.0),
                'recovery_volatility': float(np.std(np.diff(post_prices) / post_prices[:-1]) * 
                                           np.sqrt(252 * 24 * 60) if len(post_prices) > 1 else 0.0),
                'time_to_50pct_recovery': self._calculate_recovery_time(
                    post_prices, event_prices[-1] if len(event_prices) > 0 else 0.0, 0.5
                ),
                'time_to_90pct_recovery': self._calculate_recovery_time(
                    post_prices, event_prices[-1] if len(event_prices) > 0 else 0.0, 0.9
                )
            }
        }
    
    def _calculate_recovery_time(self, prices: np.ndarray, event_low: float,
                                recovery_threshold: float) -> float:
        """Calculate time to reach recovery threshold."""
        if len(prices) == 0 or event_low == 0:
            return 0.0
        
        # Find where price recovers to threshold of event low
        for i, price in enumerate(prices):
            recovery_ratio = (price - event_low) / abs(event_low)
            if recovery_ratio >= recovery_threshold:
                return i * (1.0 / len(prices))  // As fraction of recovery period
        
        return 0.0  // Never reached threshold
    
    def _calculate_scenario_risk_metrics(self, prices: np.ndarray,
                                        returns: np.ndarray) -> Dict:
        """Calculate risk metrics for the scenario."""
        if len(prices) < 2 or len(returns) < 2:
            return {}
        
        # Value at Risk (VaR) at 95% confidence
        var_95 = np.percentile(returns, 5)
        
        # Expected Shortfall (CVaR) at 95% confidence
        cvar_95 = np.mean(returns[returns <= var_95]) if np.sum(returns <= var_95) > 0 else var_95
        
        # Maximum adverse excursion
        running_max = np.maximum.accumulate(prices)
        drawdowns = (prices - running_max) / running_max
        max_adverse_excursion = np.min(drawdowns)
        
        # Stress periods identification
        stress_periods = self._identify_stress_periods(returns)
        
        return {
            'value_at_risk_95': float(var_95),
            'conditional_var_95': float(cvar_95),
            'max_adverse_excursion': float(max_adverse_excursion),
            'expected_max_loss': float(np.mean(np.sort(returns)[:int(len(returns) * 0.05)]) 
                                      if len(returns) > 20 else np.min(returns)),
            'tail_risk_ratio': float(abs(cvar_95 / np.std(returns)) 
                                   if np.std(returns) > 0 else 0.0),
            'stress_periods_count': len(stress_periods),
            'total_stress_duration': sum(p['duration'] for p in stress_periods),
            'worst_stress_period': max(stress_periods, key=lambda x: x['severity'], 
                                      default={'severity': 0, 'duration': 0})
        }
    
    def _identify_stress_periods(self, returns: np.ndarray, 
                                threshold_std: float = 2.0) -> List[Dict]:
        """Identify stress periods in returns."""
        if len(returns) < 10:
            return []
        
        returns_std = np.std(returns)
        stress_threshold = -threshold_std * returns_std
        
        stress_periods = []
        in_stress = False
        stress_start = 0
        
        for i, ret in enumerate(returns):
            if ret < stress_threshold and not in_stress:
                in_stress = True
                stress_start = i
            elif ret >= stress_threshold and in_stress:
                in_stress = False
                stress_periods.append({
                    'start': stress_start,
                    'end': i - 1,
                    'duration': i - stress_start,
                    'severity': np.mean(returns[stress_start:i]) / returns_std,
                    'max_drawdown': np.min(returns[stress_start:i]) / returns_std
                })
        
        # Handle ongoing stress at end
        if in_stress:
            stress_periods.append({
                'start': stress_start,
                'end': len(returns) - 1,
                'duration': len(returns) - stress_start,
                'severity': np.mean(returns[stress_start:]) / returns_std,
                'max_drawdown': np.min(returns[stress_start:]) / returns_std
            })
        
        return stress_periods
    
    def _generate_scenario_recommendations(self, scenario: ScenarioParameters,
                                          prices: np.ndarray, spreads: np.ndarray) -> List[Dict]:
        """Generate recommendations based on scenario results."""
        recommendations = []
        
        # Calculate key metrics
        max_dd = self._calculate_max_drawdown(prices)
        avg_spread = np.mean(spreads)
        max_spread = np.max(spreads)
        
        # General recommendations
        if max_dd > 0.10:  // More than 10% drawdown
            recommendations.append({
                'type': 'RISK_MANAGEMENT',
                'priority': 'HIGH',
                'message': f'Large drawdown detected ({max_dd:.1%})',
                'action': 'Implement tighter stop-losses or reduce position sizes',
                'expected_impact': 'High'
            })
        
        if max_spread > avg_spread * 3:  // Spread spiked significantly
            recommendations.append({
                'type': 'EXECUTION',
                'priority': 'MEDIUM',
                'message': f'Spread volatility high (max/avg: {max_spread/avg_spread:.1f}x)',
                'action': 'Use limit orders during volatile periods',
                'expected_impact': 'Medium'
            })
        
        # Scenario-specific recommendations
        if scenario.scenario_type == ScenarioType.FLASH_CRASH:
            recommendations.append({
                'type': 'SCENARIO_SPECIFIC',
                'priority': 'HIGH',
                'message': 'Strategy vulnerable to flash crashes',
                'action': 'Implement circuit breaker logic and liquidity checks',
                'expected_impact': 'Critical'
            })
        
        elif scenario.scenario_type == ScenarioType.LIQUIDITY_CRISIS:
            recommendations.append({
                'type': 'SCENARIO_SPECIFIC',
                'priority': 'HIGH',
                'message': 'Strategy suffers during liquidity crises',
                'action': 'Add liquidity monitoring and size adjustments',
                'expected_impact': 'High'
            })
        
        elif scenario.scenario_type == ScenarioType.ADVERSE_SELECTION:
            recommendations.append({
                'type': 'SCENARIO_SPECIFIC',
                'priority': 'MEDIUM',
                'message': 'Adverse selection impact detected',
                'action': 'Implement toxicity filters and adverse selection models',
                'expected_impact': 'Medium'
            })
        
        return recommendations
    
    def get_scenario_summary(self) -> Dict:
        """Get summary of all simulated scenarios."""
        if not self.scenario_history:
            return {}
        
        # Calculate statistics across all scenarios
        scenarios_by_type = {}
        for scenario in self.scenario_history:
            scenario_type = scenario['scenario_type']
            if scenario_type not in scenarios_by_type:
                scenarios_by_type[scenario_type] = []
            scenarios_by_type[scenario_type].append(scenario)
        
        summary = {
            'total_scenarios': len(self.scenario_history),
            'scenarios_by_type': {
                scenario_type: len(scenarios) 
                for scenario_type, scenarios in scenarios_by_type.items()
            },
            'worst_case_scenario': max(self.scenario_history, 
                                      key=lambda x: x.get('max_drawdown', 0),
                                      default=None),
            'most_volatile_scenario': max(self.scenario_history,
                                         key=lambda x: x.get('volatility_actual', 0),
                                         default=None),
            'recent_scenarios': self.scenario_history[-5:] if len(self.scenario_history) >= 5 
                              else self.scenario_history,
            'active_scenario': self.active_scenario.value if self.active_scenario else None,
            'scenario_duration_minutes': (
                (self.scenario_end_time - self.scenario_start_time).total_seconds() / 60 
                if self.scenario_start_time and self.scenario_end_time else 0.0
            )
        }
        
        return summary
    
    def run_comprehensive_stress_test(self, strategies: List[Any],
                                     scenarios: List[ScenarioParameters]) -> Dict:
        """
        Run comprehensive stress test across multiple strategies and scenarios.
        
        Args:
            strategies: List of strategy objects to test
            scenarios: List of scenarios to run
            
        Returns:
            Comprehensive stress test results
        """
        results = {
            'strategies': {},
            'scenarios': {},
            'overall_metrics': {}
        }
        
        # Test each strategy against each scenario
        for strategy in strategies:
            strategy_name = getattr(strategy, 'name', str(strategy))
            results['strategies'][strategy_name] = {}
            
            for scenario in scenarios:
                scenario_name = scenario.scenario_type.value
                
                # Generate scenario data
                scenario_data = self.generate_scenario_data(scenario)
                
                # Run strategy on scenario data
                strategy_results = self._run_strategy_on_scenario(
                    strategy, scenario_data, scenario
                )
                
                # Store results
                results['strategies'][strategy_name][scenario_name] = strategy_results
                results['scenarios'][scenario_name] = scenario_data
        
        # Calculate overall metrics
        results['overall_metrics'] = self._calculate_overall_stress_metrics(results)
        
        return results
    
    def _run_strategy_on_scenario(self, strategy, scenario_data: pd.DataFrame,
                                 scenario: ScenarioParameters) -> Dict:
        """Run strategy on scenario data and collect results."""
        # This is a simplified implementation
        # In practice, this would run the full strategy logic
        
        # Simulate strategy performance
        initial_capital = 100000.0
        capital = initial_capital
        positions = []
        trades = []
        
        # Simple simulation: buy on dip, sell on recovery
        prices = scenario_data['price'].values
        buy_threshold = -0.02  // Buy after 2% drop
        sell_threshold = 0.02   // Sell after 2% gain
        
        for i in range(1, len(prices)):
            ret = (prices[i] - prices[i-1]) / prices[i-1]
            
            if ret < buy_threshold and capital > 1000:
                // Buy
                position_size = min(capital * 0.1, 10000) // 10% of capital or 10k
                shares = position_size / prices[i]
                positions.append({
                    'timestamp': scenario_data.iloc[i]['timestamp'],
                    'action': 'BUY',
                    'price': prices[i],
                    'shares': shares,
                    'value': position_size
                })
                capital -= position_size
            
            elif ret > sell_threshold and positions:
                // Sell
                for pos in positions:
                    if pos['action'] == 'BUY':
                        sale_value = pos['shares'] * prices[i]
                        capital += sale_value
                        
                        trades.append({
                            'buy_price': pos['price'],
                            'sell_price': prices[i],
                            'pnl': sale_value - pos['value'],
                            'return': (prices[i] - pos['price']) / pos['price']
                        })
                        break
        
        # Calculate performance
        final_value = capital + sum(pos['shares'] * prices[-1] 
                                   for pos in positions if pos['action'] == 'BUY')
        total_return = (final_value - initial_capital) / initial_capital
        
        # Calculate risk metrics
        if trades:
            returns = [t['return'] for t in trades]
            avg_return = np.mean(returns)
            std_return = np.std(returns) if len(returns) > 1 else 0.0
            sharpe = avg_return / std_return * np.sqrt(252) if std_return > 0 else 0.0
            win_rate = sum(1 for t in trades if t['pnl'] > 0) / len(trades)
        else:
            avg_return = 0.0
            std_return = 0.0
            sharpe = 0.0
            win_rate = 0.0
        
        return {
            'initial_capital': initial_capital,
            'final_value': final_value,
            'total_return': total_return,
            'total_trades': len(trades),
            'profitable_trades': sum(1 for t in trades if t['pnl'] > 0),
            'avg_trade_return': avg_return,
            'std_trade_return': std_return,
            'sharpe_ratio': sharpe,
            'win_rate': win_rate,
            'max_consecutive_losses': self._calculate_max_consecutive_losses(trades),
            'max_drawdown_simulated': self._calculate_simulated_drawdown(positions, trades, prices),
            'scenario_severity': scenario.severity,
            'scenario_duration': scenario.duration_minutes
        }
    
    def _calculate_max_consecutive_losses(self, trades: List[Dict]) -> int:
        """Calculate maximum consecutive losing trades."""
        if not trades:
            return 0
        
        max_losses = 0
        current_losses = 0
        
        for trade in trades:
            if trade.get('pnl', 0) <= 0:
                current_losses += 1
                max_losses = max(max_losses, current_losses)
            else:
                current_losses = 0
        
        return max_losses
    
    def _calculate_simulated_drawdown(self, positions: List[Dict],
                                     trades: List[Dict], prices: np.ndarray) -> float:
        """Calculate maximum drawdown from simulated trading."""
        if not positions and not trades:
            return 0.0
        
        # Simplified drawdown calculation
        # In practice, this would track equity curve
        
        return 0.05  // Placeholder
    
    def _calculate_overall_stress_metrics(self, results: Dict) -> Dict:
        """Calculate overall metrics from stress test results."""
        overall_metrics = {
            'strategy_robustness_scores': {},
            'scenario_impact_scores': {},
            'worst_case_impacts': {},
            'recommendations': []
        }
        
        # Calculate robustness score for each strategy
        for strategy_name, scenario_results in results['strategies'].items():
            robustness_scores = []
            
            for scenario_name, result in scenario_results.items():
                # Score based on performance vs risk
                score = self._calculate_strategy_score(result)
                robustness_scores.append(score)
            
            if robustness_scores:
                overall_metrics['strategy_robustness_scores'][strategy_name] = {
                    'avg_score': np.mean(robustness_scores),
                    'min_score': min(robustness_scores),
                    'max_score': max(robustness_scores),
                    'stability': 1.0 - (np.std(robustness_scores) / np.mean(robustness_scores) 
                                       if np.mean(robustness_scores) > 0 else 0.0)
                }
        
        # Calculate impact score for each scenario
        scenario_impacts = {}
        for scenario_name in results['scenarios']:
            impacts = []
            for strategy_name in results['strategies']:
                if scenario_name in results['strategies'][strategy_name]:
                    result = results['strategies'][strategy_name][scenario_name]
                    impact = 1.0 - (result['total_return'] + 1.0) / 2.0  // Normalize to 0-1
                    impacts.append(impact)
            
            if impacts:
                scenario_impacts[scenario_name] = {
                    'avg_impact': np.mean(impacts),
                    'max_impact': max(impacts),
                    'consistency': np.std(impacts) if len(impacts) > 1 else 0.0
                }
        
        overall_metrics['scenario_impact_scores'] = scenario_impacts
        
        # Identify worst-case impacts
        for strategy_name in results['strategies']:
            worst_scenario = None
            worst_return = float('inf')
            
            for scenario_name, result in results['strategies'][strategy_name].items():
                if result['total_return'] < worst_return:
                    worst_return = result['total_return']
                    worst_scenario = scenario_name
            
            overall_metrics['worst_case_impacts'][strategy_name] = {
                'scenario': worst_scenario,
                'return': worst_return,
                'severity': 'HIGH' if worst_return < -0.2 else 
                           'MEDIUM' if worst_return < -0.1 else 'LOW'
            }
        
        # Generate overall recommendations
        overall_metrics['recommendations'] = self._generate_overall_recommendations(results)
        
        return overall_metrics
    
    def _calculate_strategy_score(self, result: Dict) -> float:
        """Calculate a single score for strategy performance."""
        # Combine multiple metrics into a single score (0-100)
        score = 50.0  // Base score
        
        # Adjust for total return
        total_return = result.get('total_return', 0.0)
        score += min(25, max(-25, total_return * 100))  // ±25 points for returns
        
        # Adjust for risk (Sharpe ratio)
        sharpe = result.get('sharpe_ratio', 0.0)
        score += min(15, max(-15, sharpe * 10))  // ±15 points for Sharpe
        
        # Adjust for win rate
        win_rate = result.get('win_rate', 0.0)
        score += (win_rate - 0.5) * 20  // ±10 points for win rate
        
        # Penalize for high drawdown
        max_dd = result.get('max_drawdown_simulated', 0.0)
        score -= min(20, max_dd * 100)  // Up to -20 points for drawdown
        
        # Penalize for consecutive losses
        consecutive_losses = result.get('max_consecutive_losses', 0)
        score -= min(10, consecutive_losses * 2)  // Up to -10 points
        
        return max(0, min(100, score))
    
    def _generate_overall_recommendations(self, results: Dict) -> List[Dict]:
        """Generate overall recommendations from stress test results."""
        recommendations = []
        
        # Check for strategies vulnerable to specific scenarios
        vulnerable_strategies = {}
        
        for strategy_name, scenario_results in results['strategies'].items():
            for scenario_name, result in scenario_results.items():
                if result.get('total_return', 0) < -0.15:  // More than 15% loss
                    if scenario_name not in vulnerable_strategies:
                        vulnerable_strategies[scenario_name] = []
                    vulnerable_strategies[scenario_name].append(strategy_name)
        
        # Generate recommendations
        for scenario, strategies in vulnerable_strategies.items():
            if len(strategies) > len(results['strategies']) * 0.5:
                // Majority of strategies vulnerable
                recommendations.append({
                    'type': 'SYSTEMIC_RISK',
                    'priority': 'CRITICAL',
                    'message': f'Most strategies vulnerable to {scenario}',
                    'action': f'Implement systemic risk controls for {scenario} scenarios',
                    'scope': 'ALL_STRATEGIES'
                })
            else:
                recommendations.append({
                    'type': 'STRATEGY_SPECIFIC',
                    'priority': 'HIGH',
                    'message': f'Strategies {strategies} vulnerable to {scenario}',
                    'action': f'Review and adjust {", ".join(strategies)} for {scenario} resilience',
                    'scope': 'SPECIFIC_STRATEGIES'
                })
        
        // Check for consistency across scenarios
        strategy_scores = {}
        for strategy_name in results['strategies']:
            scores = []
            for scenario_name in results['strategies'][strategy_name]:
                result = results['strategies'][strategy_name][scenario_name]
                scores.append(result.get('total_return', 0))
            
            if scores:
                consistency = np.std(scores) / (abs(np.mean(scores)) + 1e-6)
                if consistency > 2.0:  // Highly inconsistent
                    recommendations.append({
                        'type': 'CONSISTENCY',
                        'priority': 'MEDIUM',
                        'message': f'Strategy {strategy_name} has inconsistent performance',
                        'action': f'Review {strategy_name} parameter stability',
                        'scope': 'SINGLE_STRATEGY'
                    })
        
        return recommendations