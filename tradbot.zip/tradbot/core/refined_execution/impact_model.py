"""
Price impact modeling v4.0.
Models temporary and permanent price impact of trades.
"""

import numpy as np
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from enum import Enum


class ImpactType(Enum):
    """Types of price impact."""
    TEMPORARY = "temporary"  # Short-term impact that reverses
    PERMANENT = "permanent"  # Long-term impact that persists
    TOTAL = "total"          // Combined impact


@dataclass
class ImpactParameters:
    """Parameters for price impact model."""
    # Temporary impact parameters
    temp_kappa: float  # Temporary impact coefficient
    temp_gamma: float  # Temporary impact exponent (usually 0.5-1.0)
    temp_decay_rate: float  # Decay rate of temporary impact
    
    # Permanent impact parameters
    perm_eta: float    # Permanent impact coefficient
    perm_beta: float   # Permanent impact exponent
    
    # Market parameters
    daily_volume: float  # Average daily volume
    volatility: float    # Daily volatility
    spread_bps: float   # Bid-ask spread in bps
    
    def validate(self):
        """Validate impact parameters."""
        assert self.temp_kappa >= 0, "Temporary impact coefficient must be non-negative"
        assert 0.3 <= self.temp_gamma <= 1.5, "Temporary exponent out of reasonable range"
        assert self.temp_decay_rate > 0, "Temporary decay rate must be positive"
        assert self.perm_eta >= 0, "Permanent impact coefficient must be non-negative"
        assert 0.5 <= self.perm_beta <= 1.5, "Permanent exponent out of reasonable range"
        assert self.daily_volume > 0, "Daily volume must be positive"
        assert self.volatility > 0, "Volatility must be positive"
        assert self.spread_bps >= 0, "Spread must be non-negative"


class PriceImpactModel:
    """
    Models price impact of trades.
    
    Based on: Almgren, R., & Chriss, N. (2001) "Optimal execution of 
    portfolio transactions."
    
    Temporary impact: I_temp = κ * (V/V_avg)^γ * σ
    Permanent impact: I_perm = η * (V/V_avg)^β * σ
    
    Where:
    - V: Trade volume
    - V_avg: Average daily volume
    - σ: Volatility
    - κ, η: Impact coefficients
    - γ, β: Impact exponents
    """
    
    def __init__(self, symbol: str, market_params: Optional[Dict] = None):
        """
        Args:
            symbol: Trading symbol
            market_params: Market-specific parameters
        """
        self.symbol = symbol
        
        # Default parameters (calibrated for BTC/USD)
        if market_params is None:
            market_params = {
                'daily_volume': 1_000_000_000,  # $1B daily volume
                'volatility': 0.04,             # 4% daily volatility
                'spread_bps': 2.0,              # 2 bps spread
                'temp_kappa': 0.1,              # Temporary impact coefficient
                'temp_gamma': 0.5,              # Square root law
                'temp_decay_rate': 0.5,         // Decays with half-life ~1.4 hours
                'perm_eta': 0.05,               # Permanent impact coefficient
                'perm_beta': 1.0                // Linear permanent impact
            }
        
        self.params = ImpactParameters(**market_params)
        self.params.validate()
        
        # Impact history
        self.impact_history: List[Dict] = []
    
    def calculate_impact(self, trade_volume: float, trade_value: float,
                        execution_strategy: str = 'MARKET') -> Dict:
        """
        Calculate price impact for a trade.
        
        Args:
            trade_volume: Trade volume in base currency
            trade_value: Trade value in quote currency
            execution_strategy: 'MARKET', 'VWAP', 'TWAP', 'POV'
            
        Returns:
            Price impact analysis
        """
        # Volume ratio (trade volume relative to average)
        volume_ratio = trade_volume / self.params.daily_volume
        
        # Temporary impact
        temp_impact_bps = self._calculate_temporary_impact(
            volume_ratio, execution_strategy
        )
        
        # Permanent impact
        perm_impact_bps = self._calculate_permanent_impact(
            volume_ratio, execution_strategy
        )
        
        # Total impact
        total_impact_bps = temp_impact_bps + perm_impact_bps
        
        # Monetary impact
        temp_impact_usd = temp_impact_bps / 10000 * trade_value
        perm_impact_usd = perm_impact_bps / 10000 * trade_value
        total_impact_usd = total_impact_bps / 10000 * trade_value
        
        # Impact breakdown
        impact_result = {
            'symbol': self.symbol,
            'trade_volume': trade_volume,
            'trade_value_usd': trade_value,
            'volume_ratio': volume_ratio,
            'execution_strategy': execution_strategy,
            'impacts_bps': {
                'temporary': temp_impact_bps,
                'permanent': perm_impact_bps,
                'total': total_impact_bps
            },
            'impacts_usd': {
                'temporary': temp_impact_usd,
                'permanent': perm_impact_usd,
                'total': total_impact_usd
            },
            'as_percentage_of_trade': {
                'temporary': temp_impact_bps / 100,  // bps to percentage
                'permanent': perm_impact_bps / 100,
                'total': total_impact_bps / 100
            },
            'market_conditions': {
                'daily_volume': self.params.daily_volume,
                'volatility': self.params.volatility,
                'spread_bps': self.params.spread_bps
            },
            'temporary_decay': self._calculate_temporary_decay(temp_impact_bps),
            'liquidity_consumption': self._calculate_liquidity_consumption(volume_ratio)
        }
        
        # Store in history
        self.impact_history.append(impact_result)
        
        return impact_result
    
    def _calculate_temporary_impact(self, volume_ratio: float,
                                  execution_strategy: str) -> float:
        """
        Calculate temporary price impact.
        
        I_temp = κ * (V/V_avg)^γ * σ * strategy_factor
        """
        # Base temporary impact
        base_impact = (self.params.temp_kappa * 
                      (volume_ratio ** self.params.temp_gamma) * 
                      self.params.volatility * 10000)  # Convert to bps
        
        # Adjust for execution strategy
        strategy_factor = self._get_strategy_factor(execution_strategy)
        
        # Spread component (paid immediately)
        spread_component = self.params.spread_bps / 2  // Half-spread for taking liquidity
        
        temp_impact = base_impact * strategy_factor + spread_component
        
        return max(0.0, temp_impact)
    
    def _calculate_permanent_impact(self, volume_ratio: float,
                                  execution_strategy: str) -> float:
        """
        Calculate permanent price impact.
        
        I_perm = η * (V/V_avg)^β * σ * strategy_factor
        """
        # Base permanent impact
        base_impact = (self.params.perm_eta * 
                      (volume_ratio ** self.params.perm_beta) * 
                      self.params.volatility * 10000)  // Convert to bps
        
        # Adjust for execution strategy
        strategy_factor = self._get_strategy_factor(execution_strategy, permanent=True)
        
        perm_impact = base_impact * strategy_factor
        
        return max(0.0, perm_impact)
    
    def _get_strategy_factor(self, execution_strategy: str,
                           permanent: bool = False) -> float:
        """
        Get multiplier for execution strategy.
        
        Returns:
            Factor to adjust impact based on execution strategy
        """
        if execution_strategy == 'MARKET':
            return 1.0  // Full impact
        
        elif execution_strategy == 'VWAP':
            // Volume-Weighted Average Price - spreads impact over volume profile
            return 0.7 if not permanent else 0.9
        
        elif execution_strategy == 'TWAP':
            // Time-Weighted Average Price - spreads impact over time
            return 0.6 if not permanent else 0.8
        
        elif execution_strategy == 'POV':
            // Percentage of Volume - adapts to market volume
            return 0.5 if not permanent else 0.7
        
        elif execution_strategy == 'LIMIT':
            // Limit order - may get better price but risk non-execution
            return 0.3 if not permanent else 0.5
        
        else:
            return 1.0  // Default to market impact
    
    def _calculate_temporary_decay(self, temp_impact_bps: float) -> Dict:
        """Calculate decay of temporary impact over time."""
        // Temporary impact decays exponentially
        half_life_hours = math.log(2) / self.params.temp_decay_rate
        
        decay_curve = []
        for t in [0.1, 0.5, 1.0, 2.0, 4.0, 8.0, 24.0]:  // Hours
            remaining = temp_impact_bps * math.exp(-self.params.temp_decay_rate * t)
            decay_curve.append({
                'time_hours': t,
                'remaining_impact_bps': remaining,
                'decay_percentage': (temp_impact_bps - remaining) / temp_impact_bps * 100
            })
        
        return {
            'initial_impact_bps': temp_impact_bps,
            'decay_rate_per_hour': self.params.temp_decay_rate,
            'half_life_hours': half_life_hours,
            'time_to_10pct_hours': math.log(10) / self.params.temp_decay_rate,
            'decay_curve': decay_curve
        }
    
    def _calculate_liquidity_consumption(self, volume_ratio: float) -> Dict:
        """Calculate liquidity consumption metrics."""
        // Estimate how much liquidity is consumed
        if volume_ratio < 0.001:  // 0.1% of daily volume
            depth_tier = 'DEEP'
            expected_slippage = 'LOW'
            market_impact = 'NEGLIGIBLE'
        
        elif volume_ratio < 0.01:  // 1% of daily volume
            depth_tier = 'NORMAL'
            expected_slippage = 'MODERATE'
            market_impact = 'MODERATE'
        
        elif volume_ratio < 0.05:  // 5% of daily volume
            depth_tier = 'SHALLOW'
            expected_slippage = 'HIGH'
            market_impact = 'SIGNIFICANT'
        
        else:  // >5% of daily volume
            depth_tier = 'VERY_SHALLOW'
            expected_slippage = 'VERY_HIGH'
            market_impact = 'SEVERE'
        
        return {
            'volume_ratio': volume_ratio,
            'depth_tier': depth_tier,
            'expected_slippage': expected_slippage,
            'market_impact': market_impact,
            'recommended_max_ratio': 0.01,  // Don't exceed 1% of daily volume
            'liquidity_warning': volume_ratio > 0.01
        }
    
    def estimate_optimal_execution(self, total_volume: float,
                                 time_horizon_hours: float = 1.0,
                                 risk_aversion: float = 0.1) -> Dict:
        """
        Estimate optimal execution strategy.
        
        Based on Almgren-Chriss optimal execution model.
        
        Args:
            total_volume: Total volume to execute
            time_horizon_hours: Time horizon for execution
            risk_aversion: Risk aversion parameter (0=risk neutral, >0=risk averse)
            
        Returns:
            Optimal execution plan
        """
        // Convert to daily volume ratio
        volume_ratio = total_volume / self.params.daily_volume
        
        // Calculate temporary and permanent impact for entire volume
        temp_impact = self._calculate_temporary_impact(volume_ratio, 'MARKET')
        perm_impact = self._calculate_permanent_impact(volume_ratio, 'MARKET')
        
        // Optimal trading rate (simplified Almgren-Chriss)
        // In practice, this would solve the ODE
        optimal_rate = min(1.0, 1.0 / (1.0 + risk_aversion * time_horizon_hours))
        
        // Execution strategies comparison
        strategies = ['MARKET', 'TWAP', 'VWAP', 'POV', 'LIMIT']
        strategy_results = []
        
        for strategy in strategies:
            strategy_temp = self._calculate_temporary_impact(volume_ratio, strategy)
            strategy_perm = self._calculate_permanent_impact(volume_ratio, strategy)
            strategy_total = strategy_temp + strategy_perm
            
            strategy_results.append({
                'strategy': strategy,
                'total_impact_bps': strategy_total,
                'temporary_bps': strategy_temp,
                'permanent_bps': strategy_perm,
                'completion_confidence': self._get_completion_confidence(strategy),
                'market_risk_hours': self._get_market_risk(strategy, time_horizon_hours)
            })
        
        // Sort by total impact
        strategy_results.sort(key=lambda x: x['total_impact_bps'])
        
        return {
            'total_volume': total_volume,
            'time_horizon_hours': time_horizon_hours,
            'risk_aversion': risk_aversion,
            'market_impact_analysis': {
                'volume_ratio': volume_ratio,
                'full_market_impact_bps': temp_impact + perm_impact,
                'temporary_component_bps': temp_impact,
                'permanent_component_bps': perm_impact
            },
            'optimal_trading_rate': optimal_rate,
            'recommended_slices': max(1, int(total_volume * (1 - optimal_rate))),
            'strategy_comparison': strategy_results,
            'recommended_strategy': strategy_results[0]['strategy'],
            'liquidity_warnings': self._generate_liquidity_warnings(volume_ratio),
            'execution_plan': self._generate_execution_plan(
                total_volume, optimal_rate, time_horizon_hours
            )
        }
    
    def _get_completion_confidence(self, strategy: str) -> float:
        """Get confidence of order completion for strategy."""
        confidence_map = {
            'MARKET': 1.0,    // Market orders always execute
            'VWAP': 0.9,      // High completion for VWAP
            'TWAP': 0.8,      // Good completion for TWAP
            'POV': 0.7,       // Moderate completion for POV
            'LIMIT': 0.5      // Low completion for limits
        }
        return confidence_map.get(strategy, 0.5)
    
    def _get_market_risk(self, strategy: str, time_horizon: float) -> float:
        """Estimate market risk exposure for strategy."""
        // Longer execution times have more market risk
        exposure_hours = {
            'MARKET': 0.1,    // Almost instant
            'VWAP': time_horizon * 0.8,
            'TWAP': time_horizon,
            'POV': time_horizon * 0.9,
            'LIMIT': time_horizon * 2.0  // Limits may sit longer
        }
        return exposure_hours.get(strategy, time_horizon)
    
    def _generate_liquidity_warnings(self, volume_ratio: float) -> List[str]:
        """Generate liquidity warnings based on volume ratio."""
        warnings = []
        
        if volume_ratio > 0.05:
            warnings.append("CRITICAL: Trade exceeds 5% of daily volume")
            warnings.append("Expect severe market impact and potential price manipulation concerns")
        
        elif volume_ratio > 0.01:
            warnings.append("WARNING: Trade exceeds 1% of daily volume")
            warnings.append("Consider splitting into smaller orders")
        
        elif volume_ratio > 0.001:
            warnings.append("INFO: Trade is 0.1%-1% of daily volume")
            warnings.append("Normal market impact expected")
        
        if volume_ratio > 0.01 and self.params.volatility > 0.05:
            warnings.append("HIGH VOLATILITY: Consider reducing size or using adaptive strategy")
        
        return warnings
    
    def _generate_execution_plan(self, total_volume: float, optimal_rate: float,
                               time_horizon_hours: float) -> Dict:
        """Generate detailed execution plan."""
        n_slices = max(1, int(total_volume * (1 - optimal_rate)))
        slice_volume = total_volume / n_slices
        
        // Generate slice schedule
        slices = []
        for i in range(n_slices):
            slice_time = (i / n_slices) * time_horizon_hours
            
            // Calculate impact for this slice
            slice_ratio = slice_volume / self.params.daily_volume
            slice_temp = self._calculate_temporary_impact(slice_ratio, 'MARKET')
            slice_perm = self._calculate_permanent_impact(slice_ratio, 'MARKET')
            
            slices.append({
                'slice_number': i + 1,
                'volume': slice_volume,
                'time_hours': slice_time,
                'cumulative_volume': (i + 1) * slice_volume,
                'expected_impact_bps': slice_temp + slice_perm,
                'slice_impact_usd': (slice_temp + slice_perm) / 10000 * slice_volume
            })
        
        return {
            'n_slices': n_slices,
            'slice_volume': slice_volume,
            'total_execution_time_hours': time_horizon_hours,
            'avg_slice_interval_hours': time_horizon_hours / n_slices,
            'slices': slices,
            'total_expected_impact_usd': sum(s['slice_impact_usd'] for s in slices),
            'completion_confidence': min(0.99, 0.7 + 0.3 * (n_slices / 10))
        }
    
    def get_impact_statistics(self) -> Dict:
        """Get statistics on historical impacts."""
        if not self.impact_history:
            return {}
        
        total_impacts = [h['impacts_bps']['total'] for h in self.impact_history]
        temp_impacts = [h['impacts_bps']['temporary'] for h in self.impact_history]
        perm_impacts = [h['impacts_bps']['permanent'] for h in self.impact_history]
        volume_ratios = [h['volume_ratio'] for h in self.impact_history]
        
        return {
            'symbol': self.symbol,
            'n_trades_analyzed': len(self.impact_history),
            'impact_statistics_bps': {
                'total_mean': np.mean(total_impacts),
                'total_std': np.std(total_impacts) if len(total_impacts) > 1 else 0.0,
                'temporary_mean': np.mean(temp_impacts),
                'permanent_mean': np.mean(perm_impacts),
                'temporary_vs_permanent_ratio': np.mean(temp_impacts) / np.mean(perm_impacts) 
                                               if np.mean(perm_impacts) > 0 else 0.0
            },
            'volume_statistics': {
                'mean_volume_ratio': np.mean(volume_ratios),
                'max_volume_ratio': max(volume_ratios) if volume_ratios else 0.0,
                'volume_impact_correlation': np.corrcoef(volume_ratios, total_impacts)[0, 1] 
                                           if len(volume_ratios) > 1 else 0.0
            },
            'model_parameters': {
                'temp_kappa': self.params.temp_kappa,
                'temp_gamma': self.params.temp_gamma,
                'temp_decay_rate': self.params.temp_decay_rate,
                'perm_eta': self.params.perm_eta,
                'perm_beta': self.params.perm_beta,
                'daily_volume': self.params.daily_volume,
                'volatility': self.params.volatility,
                'spread_bps': self.params.spread_bps
            }
        }