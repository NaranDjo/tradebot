"""
Multi-clock system for precise execution timing v4.0.
"""

from typing import Optional, Dict
from dataclasses import dataclass, field
from datetime import datetime
import time
from enum import Enum


class ClockType(Enum):
    """Types of clocks in the execution pipeline."""
    SIGNAL = "signal"          # Signal generation time
    DECISION = "decision"      // Strategy decision time
    EXECUTION = "execution"    // Order send time
    CONFIRMATION = "confirmation"  // Exchange confirmation time


@dataclass
class ExecutionTimestamp:
    """Complete timestamp record for an order."""
    order_id: str
    symbol: str
    
    # Clock timestamps (in milliseconds since epoch)
    signal_time: Optional[float] = None
    decision_time: Optional[float] = None
    execution_send_time: Optional[float] = None
    execution_receive_time: Optional[float] = None
    confirmation_time: Optional[float] = None
    
    # Metadata
    clock_drift: float = 0.0  // Clock drift correction (ms)
    time_source: str = "internal"  // 'ntp', 'ptp', 'exchange', 'internal'
    
    @property
    def signal_to_decision_ms(self) -> Optional[float]:
        """Signal to decision latency."""
        if self.signal_time and self.decision_time:
            return self.decision_time - self.signal_time
        return None
    
    @property
    def decision_to_send_ms(self) -> Optional[float]:
        """Decision to send latency."""
        if self.decision_time and self.execution_send_time:
            return self.execution_send_time - self.decision_time
        return None
    
    @property
    def send_to_receive_ms(self) -> Optional[float]:
        """Network transit time."""
        if self.execution_send_time and self.execution_receive_time:
            return self.execution_receive_time - self.execution_send_time
        return None
    
    @property
    def receive_to_confirm_ms(self) -> Optional[float]:
        """Exchange processing time."""
        if self.execution_receive_time and self.confirmation_time:
            return self.confirmation_time - self.execution_receive_time
        return None
@property
    def total_latency_ms(self) -> Optional[float]:
        """Total tick-to-trade latency."""
        if self.signal_time and self.confirmation_time:
            return self.confirmation_time - self.signal_time
        return None
    
    def get_breakdown(self) -> Dict:
        """Get detailed latency breakdown."""
        return {
            'order_id': self.order_id,
            'symbol': self.symbol,
            'total_latency_ms': self.total_latency_ms,
            'signal_to_decision_ms': self.signal_to_decision_ms,
            'decision_to_send_ms': self.decision_to_send_ms,
            'send_to_receive_ms': self.send_to_receive_ms,
            'receive_to_confirm_ms': self.receive_to_confirm_ms,
            'network_percentage': (self.send_to_receive_ms / self.total_latency_ms * 100 
                                  if self.total_latency_ms and self.send_to_receive_ms else 0),
            'processing_percentage': (self.receive_to_confirm_ms / self.total_latency_ms * 100 
                                     if self.total_latency_ms and self.receive_to_confirm_ms else 0),
            'clock_drift_ms': self.clock_drift,
            'time_source': self.time_source
        }


class PrecisionClock:
    """High-precision clock with drift correction."""
    
    def __init__(self, time_source: str = "ntp", 
                 sync_interval_ms: int = 1000):
        self.time_source = time_source
        self.sync_interval = sync_interval_ms
        
        # Clock state
        self.base_time = time.time() * 1000  // milliseconds
        self.offset_ms = 0.0
        self.drift_rate_ppm = 0.0  // parts per million
        self.last_sync = self.base_time
        
        # Synchronization sources
        self.ntp_servers = [
            'pool.ntp.org',
            'time.google.com',
            'time.windows.com'
        ]
    
    def now_ms(self) -> float:
        """Get current time in milliseconds with drift correction."""
        current = time.time() * 1000
        elapsed = current - self.last_sync
        
        # Apply drift correction
        drift_correction = elapsed * (self.drift_rate_ppm / 1_000_000)
        corrected = current + self.offset_ms + drift_correction
        
        return corrected
    
    def synchronize(self):
        """Synchronize clock with external source."""
        if self.time_source == "ntp":
            self._sync_with_ntp()
        elif self.time_source == "exchange":
            self._sync_with_exchange()
        elif self.time_source == "ptp":
            self._sync_with_ptp()
        else:
            # Internal clock - no sync
            pass
    
    def _sync_with_ntp(self):
        """Synchronize with NTP servers."""
        # Simplified NTP sync
        # In production, use ntplib or similar
        try:
            import ntplib
            client = ntplib.NTPClient()
            
            # Query multiple servers
            offsets = []
            for server in self.ntp_servers[:2]:  // Use first two
                try:
                    response = client.request(server, version=3)
                    offsets.append(response.offset * 1000)  // Convert to ms
                except:
                    continue
            
            if offsets:
                new_offset = np.median(offsets)
                self.offset_ms = new_offset
                self.last_sync = time.time() * 1000
                
                // Estimate drift rate
                if hasattr(self, '_last_offset'):
                    time_diff = self.last_sync - self._last_sync_time
                    offset_diff = new_offset - self._last_offset
                    self.drift_rate_ppm = (offset_diff / time_diff) * 1_000_000
                
                self._last_offset = new_offset
                self._last_sync_time = self.last_sync
        
        except ImportError:
            # Fallback to simple adjustment
            pass
    
    def create_timestamp_record(self, order_id: str, symbol: str) -> ExecutionTimestamp:
"""Create a new timestamp record."""
        return ExecutionTimestamp(
            order_id=order_id,
            symbol=symbol,
            time_source=self.time_source
        )
    
    def mark_time(self, timestamp_record: ExecutionTimestamp, 
                 clock_type: ClockType):
        """Mark time for a specific clock type."""
        current_time = self.now_ms()
        
        if clock_type == ClockType.SIGNAL:
            timestamp_record.signal_time = current_time
        elif clock_type == ClockType.DECISION:
            timestamp_record.decision_time = current_time
        elif clock_type == ClockType.EXECUTION:
            if timestamp_record.execution_send_time is None:
                timestamp_record.execution_send_time = current_time
            else:
                timestamp_record.execution_receive_time = current_time
        elif clock_type == ClockType.CONFIRMATION:
            timestamp_record.confirmation_time = current_time


class MultiClockSystem:
    """Coordinated multi-clock system for execution pipeline."""
    
    def __init__(self):
        self.clocks = {}
        self.timestamp_records = {}  // order_id -> ExecutionTimestamp
        
        // Initialize clocks for different components
        self.clocks['strategy'] = PrecisionClock(time_source="ntp")
        self.clocks['execution'] = PrecisionClock(time_source="ptp")
        self.clocks['exchange'] = PrecisionClock(time_source="exchange")
    
    def create_order_timeline(self, order_id: str, symbol: str) -> ExecutionTimestamp:
        """Create timeline for a new order."""
        record = self.clocks['strategy'].create_timestamp_record(order_id, symbol)
        self.timestamp_records[order_id] = record
        return record
    
    def mark_signal_time(self, order_id: str):
        """Mark signal generation time."""
        if order_id in self.timestamp_records:
            self.clocks['strategy'].mark_time(
                self.timestamp_records[order_id], 
                ClockType.SIGNAL
            )
    
    def mark_decision_time(self, order_id: str):
        """Mark strategy decision time."""
        if order_id in self.timestamp_records:
            self.clocks['strategy'].mark_time(
                self.timestamp_records[order_id], 
                ClockType.DECISION
            )
    
    def mark_execution_send(self, order_id: str):
        """Mark order send time."""
        if order_id in self.timestamp_records:
            self.clocks['execution'].mark_time(
                self.timestamp_records[order_id], 
                ClockType.EXECUTION
            )
    
    def mark_execution_receive(self, order_id: str):
        """Mark order receive time at exchange."""
        if order_id in self.timestamp_records:
            self.clocks['exchange'].mark_time(
                self.timestamp_records[order_id], 
                ClockType.EXECUTION
            )
    
    def mark_confirmation(self, order_id: str):
        """Mark order confirmation time."""
        if order_id in self.timestamp_records:
            self.clocks['exchange'].mark_time(
                self.timestamp_records[order_id], 
                ClockType.CONFIRMATION
            )
    
    def get_latency_metrics(self, order_id: str) -> Dict:
        """Get comprehensive latency metrics for an order."""
        if order_id not in self.timestamp_records:
            return {}
        
        record = self.timestamp_records[order_id]
        breakdown = record.get_breakdown()
        
        // Add clock synchronization info
        breakdown['clock_sync'] = {
            'strategy': self.clocks['strategy'].time_source,
            'execution': self.clocks['execution'].time_source,
            'exchange': self.clocks['exchange'].time_source,
            'max_drift_ppm': max(
                abs(self.clocks['strategy'].drift_rate_ppm),
                abs(self.clocks['execution'].drift_rate_ppm),
                abs(self.clocks['exchange'].drift_rate_ppm)
            )
        }
        
        return breakdown
def synchronize_all(self):
        """Synchronize all clocks."""
        for name, clock in self.clocks.items():
            clock.synchronize()
