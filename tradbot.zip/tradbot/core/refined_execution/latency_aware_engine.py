"""
Latency-aware execution engine v4.0.
Integrates all latency models and adverse selection components.
"""

from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
import numpy as np
from datetime import datetime

from .clocks import MultiClockSystem, ClockType
from ..execution_latency.exchange_latency import ExchangeLatencyModel, ProtocolType, ExchangeTier
from ..execution_latency.network_latency import NetworkTopology
from ..execution_latency.queue_model import VirtualOrderBook, MatchingAlgorithm
from ..adverse_selection.toxicity_model import VPINCalculator
from ..adverse_selection.alpha_decay import AlphaDecayModel


@dataclass
class LatencyAwareOrder:
    """Enhanced order with latency tracking."""
    order_id: str
    symbol: str
    direction: str  # 'BUY' or 'SELL'
    order_type: str  # 'MARKET', 'LIMIT'
    price: float
    size: float
    
    # Latency tracking
    clock_system: Optional[MultiClockSystem] = None
    timestamp_record: Optional = None
    
    # Prediction fields
    expected_latency_ms: float = 0.0
    expected_slippage_bps: float = 0.0
    adverse_selection_risk: float = 0.0
    alpha_decay_loss_bps: float = 0.0
    
    def __post_init__(self):
        if self.clock_system:
            self.timestamp_record = self.clock_system.create_order_timeline(
                self.order_id, self.symbol
            )
    
    def mark_signal(self):
        """Mark signal time."""
        if self.clock_system:
            self.clock_system.mark_signal_time(self.order_id)
    
    def mark_decision(self):
        """Mark decision time."""
        if self.clock_system:
            self.clock_system.mark_decision_time(self.order_id)
    
    def mark_send(self):
        """Mark send time."""
        if self.clock_system:
            self.clock_system.mark_execution_send(self.order_id)
    
    def mark_receive(self):
        """Mark receive time."""
        if self.clock_system:
            self.clock_system.mark_execution_receive(self.order_id)
    
    def mark_confirmation(self):
        """Mark confirmation time."""
        if self.clock_system:
            self.clock_system.mark_confirmation(self.order_id)


class LatencyAwareExecutionEngine:
    """
    Main execution engine with full latency awareness.
    """
    
    def __init__(self, 
                 exchange: str = "binance",
                 client_location: str = "nyc",
                 exchange_location: str = "sg",
                 tier: ExchangeTier = ExchangeTier.INSTITUTIONAL,
                 protocol: ProtocolType = ProtocolType.FIX,
                 matching_algorithm: MatchingAlgorithm = MatchingAlgorithm.PRICE_TIME):
        
        // Core components
        self.clock_system = MultiClockSystem()
        self.exchange_latency = ExchangeLatencyModel(exchange, tier, protocol)
        self.network_latency = NetworkTopology(client_location, exchange_location)
        self.order_book = VirtualOrderBook("BTCUSDT", matching_algorithm)
        self.vpin_calculator = VPINCalculator()
        self.alpha_decay = AlphaDecayModel()
        
        // Statistics
        self.order_history = []
        self.latency_stats = {
            'total_orders': 0,
            'avg_total_latency_ms': 0.0,
            'avg_network_latency_ms': 0.0,
            'avg_exchange_latency_ms': 0.0,
            'latency_distribution': []
        }
        
        // Configuration
        self.max_adverse_risk = 0.4  // Maximum adverse selection probability
        self.max_alpha_decay_bps = 20.0  // Maximum alpha decay in bps
        
    def process_order(self, order: LatencyAwareOrder) -> Dict:
        """
        Process an order with full latency awareness.
        
        Returns:
            Execution results with detailed metrics
        """
        // 1. Signal time
        order.mark_signal()
        
        // 2.
Calculate expected latency
        expected_latency = self._calculate_expected_latency(order)
        order.expected_latency_ms = expected_latency
        
        // 3. Calculate adverse selection risk
        adverse_risk = self._calculate_adverse_selection_risk(order)
        order.adverse_selection_risk = adverse_risk['adverse_selection_probability']
        
        // 4. Calculate alpha decay
        alpha_decay = self._calculate_alpha_decay(order, expected_latency)
        order.alpha_decay_loss_bps = alpha_decay
        
        // 5. Decision time
        order.mark_decision()
        
        // 6. Check if order should proceed
        should_proceed, reject_reason = self._should_execute_order(order)
        
        if not should_proceed:
            return {
                'executed': False,
                'order_id': order.order_id,
                'reject_reason': reject_reason,
                'adverse_risk': adverse_risk,
                'alpha_decay_bps': alpha_decay,
                'expected_latency_ms': expected_latency
            }
        
        // 7. Simulate network latency
        network_delay = self._simulate_network_delay()
        
        // 8. Mark send time
        order.mark_send()
        
        // 9. Simulate exchange processing
        exchange_delay = self._simulate_exchange_delay(order)
        
        // 10. Mark receive time
        order.mark_receive()
        
        // 11. Execute in order book
        execution_result = self._execute_in_order_book(order)
        
        // 12. Simulate confirmation delay
        confirmation_delay = self._simulate_confirmation_delay()
        
        // 13. Mark confirmation time
        order.mark_confirmation()
        
        // 14. Calculate realized metrics
        realized_metrics = self._calculate_realized_metrics(order, execution_result)
        
        // 15. Update statistics
        self._update_statistics(order, realized_metrics)
        
        return {
            'executed': True,
            'order_id': order.order_id,
            'execution_result': execution_result,
            'latency_breakdown': self.clock_system.get_latency_metrics(order.order_id),
            'expected_metrics': {
                'latency_ms': expected_latency,
                'adverse_risk': adverse_risk,
                'alpha_decay_bps': alpha_decay
            },
            'realized_metrics': realized_metrics,
            'adverse_selection_loss': realized_metrics.get('adverse_selection_loss_bps', 0.0),
            'alpha_decay_realized': realized_metrics.get('alpha_decay_realized_bps', 0.0)
        }
    
    def _calculate_expected_latency(self, order: LatencyAwareOrder) -> float:
        """Calculate expected total latency."""
        // Network RTT
        network_rtt = self.network_latency.get_round_trip_latency()
        
        // Exchange processing
        exchange_latency = self.exchange_latency.get_order_latency(
            order.order_type.lower(), order.size
        )
        
        // Queue time (if limit order)
        queue_time = 0.0
        if order.order_type == 'LIMIT':
            // Estimate queue position
            bid_ask = self.order_book.get_best_bid_ask()
            if order.direction == 'BUY':
                if bid_ask[1] and order.price >= bid_ask[1]:
                    // Marketable limit order
                    queue_time = 0.0
                else:
                    // Non-marketable - estimate queue time
                    queue_time = np.random.exponential(1000)  // ms
            else:  // SELL
                if bid_ask[0] and order.price <= bid_ask[0]:
                    queue_time = 0.0
                else:
                    queue_time = np.random.exponential(1000)
        
        total = network_rtt + exchange_latency + queue_time
        return total
    
    def _calculate_adverse_selection_risk(self, order: LatencyAwareOrder) -> Dict:
        """Calculate adverse selection risk using VPIN."""
        prediction = self.vpin_calculator.predict_adverse_selection(
order.size, 
            'buy' if order.direction == 'BUY' else 'sell'
        )
        return prediction
    
    def _calculate_alpha_decay(self, order: LatencyAwareOrder, 
                             expected_latency_ms: float) -> float:
        """Calculate alpha decay due to latency."""
        // Convert ms to hours
        latency_hours = expected_latency_ms / (1000 * 3600)
        
        // Get alpha decay
        alpha0 = 10.0  // Base alpha in bps (example)
        decayed_alpha = self.alpha_decay.calculate_decay(
            alpha0, 
            latency_hours
        )
        
        decay_loss = alpha0 - decayed_alpha
        return decay_loss
    
    def _should_execute_order(self, order: LatencyAwareOrder) -> Tuple[bool, str]:
        """Determine if order should be executed based on risks."""
        reasons = []
        
        // Check adverse selection risk
        if order.adverse_selection_risk > self.max_adverse_risk:
            reasons.append(f"High adverse selection risk: {order.adverse_selection_risk:.2%}")
        
        // Check alpha decay
        if order.alpha_decay_loss_bps > self.max_alpha_decay_bps:
            reasons.append(f"High alpha decay: {order.alpha_decay_loss_bps:.2f} bps")
        
        // Check expected latency
        if order.expected_latency_ms > 1000:  // 1 second threshold
            reasons.append(f"High expected latency: {order.expected_latency_ms:.0f} ms")
        
        if reasons:
            return False, "; ".join(reasons)
        
        return True, ""
    
    def _simulate_network_delay(self) -> float:
        """Simulate network transmission delay."""
        delay = np.random.normal(
            self.network_latency.link.estimated_latency_ms,
            self.network_latency.link.estimated_latency_ms * 0.1
        )
        return max(0.1, delay)
    
    def _simulate_exchange_delay(self, order: LatencyAwareOrder) -> float:
        """Simulate exchange processing delay."""
        delay = self.exchange_latency.get_order_latency(
            order.order_type.lower(), 
            order.size
        )
        return delay
    
    def _execute_in_order_book(self, order: LatencyAwareOrder) -> Dict:
        """Execute order in virtual order book."""
        if order.order_type == 'MARKET':
            avg_price, matched_orders = self.order_book.match_market_order(
                'buy' if order.direction == 'BUY' else 'sell',
                order.size,
                time.time() * 1000
            )
            
            executed_size = sum(vol for _, vol, _ in matched_orders)
            
            return {
                'execution_type': 'MARKET',
                'avg_price': avg_price,
                'executed_size': executed_size,
                'matched_orders': matched_orders,
                'slippage_bps': ((avg_price - order.price) / order.price * 10000 
                               if order.price > 0 else 0.0)
            }
        else:  // LIMIT
            // Add to order book
            self.order_book.add_limit_order(
                order.order_id,
                'buy' if order.direction == 'BUY' else 'sell',
                order.price,
                order.size,
                time.time() * 1000
            )
            
            return {
                'execution_type': 'LIMIT_PENDING',
                'price': order.price,
                'size': order.size,
                'status': 'QUEUED'
            }
    
    def _simulate_confirmation_delay(self) -> float:
        """Simulate confirmation delay from exchange."""
        return np.random.exponential(5)  // Average 5ms
    
    def _calculate_realized_metrics(self, order: LatencyAwareOrder, 
                                  execution_result: Dict) -> Dict:
        """Calculate realized metrics after execution."""
        // Get latency breakdown
        latency_metrics = self.clock_system.get_latency_metrics(order.order_id)
        
        // Calculate realized slippage
        realized_slippage = 0.0
        if execution_result.
get('execution_type') == 'MARKET':
            realized_slippage = execution_result.get('slippage_bps', 0.0)
        
        // Calculate adverse selection loss
        expected_slippage = order.expected_slippage_bps
        adverse_loss = max(0, realized_slippage - expected_slippage)
        
        // Calculate realized alpha decay
        total_latency_ms = latency_metrics.get('total_latency_ms', 0)
        latency_hours = total_latency_ms / (1000 * 3600)
        alpha0 = 10.0  // Base alpha
        realized_alpha = self.alpha_decay.calculate_decay(alpha0, latency_hours)
        realized_decay = alpha0 - realized_alpha
        
        return {
            'total_latency_ms': total_latency_ms,
            'realized_slippage_bps': realized_slippage,
            'expected_slippage_bps': expected_slippage,
            'adverse_selection_loss_bps': adverse_loss,
            'alpha_decay_realized_bps': realized_decay,
            'latency_breakdown': latency_metrics
        }
    
    def _update_statistics(self, order: LatencyAwareOrder, 
                          realized_metrics: Dict):
        """Update execution statistics."""
        self.order_history.append({
            'order_id': order.order_id,
            'timestamp': datetime.now().isoformat(),
            'order': order,
            'metrics': realized_metrics
        })
        
        // Update latency stats
        total_latency = realized_metrics.get('total_latency_ms', 0)
        self.latency_stats['total_orders'] += 1
        self.latency_stats['latency_distribution'].append(total_latency)
        
        // Recalculate averages
        n = self.latency_stats['total_orders']
        self.latency_stats['avg_total_latency_ms'] = (
            self.latency_stats['avg_total_latency_ms'] * (n-1) + total_latency
        ) / n
        
    def get_performance_report(self) -> Dict:
        """Get comprehensive performance report."""
        if not self.order_history:
            return {}
        
        executed_orders = [h for h in self.order_history 
                          if h['metrics'].get('execution_type') != 'LIMIT_PENDING']
        
        if not executed_orders:
            return {}
        
        adverse_losses = [h['metrics'].get('adverse_selection_loss_bps', 0) 
                         for h in executed_orders]
        alpha_decays = [h['metrics'].get('alpha_decay_realized_bps', 0) 
                       for h in executed_orders]
        latencies = [h['metrics'].get('total_latency_ms', 0) 
                    for h in executed_orders]
        
        return {
            'summary': {
                'total_orders': len(self.order_history),
                'executed_orders': len(executed_orders),
                'rejected_orders': len(self.order_history) - len(executed_orders),
                'avg_adverse_loss_bps': np.mean(adverse_losses) if adverse_losses else 0.0,
                'avg_alpha_decay_bps': np.mean(alpha_decays) if alpha_decays else 0.0,
                'avg_latency_ms': np.mean(latencies) if latencies else 0.0,
                'total_adverse_loss_bps': sum(adverse_losses),
                'total_alpha_decay_bps': sum(alpha_decays)
            },
            'latency_stats': self.latency_stats,
            'vpin_metrics': self.vpin_calculator.get_toxic_flow_metrics(),
            'recommendations': self._generate_recommendations()
        }
    
    def _generate_recommendations(self) -> List[str]:
        """Generate recommendations based on performance."""
        recommendations = []
        
        report = self.get_performance_report()
        if not report:
            return recommendations
        
        summary = report['summary']
        
        if summary['avg_adverse_loss_bps'] > 5.0:
            recommendations.append(
                "Consider reducing order sizes or avoiding high-toxicity periods"
            )
        
        if summary['avg_alpha_decay_bps'] > summary['avg_adverse_loss_bps']:
            recommendations.append(
"Focus on reducing execution latency to minimize alpha decay"
            )
        
        if self.latency_stats['avg_total_latency_ms'] > 500:
            recommendations.append(
                "Consider co-location or improved network infrastructure"
            )
        
        return recommendations
