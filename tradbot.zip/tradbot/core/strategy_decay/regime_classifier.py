"""
Market regime classification v4.0.
Identifies and classifies different market regimes.
"""

import numpy as np
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from enum import Enum
from scipy import stats, signal
import warnings
warnings.filterwarnings('ignore')


class MarketRegime(Enum):
    """Market regime classifications."""
    HIGH_VOLATILITY = "high_volatility"
    LOW_VOLATILITY = "low_volatility"
    TRENDING_UP = "trending_up"
    TRENDING_DOWN = "trending_down"
    MEAN_REVERSION = "mean_reversion"
    SIDEWAYS = "sideways"
    CRASH = "crash"
    RALLY = "rally"
    HIGH_FREQUENCY = "high_frequency"  // HFT-dominated
    NEWS_DRIVEN = "news_driven"
    LIQUIDITY_CRISIS = "liquidity_crisis"


@dataclass
class RegimeFeatures:
    """Features for regime classification."""
    # Volatility features
    volatility_1h: float
    volatility_1d: float
    volatility_ratio: float  // Short-term / long-term
    
    # Trend features
    trend_strength: float
    trend_direction: float  // -1 to 1
    
    # Volume features
    volume_zscore: float
    volume_trend: float
    
    # Liquidity features
    spread_bps: float
    depth_imbalance: float
    
    # Return distribution features
    skewness: float
    kurtosis: float
    hurst_exponent: float
    
    # Additional features
    autocorrelation: float
    noise_ratio: float  // Signal-to-noise ratio
    
    def to_array(self) -> np.ndarray:
        """Convert features to numpy array."""
        return np.array([
            self.volatility_1h,
            self.volatility_1d,
            self.volatility_ratio,
            self.trend_strength,
            self.trend_direction,
            self.volume_zscore,
            self.volume_trend,
            self.spread_bps,
            self.depth_imbalance,
            self.skewness,
            self.kurtosis,
            self.hurst_exponent,
            self.autocorrelation,
            self.noise_ratio
        ])


class RegimeClassifier:
    """
    Classifies market regimes based on price and volume data.
    
    Uses a combination of statistical features and machine learning
    to identify current market regime.
    """
    
    def __init__(self, lookback_periods: int = 100,
                 classification_method: str = 'rules_based'):
        """
        Args:
            lookback_periods: Number of periods to analyze for regime
            classification_method: 'rules_based' or 'ml_based'
        """
        self.lookback_periods = lookback_periods
        self.classification_method = classification_method
        
        # Regime history
        self.regime_history: List[Dict] = []
        self.feature_history: List[RegimeFeatures] = []
        
        # For ML-based classification
        self.classifier = None
        if classification_method == 'ml_based':
            self._initialize_ml_classifier()
    
    def _initialize_ml_classifier(self):
        """Initialize machine learning classifier."""
        try:
            from sklearn.ensemble import RandomForestClassifier
            from sklearn.preprocessing import StandardScaler
            
            self.classifier = RandomForestClassifier(
                n_estimators=100,
                max_depth=10,
                random_state=42
            )
            self.scaler = StandardScaler()
            self.ml_initialized = False
        except ImportError:
            print("scikit-learn not available, falling back to rules-based classification")
            self.classification_method = 'rules_based'
            self.classifier = None
    
    def analyze_market_data(self, price_data: np.ndarray,
                           volume_data: np.ndarray,
                           spread_data: Optional[np.ndarray] = None,
                           timestamp: Optional[float] = None) -> Dict:
        """
        Analyze market data and classify regime.
        
        Args:
            price_data: Array of price values (most recent last)
            volume_data: Array of volume values
            spread_data: Array of bid-ask spreads (optional)
            timestamp: Current timestamp
            
        Returns:
            Regime classification results
        """
        if len(price_data) < self.lookback_periods:
            # Insufficient data
            return {
                'regime': MarketRegime.SIDEWAYS.value,
                'confidence': 0.0,
                'features': None,
                'insufficient_data': True
            }
        
        # Use most recent data
        recent_prices = price_data[-self.lookback_periods:]
        recent_volumes = volume_data[-self.lookback_periods:]
        
        if spread_data is not None and len(spread_data) >= self.lookback_periods:
            recent_spreads = spread_data[-self.lookback_periods:]
        else:
            recent_spreads = None
        
        # Calculate features
        features = self._calculate_features(recent_prices, recent_volumes, recent_spreads)
        self.feature_history.append(features)
        
        # Classify regime
        if self.classification_method == 'ml_based' and self.ml_initialized:
            regime, confidence = self._classify_ml(features)
        else:
            regime, confidence = self._classify_rules_based(features)
        
        # Create regime record
        regime_record = {
            'timestamp': timestamp if timestamp else len(self.regime_history),
            'regime': regime.value,
            'confidence': confidence,
            'features': features,
            'feature_vector': features.to_array().tolist()
        }
        
        self.regime_history.append(regime_record)
        
        # Generate regime insights
        insights = self._generate_regime_insights(regime, features, confidence)
        
        return {
            **regime_record,
            'insights': insights,
            'regime_duration': self._calculate_regime_duration(regime),
            'regime_transition_probability': self._calculate_transition_probability(regime)
        }
    
    def _calculate_features(self, prices: np.ndarray, volumes: np.ndarray,
                          spreads: Optional[np.ndarray]) -> RegimeFeatures:
        """Calculate regime classification features."""
        returns = np.diff(prices) / prices[:-1]
        
        # Volatility features
        volatility_1h = np.std(returns[-12:]) * np.sqrt(12) if len(returns) >= 12 else np.std(returns)
        volatility_1d = np.std(returns) * np.sqrt(len(returns))
        volatility_ratio = volatility_1h / volatility_1d if volatility_1d > 0 else 1.0
        
        # Trend features
        trend_strength, trend_direction = self._calculate_trend_features(prices)
        
        # Volume features
        volume_zscore = (volumes[-1] - np.mean(volumes)) / np.std(volumes) \
                       if np.std(volumes) > 0 else 0.0
        volume_trend = np.polyfit(range(len(volumes)), volumes, 1)[0] / np.mean(volumes) \
                      if np.mean(volumes) > 0 else 0.0
        
        # Liquidity features
        if spreads is not None:
            spread_bps = np.mean(spreads[-10:]) if len(spreads) >= 10 else np.mean(spreads)
            # Depth imbalance (simplified - would need order book data)
            depth_imbalance = 0.0
        else:
            spread_bps = 0.0
            depth_imbalance = 0.0
        
        # Return distribution features
        skewness = stats.skew(returns) if len(returns) > 2 else 0.0
        kurtosis = stats.kurtosis(returns) if len(returns) > 3 else 0.0
        hurst_exponent = self._calculate_hurst_exponent(prices)
        
        # Additional features
        autocorrelation = self._calculate_autocorrelation(returns)
        noise_ratio = self._calculate_noise_ratio(prices)
        
        return RegimeFeatures(
            volatility_1h=volatility_1h,
            volatility_1d=volatility_1d,
            volatility_ratio=volatility_ratio,
            trend_strength=trend_strength,
            trend_direction=trend_direction,
            volume_zscore=volume_zscore,
            volume_trend=volume_trend,
            spread_bps=spread_bps,
            depth_imbalance=depth_imbalance,
            skewness=skewness,
            kurtosis=kurtosis,
            hurst_exponent=hurst_exponent,
            autocorrelation=autocorrelation,
            noise_ratio=noise_ratio
        )
    
    def _calculate_trend_features(self, prices: np.ndarray) -> Tuple[float, float]:
        """Calculate trend strength and direction."""
        if len(prices) < 10:
            return 0.0, 0.0
        
        # Linear trend
        x = np.arange(len(prices))
        slope, intercept = np.polyfit(x, prices, 1)
        
        # R-squared as trend strength
        y_pred = slope * x + intercept
        ss_res = np.sum((prices - y_pred) ** 2)
        ss_tot = np.sum((prices - np.mean(prices)) ** 2)
        r_squared = 1 - (ss_res / ss_tot) if ss_tot > 0 else 0.0
        
        # Direction (-1 to 1)
        direction = np.sign(slope) * min(1.0, abs(slope / np.std(prices)) 
                                        if np.std(prices) > 0 else 0.0)
        
        return r_squared, direction
    
    def _calculate_hurst_exponent(self, prices: np.ndarray) -> float:
        """Calculate Hurst exponent for mean reversion/trend detection."""
        if len(prices) < 50:
            return 0.5  # Neutral
        
        # Rescaled range analysis (simplified)
        returns = np.diff(prices) / prices[:-1]
        n = len(returns)
        
        # Calculate R/S for different time lags
        lags = range(2, min(20, n // 2))
        rs_values = []
        
        for lag in lags:
            # Split into segments
            segments = n // lag
            if segments < 2:
                continue
            
            segment_rs = []
            for i in range(segments):
                segment = returns[i*lag:(i+1)*lag]
                if len(segment) < 2:
                    continue
                
                # Calculate mean adjusted series
                mean_segment = np.mean(segment)
                adjusted = segment - mean_segment
                cumulative = np.cumsum(adjusted)
                
                # Range
                R = np.max(cumulative) - np.min(cumulative)
                S = np.std(segment) if np.std(segment) > 0 else 1.0
                segment_rs.append(R / S)
            
            if segment_rs:
                rs_values.append(np.mean(segment_rs))
        
        if len(rs_values) < 3:
            return 0.5
        
        # Fit log(R/S) vs log(lag)
        log_lags = np.log(lags[:len(rs_values)])
        log_rs = np.log(rs_values)
        
        hurst, _ = np.polyfit(log_lags, log_rs, 1)
        
        return hurst
    
    def _calculate_autocorrelation(self, returns: np.ndarray, lag: int = 1) -> float:
        """Calculate autocorrelation of returns."""
        if len(returns) < lag * 2:
            return 0.0
        
        x = returns[:-lag]
        y = returns[lag:]
        
        correlation = np.corrcoef(x, y)[0, 1] if len(x) > 1 and len(y) > 1 else 0.0
        
        return correlation if not np.isnan(correlation) else 0.0
    
    def _calculate_noise_ratio(self, prices: np.ndarray) -> float:
        """Calculate signal-to-noise ratio."""
        if len(prices) < 20:
            return 1.0
        
        # High-pass filter to separate signal and noise
        returns = np.diff(prices) / prices[:-1]
        
        # Simple approach: trend vs noise
        detrended = signal.detrend(returns)
        
        signal_power = np.var(returns)
        noise_power = np.var(detrended)
        
        if noise_power == 0:
            return 10.0  # All signal
        
        return signal_power / noise_power
    
    def _classify_rules_based(self, features: RegimeFeatures) -> Tuple[MarketRegime, float]:
        """Classify regime using rule-based approach."""
        rules = []
        confidences = []
        
        # Rule 1: High volatility
        if features.volatility_1d > 0.05:  // 5% daily volatility
            if features.trend_direction > 0.3:
                rules.append(MarketRegime.CRASH)
                confidences.append(min(0.9, features.volatility_1d * 10))
            elif features.trend_direction < -0.3:
                rules.append(MarketRegime.RALLY)
                confidences.append(min(0.9, features.volatility_1d * 10))
            else:
                rules.append(MarketRegime.HIGH_VOLATILITY)
                confidences.append(min(0.8, features.volatility_1d * 8))
        
        # Rule 2: Low volatility
        elif features.volatility_1d < 0.01:  // 1% daily volatility
            rules.append(MarketRegime.LOW_VOLATILITY)
            confidences.append(min(0.9, (0.02 - features.volatility_1d) * 50))
        
        # Rule 3: Strong trend
        if features.trend_strength > 0.7:
            if features.trend_direction > 0.5:
                rules.append(MarketRegime.TRENDING_UP)
                confidences.append(features.trend_strength * 0.8)
            elif features.trend_direction < -0.5:
                rules.append(MarketRegime.TRENDING_DOWN)
                confidences.append(features.trend_strength * 0.8)
        
        # Rule 4: Mean reversion
        if features.hurst_exponent < 0.4:
            rules.append(MarketRegime.MEAN_REVERSION)
            confidences.append(min(0.8, (0.5 - features.hurst_exponent) * 2))
        
        # Rule 5: Sideways
        if features.trend_strength < 0.2 and features.volatility_1d < 0.02:
            rules.append(MarketRegime.SIDEWAYS)
            confidences.append(min(0.9, (0.3 - features.trend_strength) * 3))
        
        # Rule 6: High frequency (high autocorrelation)
        if features.autocorrelation > 0.3:
            rules.append(MarketRegime.HIGH_FREQUENCY)
            confidences.append(min(0.7, features.autocorrelation * 2))
        
        # Rule 7: News driven (high volume, high volatility)
        if features.volume_zscore > 2.0 and features.volatility_1h > 0.02:
            rules.append(MarketRegime.NEWS_DRIVEN)
            confidences.append(min(0.8, features.volume_zscore * 0.3))
        
        # Rule 8: Liquidity crisis (high spread, low volume)
        if features.spread_bps > 10.0 and features.volume_zscore < -1.0:
            rules.append(MarketRegime.LIQUIDITY_CRISIS)
            confidences.append(min(0.9, features.spread_bps / 20))
        
        # Default: based on trend
        if not rules:
            if abs(features.trend_direction) > 0.3:
                if features.trend_direction > 0:
                    rules.append(MarketRegime.TRENDING_UP)
                else:
                    rules.append(MarketRegime.TRENDING_DOWN)
                confidences.append(abs(features.trend_direction) * 0.7)
            else:
                rules.append(MarketRegime.SIDEWAYS)
                confidences.append(0.6)
        
        # Select regime with highest confidence
        best_idx = np.argmax(confidences)
        best_regime = rules[best_idx]
        best_confidence = confidences[best_idx]
        
        return best_regime, best_confidence
    
    def _classify_ml(self, features: RegimeFeatures) -> Tuple[MarketRegime, float]:
        """Classify regime using machine learning."""
        if not self.ml_initialized:
            # Not enough training data yet
            return self._classify_rules_based(features)
        
        # Scale features
        features_scaled = self.scaler.transform([features.to_array()])
        
        # Predict
        prediction = self.classifier.predict(features_scaled)[0]
        probabilities = self.classifier.predict_proba(features_scaled)[0]
        
        # Convert prediction to MarketRegime
        try:
            regime = MarketRegime(prediction)
            confidence = np.max(probabilities)
        except:
            # Fallback to rules-based
            return self._classify_rules_based(features)
        
        return regime, confidence
    
    def train_classifier(self, training_data: List[Tuple[RegimeFeatures, MarketRegime]]):
        """Train ML classifier on labeled data."""
        if self.classification_method != 'ml_based' or self.classifier is None:
            return False
        
        if len(training_data) < 100:
            print(f"Insufficient training data: {len(training_data)} samples (need at least 100)")
            return False
        
        # Prepare data
        X = np.array([f.to_array() for f, _ in training_data])
        y = np.array([r.value for _, r in training_data])
        
        # Scale features
        X_scaled = self.scaler.fit_transform(X)
        
        # Train classifier
        self.classifier.fit(X_scaled, y)
        self.ml_initialized = True
        
        # Calculate training accuracy
        accuracy = self.classifier.score(X_scaled, y)
        print(f"Regime classifier trained with {len(training_data)} samples, accuracy: {accuracy:.2%}")
        
        return True
    
    def _generate_regime_insights(self, regime: MarketRegime,
                                features: RegimeFeatures,
                                confidence: float) -> Dict:
        """Generate insights for the current regime."""
        insights = {
            'regime_description': self._get_regime_description(regime),
            'trading_implications': self._get_trading_implications(regime),
            'risk_level': self._get_risk_level(regime, features),
            'expected_duration': self._get_expected_duration(regime),
            'strategy_recommendations': self._get_strategy_recommendations(regime),
            'key_indicators': self._get_key_indicators(features)
        }
        
        return insights
    
    def _get_regime_description(self, regime: MarketRegime) -> str:
        """Get description of regime."""
        descriptions = {
            MarketRegime.HIGH_VOLATILITY: "High volatility with no clear trend",
            MarketRegime.LOW_VOLATILITY: "Low volatility, calm market conditions",
            MarketRegime.TRENDING_UP: "Strong upward trend",
            MarketRegime.TRENDING_DOWN: "Strong downward trend",
            MarketRegime.MEAN_REVERSION: "Mean-reverting price action",
            MarketRegime.SIDEWAYS: "Sideways consolidation",
            MarketRegime.CRASH: "Severe downward move with high volatility",
            MarketRegime.RALLY: "Strong upward move with high volatility",
            MarketRegime.HIGH_FREQUENCY: "HFT-dominated, short-term autocorrelation",
            MarketRegime.NEWS_DRIVEN: "News or event-driven price action",
            MarketRegime.LIQUIDITY_CRISIS: "Low liquidity, high spreads"
        }
        return descriptions.get(regime, "Unknown regime")
    
    def _get_trading_implications(self, regime: MarketRegime) -> List[str]:
        """Get trading implications for regime."""
        implications = {
            MarketRegime.HIGH_VOLATILITY: [
                "High option premiums",
                "Wider stops required",
                "Position sizing should be reduced"
            ],
            MarketRegime.LOW_VOLATILITY: [
                "Low option premiums",
                "Tighter stops possible",
                "Trend-following strategies may underperform"
            ],
            MarketRegime.TRENDING_UP: [
                "Trend-following strategies favorable",
                "Buy dips",
                "Avoid contrarian strategies"
            ],
            MarketRegime.TRENDING_DOWN: [
                "Short strategies favorable",
                "Sell rallies",
                "Avoid catching falling knives"
            ],
            MarketRegime.MEAN_REVERSION: [
                "Mean-reversion strategies favorable",
                "Fade extremes",
                "Set profit targets at mean"
            ],
            MarketRegime.SIDEWAYS: [
                "Range-bound strategies",
                "Sell resistance, buy support",
                "Avoid breakout strategies"
            ],
            MarketRegime.CRASH: [
                "Extreme risk - reduce exposure",
                "Defensive positioning",
                "Consider hedging"
            ],
            MarketRegime.RALLY: [
                "Momentum strategies",
                "Avoid early profit-taking",
                "Watch for exhaustion"
            ],
            MarketRegime.HIGH_FREQUENCY: [
                "Short-term strategies may work",
                "Market microstructure matters",
                "Latency critical"
            ],
            MarketRegime.NEWS_DRIVEN: [
                "Fundamental analysis important",
                "High headline risk",
                "Watch for overreactions"
            ],
            MarketRegime.LIQUIDITY_CRISIS: [
                "Extreme caution required",
                "Limit orders recommended",
                "Avoid large positions"
            ]
        }
        return implications.get(regime, ["Proceed with caution"])
    
    def _get_risk_level(self, regime: MarketRegime, features: RegimeFeatures) -> str:
        """Get risk level for regime."""
        risk_scores = {
            MarketRegime.CRASH: 10,
            MarketRegime.LIQUIDITY_CRISIS: 9,
            MarketRegime.HIGH_VOLATILITY: 8,
            MarketRegime.RALLY: 7,
            MarketRegime.TRENDING_DOWN: 6,
            MarketRegime.TRENDING_UP: 5,
            MarketRegime.NEWS_DRIVEN: 6,
            MarketRegime.HIGH_FREQUENCY: 4,
            MarketRegime.MEAN_REVERSION: 3,
            MarketRegime.SIDEWAYS: 2,
            MarketRegime.LOW_VOLATILITY: 1
        }
        
        base_risk = risk_scores.get(regime, 5)
        
        # Adjust for volatility
        if features.volatility_1d > 0.03:
            base_risk += 2
        elif features.volatility_1d < 0.01:
            base_risk -= 1
        
        # Categorize
        if base_risk >= 8:
            return "EXTREME"
        elif base_risk >= 6:
            return "HIGH"
        elif base_risk >= 4:
            return "MEDIUM"
        else:
            return "LOW"
    
    def _get_expected_duration(self, regime: MarketRegime) -> str:
        """Get expected duration of regime."""
        durations = {
            MarketRegime.HIGH_VOLATILITY: "Hours to days",
            MarketRegime.LOW_VOLATILITY: "Days to weeks",
            MarketRegime.TRENDING_UP: "Days to months",
            MarketRegime.TRENDING_DOWN: "Days to months",
            MarketRegime.MEAN_REVERSION: "Hours to days",
            MarketRegime.SIDEWAYS: "Days to weeks",
            MarketRegime.CRASH: "Hours to days",
            MarketRegime.RALLY: "Hours to days",
            MarketRegime.HIGH_FREQUENCY: "Minutes to hours",
            MarketRegime.NEWS_DRIVEN: "Minutes to hours",
            MarketRegime.LIQUIDITY_CRISIS: "Hours to days"
        }
        return durations.get(regime, "Variable")
    
    def _get_strategy_recommendations(self, regime: MarketRegime) -> List[str]:
        """Get strategy recommendations for regime."""
        recommendations = {
            MarketRegime.HIGH_VOLATILITY: [
                "Volatility strategies (straddles, strangles)",
                "Reduce position sizes",
                "Wider stops"
            ],
            MarketRegime.LOW_VOLATILITY: [
                "Theta decay strategies",
                "Iron condors",
                "Calendar spreads"
            ],
            MarketRegime.TRENDING_UP: [
                "Trend following",
                "Momentum strategies",
                "Buy and hold"
            ],
            MarketRegime.TRENDING_DOWN: [
                "Short selling",
                "Put options",
                "Inverse ETFs"
            ],
            MarketRegime.MEAN_REVERSION: [
                "Statistical arbitrage",
                "Pairs trading",
                "Oversold/overbought indicators"
            ],
            MarketRegime.SIDEWAYS: [
                "Range trading",
                "Straddle selling",
                "Butterfly spreads"
            ],
            MarketRegime.CRASH: [
                "Capital preservation",
                "Hedging",
                "Defensive positioning"
            ],
            MarketRegime.RALLY: [
                "Momentum continuation",
                "Breakout strategies",
                "Trailing stops"
            ],
            MarketRegime.HIGH_FREQUENCY: [
                "Latency-sensitive strategies",
                "Market making",
                "Statistical arbitrage"
            ],
            MarketRegime.NEWS_DRIVEN: [
                "Event-driven strategies",
                "News sentiment analysis",
                "Quick reaction systems"
            ],
            MarketRegime.LIQUIDITY_CRISIS: [
                "Avoid trading",
                "Limit orders only",
                "Extreme caution"
            ]
        }
        return recommendations.get(regime, ["Adapt strategy to conditions"])
    
    def _get_key_indicators(self, features: RegimeFeatures) -> Dict:
        """Get key indicators for current features."""
        return {
            'volatility_1d': f"{features.volatility_1d:.2%}",
            'trend_strength': f"{features.trend_strength:.2%}",
            'trend_direction': "UP" if features.trend_direction > 0.1 else 
                             "DOWN" if features.trend_direction < -0.1 else "NEUTRAL",
            'volume_anomaly': "HIGH" if features.volume_zscore > 2 else 
                            "LOW" if features.volume_zscore < -2 else "NORMAL",
            'mean_reversion_tendency': "HIGH" if features.hurst_exponent < 0.4 else 
                                      "LOW" if features.hurst_exponent > 0.6 else "NEUTRAL",
            'spread_conditions': "TIGHT" if features.spread_bps < 5 else 
                               "WIDE" if features.spread_bps > 15 else "NORMAL"
        }
    
    def _calculate_regime_duration(self, current_regime: MarketRegime) -> int:
        """Calculate how long current regime has been active."""
        if len(self.regime_history) < 2:
            return 1
        
        duration = 1
        for i in range(len(self.regime_history) - 2, -1, -1):
            if self.regime_history[i]['regime'] == current_regime.value:
                duration += 1
            else:
                break
        
        return duration
    
    def _calculate_transition_probability(self, current_regime: MarketRegime) -> Dict:
        """Calculate probability of transitioning to other regimes."""
        if len(self.regime_history) < 10:
            return {}
        
        # Count transitions
        transitions = {}
        total_transitions = 0
        
        for i in range(1, len(self.regime_history)):
            prev_regime = self.regime_history[i-1]['regime']
            curr_regime = self.regime_history[i]['regime']
            
            if prev_regime == current_regime.value:
                transitions[curr_regime] = transitions.get(curr_regime, 0) + 1
                total_transitions += 1
        
        # Calculate probabilities
        probabilities = {}
        for regime, count in transitions.items():
            probabilities[regime] = count / total_transitions if total_transitions > 0 else 0.0
        
        # Sort by probability
        sorted_probs = sorted(probabilities.items(), key=lambda x: x[1], reverse=True)
        
        return {
            'most_likely_transitions': sorted_probs[:3],
            'stability_probability': probabilities.get(current_regime.value, 0.0),
            'total_observed_transitions': total_transitions
        }
    
    def get_regime_statistics(self) -> Dict:
        """Get statistics on regime classifications."""
        if not self.regime_history:
            return {}
        
        # Count regimes
        regime_counts = {}
        regime_durations = []
        
        current_duration = 1
        for i in range(len(self.regime_history)):
            regime = self.regime_history[i]['regime']
            regime_counts[regime] = regime_counts.get(regime, 0) + 1
            
            if i > 0 and self.regime_history[i-1]['regime'] == regime:
                current_duration += 1
            else:
                if current_duration > 1:
                    regime_durations.append(current_duration)
                current_duration = 1
        
        if current_duration > 1:
            regime_durations.append(current_duration)
        
        # Calculate statistics
        total_periods = len(self.regime_history)
        avg_confidence = np.mean([r['confidence'] for r in self.regime_history])
        
        return {
            'total_periods_analyzed': total_periods,
            'regime_distribution': {
                regime: {
                    'count': count,
                    'percentage': count / total_periods * 100,
                    'avg_confidence': np.mean([r['confidence'] 
                                              for r in self.regime_history 
                                              if r['regime'] == regime])
                }
                for regime, count in regime_counts.items()
            },
            'regime_stability': {
                'avg_regime_duration': np.mean(regime_durations) if regime_durations else 1.0,
                'median_regime_duration': np.median(regime_durations) if regime_durations else 1.0,
                'max_regime_duration': max(regime_durations) if regime_durations else 1,
                'regime_volatility': np.std(list(regime_counts.values())) / np.mean(list(regime_counts.values())) 
                                   if regime_counts else 0.0
            },
            'classification_quality': {
                'avg_confidence': avg_confidence,
                'low_confidence_percentage': sum(1 for r in self.regime_history 
                                                if r['confidence'] < 0.5) / total_periods * 100,
                'high_confidence_percentage': sum(1 for r in self.regime_history 
                                                 if r['confidence'] > 0.8) / total_periods * 100
            },
            'current_regime': self.regime_history[-1] if self.regime_history else None,
            'regime_transition_matrix': self._build_transition_matrix()
        }
    
    def _build_transition_matrix(self) -> Dict:
        """Build regime transition probability matrix."""
        if len(self.regime_history) < 20:
            return {}
        
        # Get all unique regimes
        all_regimes = sorted(set(r['regime'] for r in self.regime_history))
        n_regimes = len(all_regimes)
        
        # Initialize transition counts
        transition_counts = {from_regime: {to_regime: 0 for to_regime in all_regimes} 
                           for from_regime in all_regimes}
        
        # Count transitions
        for i in range(1, len(self.regime_history)):
            from_regime = self.regime_history[i-1]['regime']
            to_regime = self.regime_history[i]['regime']
            transition_counts[from_regime][to_regime] += 1
        
        # Convert to probabilities
        transition_matrix = {}
        for from_regime in all_regimes:
            total = sum(transition_counts[from_regime].values())
            if total > 0:
                transition_matrix[from_regime] = {
                    to_regime: count / total
                    for to_regime, count in transition_counts[from_regime].items()
                }
        
        return transition_matrix