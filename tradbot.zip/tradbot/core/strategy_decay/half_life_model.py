"""
Signal half-life estimation and decay modeling v4.0.
"""

import numpy as np
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass
from scipy import optimize, stats
import pandas as pd
from datetime import datetime, timedelta


@dataclass
class SignalObservation:
    """Observation of a trading signal's performance."""
    signal_time: datetime
    signal_strength: float  // Initial alpha estimate
    entry_price: float
    exit_price: Optional[float] = None
    exit_time: Optional[datetime] = None
    realized_return: Optional[float] = None
    holding_period_hours: Optional[float] = None
    
    def calculate_return(self) -> float:
        """Calculate return if exit information available."""
        if self.exit_price and self.entry_price > 0:
            return (self.exit_price - self.entry_price) / self.entry_price
        return 0.0


class HalfLifeModel:
    """
    Models the half-life of trading signals using exponential decay.
    
    Based on: Alpha decay follows exponential pattern:
    α(t) = α₀ * exp(-λt)
    where λ = ln(2) / T_half
    """
    
    def __init__(self, min_observations: int = 50):
        self.min_observations = min_observations
        self.signal_history: List[SignalObservation] = []
        self.half_life_hours: Optional[float] = None
        self.decay_rate: Optional[float] = None
        self.confidence_interval: Optional[Tuple[float, float]] = None
        
    def add_signal(self, signal: SignalObservation):
        """Add a signal observation to the model."""
        self.signal_history.append(signal)
        
        // Recalculate half-life if enough observations
        if len(self.signal_history) >= self.min_observations:
            self._recalculate_half_life()
    
    def _recalculate_half_life(self):
        """Recalculate half-life from signal history."""
        // Filter signals with complete information
        complete_signals = [
            s for s in self.signal_history 
            if s.realized_return is not None and s.holding_period_hours is not None
        ]
        
        if len(complete_signals) < self.min_observations:
            return
        
        // Prepare data for fitting
        holding_periods = [s.holding_period_hours for s in complete_signals]
        returns = [s.realized_return for s in complete_signals]
        initial_alphas = [abs(s.signal_strength) for s in complete_signals]
        
        // Normalize returns by initial alpha
        normalized_returns = []
        for ret, alpha in zip(returns, initial_alphas):
            if alpha != 0:
                normalized_returns.append(ret / alpha)
            else:
                normalized_returns.append(0.0)
        
        // Fit exponential decay model
        try:
            // Define exponential decay function
            def decay_func(t, lambd):
                return np.exp(-lambd * t)
            
            // Fit using nonlinear least squares
            popt, pcov = optimize.curve_fit(
                decay_func,
                holding_periods,
                normalized_returns,
                p0=[0.01],  // Initial guess for λ
                maxfev=5000
            )
            
            lambd = popt[0]
            self.decay_rate = lambd
            
            // Calculate half-life: T_half = ln(2) / λ
            self.half_life_hours = np.log(2) / lambd if lambd > 0 else float('inf')
            
            // Calculate confidence intervals
            perr = np.sqrt(np.diag(pcov))
            half_life_err = (np.log(2) / (lambd**2)) * perr[0]
            self.confidence_interval = (
                self.half_life_hours - 1.96 * half_life_err,
                self.
half_life_hours + 1.96 * half_life_err
            )
            
        except (RuntimeError, ValueError) as e:
            // Fit failed, use robust estimation
            self._estimate_half_life_robust(holding_periods, normalized_returns)
    
    def _estimate_half_life_robust(self, holding_periods: List[float], 
                                  normalized_returns: List[float]):
        """Robust half-life estimation using quantile method."""
        // Bin observations by holding period
        bins = np.linspace(0, max(holding_periods), 10)
        bin_indices = np.digitize(holding_periods, bins)
        
        median_returns = []
        median_periods = []
        
        for i in range(1, len(bins)):
            mask = bin_indices == i
            if np.sum(mask) > 3:  // Minimum observations per bin
                median_returns.append(np.median(np.array(normalized_returns)[mask]))
                median_periods.append(np.median(np.array(holding_periods)[mask]))
        
        if len(median_returns) < 5:
            return
        
        // Find where returns decay to half
        max_return = np.max(median_returns)
        half_return = max_return / 2
        
        // Interpolate to find half-life
        if half_return < np.min(median_returns):
            self.half_life_hours = median_periods[-1]
        else:
            // Simple linear interpolation
            for i in range(len(median_returns)-1):
                if median_returns[i] >= half_return >= median_returns[i+1]:
                    // Linear interpolation
                    x1, y1 = median_periods[i], median_returns[i]
                    x2, y2 = median_periods[i+1], median_returns[i+1]
                    
                    t_half = x1 + (x2 - x1) * (half_return - y1) / (y2 - y1)
                    self.half_life_hours = t_half
                    break
        
        self.decay_rate = np.log(2) / self.half_life_hours if self.half_life_hours > 0 else 0.0
    
    def predict_remaining_alpha(self, initial_alpha: float, 
                              elapsed_hours: float) -> float:
        """
        Predict remaining alpha after elapsed time.
        
        Args:
            initial_alpha: Initial alpha strength
            elapsed_hours: Time elapsed since signal
            
        Returns:
            Estimated remaining alpha
        """
        if self.decay_rate is None:
            return initial_alpha
        
        remaining = initial_alpha * np.exp(-self.decay_rate * elapsed_hours)
        return remaining
    
    def get_decay_curve(self, initial_alpha: float = 1.0, 
                       max_hours: float = 168) -> Dict:
        """Get decay curve for visualization."""
        if self.decay_rate is None:
            return {}
        
        time_points = np.linspace(0, max_hours, 100)
        alpha_values = initial_alpha * np.exp(-self.decay_rate * time_points)
        
        return {
            'time_hours': time_points.tolist(),
            'alpha_values': alpha_values.tolist(),
            'half_life_point': self.half_life_hours,
            'half_life_alpha': initial_alpha * 0.5
        }
    
    def get_model_statistics(self) -> Dict:
        """Get comprehensive model statistics."""
        if not self.signal_history:
            return {}
        
        complete_signals = [
            s for s in self.signal_history 
            if s.realized_return is not None
        ]
        
        if not complete_signals:
            return {}
        
        returns = [s.realized_return for s in complete_signals]
        holding_periods = [s.holding_period_hours for s in complete_signals 
                          if s.holding_period_hours is not None]
        
        stats = {
            'n_signals': len(self.signal_history),
            'n_complete': len(complete_signals),
            'avg_return': np.mean(returns) if returns else 0.0,
            'std_return': np.std(returns) if len(returns) > 1 else 0.0,
            'sharpe_ratio': (np.mean(returns) / np.std(returns) * np.sqrt(365*24)
if np.std(returns) > 0 else 0.0),
            'avg_holding_hours': np.mean(holding_periods) if holding_periods else 0.0,
            'signal_frequency_hours': self._calculate_signal_frequency()
        }
        
        if self.half_life_hours:
            stats.update({
                'half_life_hours': self.half_life_hours,
                'decay_rate_per_hour': self.decay_rate,
                'confidence_interval': self.confidence_interval,
                'model_quality': self._assess_model_quality(),
                'recommended_max_holding': self._calculate_recommended_holding(),
                'decay_percentage_at_1h': (1 - np.exp(-self.decay_rate)) * 100 
                                        if self.decay_rate else 0.0
            })
        
        return stats
    
    def _calculate_signal_frequency(self) -> float:
        """Calculate average time between signals."""
        if len(self.signal_history) < 2:
            return 0.0
        
        times = sorted([s.signal_time for s in self.signal_history])
        intervals = [(times[i+1] - times[i]).total_seconds() / 3600 
                    for i in range(len(times)-1)]
        
        return np.mean(intervals) if intervals else 0.0
    
    def _assess_model_quality(self) -> str:
        """Assess quality of half-life estimation."""
        if not self.confidence_interval:
            return "POOR"
        
        ci_width = self.confidence_interval[1] - self.confidence_interval[0]
        ci_relative = ci_width / self.half_life_hours if self.half_life_hours > 0 else 1.0
        
        if ci_relative < 0.1:
            return "EXCELLENT"
        elif ci_relative < 0.25:
            return "GOOD"
        elif ci_relative < 0.5:
            return "FAIR"
        else:
            return "POOR"
    
    def _calculate_recommended_holding(self) -> float:
        """Calculate recommended maximum holding period."""
        if not self.half_life_hours:
            return 24.0  // Default 24 hours
        
        // Recommend holding until alpha decays to 25% of initial
        recommended = -np.log(0.25) / self.decay_rate if self.decay_rate > 0 else 24.0
        return min(recommended, 7*24)  // Cap at 1 week
    
    def detect_regime_change(self, window_size: int = 100) -> Dict:
        """
        Detect changes in signal decay regime.
        
        Args:
            window_size: Rolling window size for regime detection
            
        Returns:
            Regime change detection results
        """
        if len(self.signal_history) < window_size * 2:
            return {'change_detected': False}
        
        complete_signals = [
            s for s in self.signal_history 
            if s.realized_return is not None and s.holding_period_hours is not None
        ]
        
        if len(complete_signals) < window_size * 2:
            return {'change_detected': False}
        
        // Calculate rolling half-lives
        rolling_half_lives = []
        
        for i in range(len(complete_signals) - window_size):
            window = complete_signals[i:i+window_size]
            half_life = self._estimate_window_half_life(window)
            if half_life:
                rolling_half_lives.append(half_life)
        
        if len(rolling_half_lives) < 20:
            return {'change_detected': False}
        
        // Detect structural breaks using CUSUM
        cusum_stat = self._calculate_cusum(rolling_half_lives)
        threshold = 1.358 * np.sqrt(len(rolling_half_lives))  // 95% confidence
        
        change_detected = np.max(np.abs(cusum_stat)) > threshold
        
        result = {
            'change_detected': bool(change_detected),
            'max_cusum': float(np.max(np.abs(cusum_stat))),
            'threshold': float(threshold),
            'current_half_life': float(self.half_life_hours) if self.half_life_hours else 0.0,
            'rolling_half_lives': rolling_half_lives
        }
        
        if change_detected:
            // Estimate change point
change_idx = np.argmax(np.abs(cusum_stat))
            result['change_point_index'] = int(change_idx)
            result['change_point_signal'] = complete_signals[change_idx + window_size].signal_time.isoformat()
            result['old_regime_half_life'] = float(np.mean(rolling_half_lives[:change_idx])) if change_idx > 0 else 0.0
            result['new_regime_half_life'] = float(np.mean(rolling_half_lives[change_idx:])) if change_idx < len(rolling_half_lives) else 0.0
        
        return result
    
    def _estimate_window_half_life(self, signals: List[SignalObservation]) -> Optional[float]:
        """Estimate half-life for a window of signals."""
        if len(signals) < 10:
            return None
        
        holding_periods = [s.holding_period_hours for s in signals]
        returns = [s.realized_return for s in signals]
        alphas = [abs(s.signal_strength) for s in signals]
        
        // Normalize
        normalized = []
        for ret, alpha in zip(returns, alphas):
            if alpha != 0:
                normalized.append(ret / alpha)
            else:
                normalized.append(0.0)
        
        // Simple median-based estimation
        try:
            // Fit linear regression to log of normalized returns
            valid_mask = np.array(normalized) > 0
            if np.sum(valid_mask) < 5:
                return None
            
            log_returns = np.log(np.array(normalized)[valid_mask])
            periods = np.array(holding_periods)[valid_mask]
            
            slope, intercept, r_value, p_value, std_err = stats.linregress(
                periods, log_returns
            )
            
            if slope >= 0:  // Positive slope doesn't make sense for decay
                return None
            
            half_life = -np.log(2) / slope
            return half_life
        
        except:
            return None
    
    def _calculate_cusum(self, data: List[float]) -> np.ndarray:
        """Calculate CUSUM statistics for change detection."""
        n = len(data)
        mean = np.mean(data)
        std = np.std(data) if np.std(data) > 0 else 1.0
        
        standardized = [(x - mean) / std for x in data]
        
        cusum = np.zeros(n)
        for i in range(1, n):
            cusum[i] = cusum[i-1] + standardized[i]
        
        return cusum
