"""
Parameter drift detection v4.0.
Detects and monitors drift in strategy parameters over time.
"""

import numpy as np
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass
from enum import Enum
from scipy import stats
import warnings
warnings.filterwarnings('ignore')


class DriftDetectionMethod(Enum):
    """Methods for detecting parameter drift."""
    CUSUM = "cusum"              // Cumulative sum control chart
    EWMA = "ewma"                // Exponentially weighted moving average
    PAGE_HINKLEY = "page_hinkley"  // Page-Hinkley test
    ADWIN = "adwin"              // Adaptive Windowing
    KSWIN = "kswin"              // Kolmogorov-Smirnov Windowing


@dataclass
class ParameterMonitor:
    """Monitor for a single parameter."""
    name: str
    current_value: float
    historical_values: List[float]
    timestamps: List[float]
    
    # Statistical properties
    mean: float = 0.0
    std: float = 0.0
    stable_period_mean: float = 0.0
    stable_period_std: float = 0.0
    
    # Drift detection state
    drift_detected: bool = False
    drift_magnitude: float = 0.0
    drift_confidence: float = 0.0
    last_drift_time: Optional[float] = None
    
    def update(self, new_value: float, timestamp: float):
        """Update parameter with new value."""
        self.current_value = new_value
        self.historical_values.append(new_value)
        self.timestamps.append(timestamp)
        
        # Update statistics
        if len(self.historical_values) >= 10:
            self.mean = np.mean(self.historical_values)
            self.std = np.std(self.historical_values) if len(self.historical_values) > 1 else 0.0


class ParameterDriftDetector:
    """
    Detects drift in strategy parameters over time.
    
    Monitors key parameters and detects when they significantly change,
    indicating strategy decay or regime change.
    """
    
    def __init__(self, parameters_to_monitor: List[str],
                 detection_method: DriftDetectionMethod = DriftDetectionMethod.CUSUM,
                 window_size: int = 100,
                 sensitivity: float = 2.0):
        """
        Args:
            parameters_to_monitor: List of parameter names to monitor
            detection_method: Method for drift detection
            window_size: Size of rolling window for detection
            sensitivity: Sensitivity factor for detection (higher = more sensitive)
        """
        self.detection_method = detection_method
        self.window_size = window_size
        self.sensitivity = sensitivity
        
        # Initialize monitors
        self.monitors: Dict[str, ParameterMonitor] = {}
        for param_name in parameters_to_monitor:
            self.monitors[param_name] = ParameterMonitor(
                name=param_name,
                current_value=0.0,
                historical_values=[],
                timestamps=[]
            )
        
        # Drift history
        self.drift_history: List[Dict] = []
        self.alerts: List[Dict] = []
        
        # Detection thresholds
        self.alert_threshold = 0.8  // Confidence threshold for alerts
        self.warning_threshold = 0.6  // Confidence threshold for warnings
    
    def update_parameters(self, parameters: Dict[str, float], timestamp: float):
        """
        Update all monitored parameters.
        
        Args:
            parameters: Dictionary of parameter name -> value
            timestamp: Current timestamp
        """
        for param_name, param_value in parameters.items():
            if param_name in self.monitors:
                monitor = self.monitors[param_name]
                monitor.update(param_value, timestamp)
                
                # Check for drift
                if len(monitor.historical_values) >= self.window_size:
                    drift_result = self._detect_drift(monitor)
                    
                    if drift_result['drift_detected']:
                        monitor.drift_detected = True
                        monitor.drift_magnitude = drift_result['drift_magnitude']
                        monitor.drift_confidence = drift_result['confidence']
                        monitor.last_drift_time = timestamp
                        
                        # Record drift event
                        drift_event = {
                            'timestamp': timestamp,
                            'parameter': param_name,
                            'old_value': drift_result.get('old_mean', monitor.mean),
                            'new_value': drift_result.get('new_mean', param_value),
                            'magnitude': monitor.drift_magnitude,
                            'confidence': monitor.drift_confidence,
                            'method': self.detection_method.value
                        }
                        
                        self.drift_history.append(drift_event)
                        
                        # Generate alert if confidence is high
                        if monitor.drift_confidence >= self.alert_threshold:
                            self._generate_alert(drift_event, 'ALERT')
                        elif monitor.drift_confidence >= self.warning_threshold:
                            self._generate_alert(drift_event, 'WARNING')
                    else:
                        monitor.drift_detected = False
                        monitor.drift_magnitude = 0.0
                        monitor.drift_confidence = 0.0
    
    def _detect_drift(self, monitor: ParameterMonitor) -> Dict:
        """
        Detect drift using specified method.
        
        Returns:
            Drift detection results
        """
        values = monitor.historical_values
        
        if len(values) < self.window_size * 2:
            return {'drift_detected': False, 'confidence': 0.0}
        
        # Split into reference and test windows
        ref_window = values[-self.window_size*2:-self.window_size]
        test_window = values[-self.window_size:]
        
        if len(ref_window) < 10 or len(test_window) < 10:
            return {'drift_detected': False, 'confidence': 0.0}
        
        if self.detection_method == DriftDetectionMethod.CUSUM:
            return self._detect_drift_cusum(ref_window, test_window)
        elif self.detection_method == DriftDetectionMethod.EWMA:
            return self._detect_drift_ewma(ref_window, test_window)
        elif self.detection_method == DriftDetectionMethod.PAGE_HINKLEY:
            return self._detect_drift_page_hinkley(values)
        elif self.detection_method == DriftDetectionMethod.ADWIN:
            return self._detect_drift_adwin(values)
        elif self.detection_method == DriftDetectionMethod.KSWIN:
            return self._detect_drift_kswin(ref_window, test_window)
        else:
            return self._detect_drift_statistical(ref_window, test_window)
    
    def _detect_drift_cusum(self, ref_window: List[float], 
                           test_window: List[float]) -> Dict:
        """Detect drift using CUSUM method."""
        ref_mean = np.mean(ref_window)
        ref_std = np.std(ref_window)
        
        if ref_std == 0:
            return {'drift_detected': False, 'confidence': 0.0}
        
        # Standardize test window
        standardized = [(x - ref_mean) / ref_std for x in test_window]
        
        # Calculate CUSUM statistics
        cusum_pos = 0.0
        cusum_neg = 0.0
        max_cusum_pos = 0.0
        max_cusum_neg = 0.0
        
        for z in standardized:
            cusum_pos = max(0, cusum_pos + z - self.sensitivity)
            cusum_neg = min(0, cusum_neg + z + self.sensitivity)
            max_cusum_pos = max(max_cusum_pos, cusum_pos)
            max_cusum_neg = min(max_cusum_neg, cusum_neg)
        
        # Test for drift
        threshold = np.sqrt(len(test_window)) * 1.5
        
        drift_detected = (max_cusum_pos > threshold) or (abs(max_cusum_neg) > threshold)
        
        if drift_detected:
            # Calculate confidence and magnitude
            test_mean = np.mean(test_window)
            magnitude = abs(test_mean - ref_mean) / ref_std if ref_std > 0 else 0.0
            confidence = min(0.99, max_cusum_pos / (threshold * 2))
        else:
            magnitude = 0.0
            confidence = 0.0
        
        return {
            'drift_detected': drift_detected,
            'drift_magnitude': magnitude,
            'confidence': confidence,
            'old_mean': ref_mean,
            'new_mean': np.mean(test_window) if drift_detected else ref_mean
        }
    
    def _detect_drift_ewma(self, ref_window: List[float],
                          test_window: List[float]) -> Dict:
        """Detect drift using EWMA control chart."""
        ref_mean = np.mean(ref_window)
        ref_std = np.std(ref_window)
        
        if ref_std == 0:
            return {'drift_detected': False, 'confidence': 0.0}
        
        # EWMA parameters
        lambda_param = 0.2  // Smoothing factor
        L = 2.7  // Control limit multiplier
        
        # Calculate EWMA statistics
        ewma_values = []
        z_prev = ref_mean
        
        for x in test_window:
            z = lambda_param * x + (1 - lambda_param) * z_prev
            ewma_values.append(z)
            z_prev = z
        
        # Control limits
        sigma_z = ref_std * np.sqrt(lambda_param / (2 - lambda_param))
        ucl = ref_mean + L * sigma_z
        lcl = ref_mean - L * sigma_z
        
        # Check for violations
        violations = sum(1 for z in ewma_values if z > ucl or z < lcl)
        drift_detected = violations > len(test_window) * 0.1  // More than 10% violations
        
        if drift_detected:
            test_mean = np.mean(test_window)
            magnitude = abs(test_mean - ref_mean) / ref_std if ref_std > 0 else 0.0
            confidence = min(0.99, violations / len(test_window))
        else:
            magnitude = 0.0
            confidence = 0.0
        
        return {
            'drift_detected': drift_detected,
            'drift_magnitude': magnitude,
            'confidence': confidence,
            'old_mean': ref_mean,
            'new_mean': np.mean(test_window) if drift_detected else ref_mean
        }
    
    def _detect_drift_page_hinkley(self, values: List[float]) -> Dict:
        """Detect drift using Page-Hinkley test."""
        if len(values) < 20:
            return {'drift_detected': False, 'confidence': 0.0}
        
        # Calculate cumulative differences
        mean = np.mean(values[:10])  // Initial mean
        cumulative_sum = 0.0
        max_cumulative = 0.0
        min_cumulative = 0.0
        
        for i, x in enumerate(values[10:]):
            cumulative_sum += x - mean - 0.01  // Allow small tolerance
            max_cumulative = max(max_cumulative, cumulative_sum)
            min_cumulative = min(min_cumulative, cumulative_sum)
        
        # Test statistic
        test_stat = max_cumulative - min_cumulative
        threshold = np.sqrt(len(values)) * self.sensitivity
        
        drift_detected = test_stat > threshold
        
        if drift_detected:
            # Split into before and after drift
            split_point = len(values) // 2
            old_mean = np.mean(values[:split_point])
            new_mean = np.mean(values[split_point:])
            magnitude = abs(new_mean - old_mean) / np.std(values[:split_point]) \
                       if np.std(values[:split_point]) > 0 else 0.0
            confidence = min(0.99, test_stat / (threshold * 2))
        else:
            magnitude = 0.0
            confidence = 0.0
            old_mean = np.mean(values)
            new_mean = old_mean
        
        return {
            'drift_detected': drift_detected,
            'drift_magnitude': magnitude,
            'confidence': confidence,
            'old_mean': old_mean,
            'new_mean': new_mean
        }
    
    def _detect_drift_adwin(self, values: List[float]) -> Dict:
        """Adaptive Windowing drift detection (simplified)."""
        if len(values) < 30:
            return {'drift_detected': False, 'confidence': 0.0}
        
        # Try different split points
        max_delta = 0.0
        best_split = len(values) // 2
        
        for split in range(10, len(values) - 10):
            window1 = values[:split]
            window2 = values[split:]
            
            if len(window1) < 10 or len(window2) < 10:
                continue
            
            mean1 = np.mean(window1)
            mean2 = np.mean(window2)
            std1 = np.std(window1) if len(window1) > 1 else 1.0
            std2 = np.std(window2) if len(window2) > 1 else 1.0
            
            # Two-sample t-test
            t_stat, p_value = stats.ttest_ind(window1, window2, equal_var=False)
            delta = abs(mean2 - mean1) / ((std1 + std2) / 2) if (std1 + std2) > 0 else 0.0
            
            if delta > max_delta and p_value < 0.05:
                max_delta = delta
                best_split = split
        
        drift_detected = max_delta > self.sensitivity
        
        if drift_detected:
            window1 = values[:best_split]
            window2 = values[best_split:]
            magnitude = max_delta
            confidence = min(0.99, max_delta / (self.sensitivity * 2))
        else:
            magnitude = 0.0
            confidence = 0.0
            window1 = values
            window2 = values
        
        return {
            'drift_detected': drift_detected,
            'drift_magnitude': magnitude,
            'confidence': confidence,
            'old_mean': np.mean(window1),
            'new_mean': np.mean(window2) if drift_detected else np.mean(window1)
        }
    
    def _detect_drift_kswin(self, ref_window: List[float],
                           test_window: List[float]) -> Dict:
        """Kolmogorov-Smirnov Windowing drift detection."""
        if len(ref_window) < 10 or len(test_window) < 10:
            return {'drift_detected': False, 'confidence': 0.0}
        
        # KS test
        statistic, p_value = stats.ks_2samp(ref_window, test_window)
        
        drift_detected = p_value < 0.05  // 95% confidence
        
        if drift_detected:
            ref_mean = np.mean(ref_window)
            test_mean = np.mean(test_window)
            ref_std = np.std(ref_window) if len(ref_window) > 1 else 1.0
            magnitude = abs(test_mean - ref_mean) / ref_std if ref_std > 0 else 0.0
            confidence = 1.0 - p_value
        else:
            magnitude = 0.0
            confidence = 0.0
            ref_mean = np.mean(ref_window)
            test_mean = ref_mean
        
        return {
            'drift_detected': drift_detected,
            'drift_magnitude': magnitude,
            'confidence': confidence,
            'old_mean': ref_mean,
            'new_mean': test_mean
        }
    
    def _detect_drift_statistical(self, ref_window: List[float],
                                 test_window: List[float]) -> Dict:
        """Simple statistical drift detection."""
        ref_mean = np.mean(ref_window)
        test_mean = np.mean(test_window)
        ref_std = np.std(ref_window) if len(ref_window) > 1 else 1.0
        
        # Z-test for difference in means
        if ref_std == 0:
            return {'drift_detected': False, 'confidence': 0.0}
        
        z_score = abs(test_mean - ref_mean) / (ref_std / np.sqrt(len(test_window)))
        
        # Two-tailed test
        drift_detected = z_score > self.sensitivity
        
        if drift_detected:
            magnitude = abs(test_mean - ref_mean) / ref_std
            confidence = min(0.99, z_score / (self.sensitivity * 2))
        else:
            magnitude = 0.0
            confidence = 0.0
        
        return {
            'drift_detected': drift_detected,
            'drift_magnitude': magnitude,
            'confidence': confidence,
            'old_mean': ref_mean,
            'new_mean': test_mean
        }
    
    def _generate_alert(self, drift_event: Dict, alert_type: str):
        """Generate drift alert."""
        alert = {
            'timestamp': drift_event['timestamp'],
            'type': alert_type,
            'parameter': drift_event['parameter'],
            'message': self._create_alert_message(drift_event, alert_type),
            'severity': self._calculate_severity(drift_event['magnitude'], 
                                               drift_event['confidence']),
            'data': drift_event
        }
        
        self.alerts.append(alert)
    
    def _create_alert_message(self, drift_event: Dict, alert_type: str) -> str:
        """Create human-readable alert message."""
        param = drift_event['parameter']
        magnitude = drift_event['magnitude']
        confidence = drift_event['confidence']
        
        if magnitude > 3.0:
            change_desc = "SEVERE change"
        elif magnitude > 2.0:
            change_desc = "major change"
        elif magnitude > 1.0:
            change_desc = "significant change"
        elif magnitude > 0.5:
            change_desc = "moderate change"
        else:
            change_desc = "small change"
        
        return (f"{alert_type}: Parameter '{param}' detected {change_desc} "
                f"(magnitude: {magnitude:.2f}σ, confidence: {confidence:.1%})")
    
    def _calculate_severity(self, magnitude: float, confidence: float) -> str:
        """Calculate alert severity."""
        score = magnitude * confidence
        
        if score > 2.0:
            return 'CRITICAL'
        elif score > 1.0:
            return 'HIGH'
        elif score > 0.5:
            return 'MEDIUM'
        elif score > 0.2:
            return 'LOW'
        else:
            return 'INFO'
    
    def get_drift_summary(self) -> Dict:
        """Get summary of parameter drifts."""
        drifting_params = []
        stable_params = []
        
        for param_name, monitor in self.monitors.items():
            if monitor.drift_detected:
                drifting_params.append({
                    'parameter': param_name,
                    'current_value': monitor.current_value,
                    'drift_magnitude': monitor.drift_magnitude,
                    'drift_confidence': monitor.drift_confidence,
                    'last_drift_time': monitor.last_drift_time
                })
            else:
                stable_params.append(param_name)
        
        # Calculate overall drift score
        if drifting_params:
            avg_magnitude = np.mean([p['drift_magnitude'] for p in drifting_params])
            avg_confidence = np.mean([p['drift_confidence'] for p in drifting_params])
            drift_score = avg_magnitude * avg_confidence
        else:
            avg_magnitude = 0.0
            avg_confidence = 0.0
            drift_score = 0.0
        
        return {
            'total_parameters_monitored': len(self.monitors),
            'drifting_parameters': len(drifting_params),
            'stable_parameters': len(stable_params),
            'overall_drift_score': drift_score,
            'avg_drift_magnitude': avg_magnitude,
            'avg_drift_confidence': avg_confidence,
            'drifting_parameters_details': drifting_params,
            'stable_parameters_list': stable_params,
            'recent_alerts': self.alerts[-5:] if self.alerts else [],
            'total_drift_events': len(self.drift_history),
            'recommendations': self._generate_drift_recommendations(drifting_params)
        }
    
    def _generate_drift_recommendations(self, drifting_params: List[Dict]) -> List[str]:
        """Generate recommendations based on drift analysis."""
        recommendations = []
        
        if not drifting_params:
            recommendations.append("All parameters stable - continue current strategy")
            return recommendations
        
        # Count critical drifts
        critical_drifts = [p for p in drifting_params 
                          if p['drift_confidence'] > 0.9 and p['drift_magnitude'] > 2.0]
        
        if critical_drifts:
            param_names = [p['parameter'] for p in critical_drifts]
            recommendations.append(
                f"CRITICAL: Parameters {param_names} showing severe drift. "
                "Consider pausing strategy and re-optimizing."
            )
        
        # Check if multiple parameters are drifting
        if len(drifting_params) > len(self.monitors) * 0.3:  // More than 30%
            recommendations.append(
                "Multiple parameters drifting - possible regime change. "
                "Consider strategy deactivation or major re-calibration."
            )
        
        # Check drift magnitude
        high_magnitude = [p for p in drifting_params if p['drift_magnitude'] > 1.5]
        if high_magnitude:
            recommendations.append(
                "Large magnitude drifts detected - parameter values may be invalid. "
                "Reset to default values or re-estimate from recent data."
            )
        
        # Specific parameter recommendations
        for param in drifting_params:
            if 'sharpe' in param.lower() or 'return' in param.lower():
                recommendations.append(
                    f"Performance metric '{param}' drifting - strategy may be decaying"
                )
            elif 'volatility' in param.lower() or 'risk' in param.lower():
                recommendations.append(
                    f"Risk parameter '{param}' drifting - adjust position sizing"
                )
            elif 'correlation' in param.lower():
                recommendations.append(
                    f"Correlation '{param}' drifting - review portfolio construction"
                )
        
        if not recommendations:
            recommendations.append(
                "Minor parameter drift detected - monitor closely but no action required"
            )
        
        return recommendations
    
    def get_parameter_stability_report(self) -> Dict:
        """Get detailed stability report for all parameters."""
        report = {}
        
        for param_name, monitor in self.monitors.items():
            values = monitor.historical_values
            
            if len(values) < 10:
                report[param_name] = {
                    'status': 'INSUFFICIENT_DATA',
                    'n_observations': len(values),
                    'current_value': monitor.current_value
                }
                continue
            
            # Calculate stability metrics
            mean = np.mean(values)
            std = np.std(values) if len(values) > 1 else 0.0
            cv = std / mean if mean != 0 else 0.0  // Coefficient of variation
            
            # Rolling stability
            if len(values) >= 20:
                rolling_std = []
                for i in range(len(values) - 9):
                    window = values[i:i+10]
                    rolling_std.append(np.std(window) if len(window) > 1 else 0.0)
                avg_rolling_std = np.mean(rolling_std)
                std_trend = np.polyfit(range(len(rolling_std)), rolling_std, 1)[0]
            else:
                avg_rolling_std = std
                std_trend = 0.0
            
            # Stability classification
            if cv < 0.1:
                stability = 'VERY_STABLE'
            elif cv < 0.25:
                stability = 'STABLE'
            elif cv < 0.5:
                stability = 'MODERATELY_VOLATILE'
            else:
                stability = 'HIGHLY_VOLATILE'
            
            # Trend analysis
            if len(values) >= 20:
                trend_coeff = np.polyfit(range(len(values)), values, 1)[0]
                trend_strength = abs(trend_coeff) / std if std > 0 else 0.0
                
                if trend_strength > 0.5:
                    trend = 'STRONG_TREND'
                elif trend_strength > 0.2:
                    trend = 'MODERATE_TREND'
                elif trend_strength > 0.05:
                    trend = 'WEAK_TREND'
                else:
                    trend = 'NO_TREND'
            else:
                trend = 'INSUFFICIENT_DATA'
                trend_strength = 0.0
            
            report[param_name] = {
                'status': 'MONITORING',
                'stability': stability,
                'coefficient_of_variation': cv,
                'current_value': monitor.current_value,
                'historical_mean': mean,
                'historical_std': std,
                'avg_rolling_std': avg_rolling_std,
                'std_trend': std_trend,
                'trend': trend,
                'trend_strength': trend_strength,
                'n_observations': len(values),
                'drift_detected': monitor.drift_detected,
                'drift_confidence': monitor.drift_confidence,
                'drift_magnitude': monitor.drift_magnitude,
                'last_drift_time': monitor.last_drift_time
            }
        
        return report