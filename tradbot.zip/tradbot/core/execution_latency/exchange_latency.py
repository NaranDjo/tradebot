# core/execution_latency/exchange_latency.py

# Импорты должны быть в начале файла!
import numpy as np
import pandas as pd
from enum import Enum
from typing import Dict, List, Optional


class ExchangeTier(Enum):
    """Exchange latency tiers."""
    TIER_1 = 1  # < 1ms (e.g., CME, NYSE)
    TIER_2 = 2  # 1-5ms (e.g., Nasdaq, ICE)
    TIER_3 = 3  # 5-20ms (e.g., Binance, Coinbase)
    TIER_4 = 4  # > 20ms (e.g., smaller exchanges)


class ProtocolType(Enum):
    """Communication protocol types."""
    FIX = "fix"                # Financial Information eXchange
    WEBSOCKET = "websocket"    # WebSocket connections
    REST = "rest"              # REST API
    HFT = "hft"                # Ultra-low latency, microwave links


class ExchangeLatencyModel:
    """Models latency characteristics for different exchanges."""
    
    def __init__(self):
        # Base latency in milliseconds by exchange tier
        self.base_latency = {
            ExchangeTier.TIER_1: 0.5,
            ExchangeTier.TIER_2: 2.0,
            ExchangeTier.TIER_3: 10.0,
            ExchangeTier.TIER_4: 30.0
        }
        
        # Protocol multipliers
        self.protocol_multiplier = {
            ProtocolType.HFT: 0.5,
            ProtocolType.FIX: 1.0,
            ProtocolType.WEBSOCKET: 1.2,
            ProtocolType.REST: 2.0
        }
        
        # Exchange-specific configurations
        self.exchange_profiles = {
            'binance': {
                'tier': ExchangeTier.TIER_3,
                'preferred_protocol': ProtocolType.WEBSOCKET,
                'location': 'Asia',
                'api_rate_limit': 1200  # requests per minute
            },
            'coinbase': {
                'tier': ExchangeTier.TIER_2,
                'preferred_protocol': ProtocolType.FIX,
                'location': 'US',
                'api_rate_limit': 1000
            },
            'kraken': {
                'tier': ExchangeTier.TIER_3,
                'preferred_protocol': ProtocolType.WEBSOCKET,
                'location': 'Europe',
                'api_rate_limit': 800
            },
            'ftx': {
                'tier': ExchangeTier.TIER_2,
                'preferred_protocol': ProtocolType.FIX,
                'location': 'US',
                'api_rate_limit': 1500
            }
        }
    
    def estimate_latency(self, 
                        exchange: str, 
                        protocol: ProtocolType = None,
                        network_jitter: float = 5.0) -> float:
        """
        Estimate latency for a specific exchange and protocol.
        
        Args:
            exchange: Exchange name
            protocol: Communication protocol
            network_jitter: Additional network jitter in ms
        
        Returns:
            Estimated latency in milliseconds
        """
        if exchange not in self.exchange_profiles:
            # Default to Tier 3 for unknown exchanges
            profile = {'tier': ExchangeTier.TIER_3}
        else:
            profile = self.exchange_profiles[exchange]
        
        if protocol is None:
            protocol = profile.get('preferred_protocol', ProtocolType.WEBSOCKET)
        
        # Base latency from tier
        base_ms = self.base_latency[profile['tier']]
        
        # Protocol adjustment
        protocol_ms = base_ms * self.protocol_multiplier[protocol]
        
        # Add network jitter (random delay)
        total_ms = protocol_ms + np.random.exponential(network_jitter)
        
        return total_ms
    
    def get_exchange_tier(self, exchange: str) -> ExchangeTier:
        """Get tier for a specific exchange."""
        if exchange in self.exchange_profiles:
            return self.exchange_profiles[exchange]['tier']
        return ExchangeTier.TIER_4
    
    def get_optimal_protocol(self, exchange: str) -> ProtocolType:
        """Get optimal protocol for an exchange."""
        if exchange in self.exchange_profiles:
            return self.exchange_profiles[exchange]['preferred_protocol']
        return ProtocolType.WEBSOCKET
    
    def compare_exchanges(self, exchanges: List[str]) -> Dict:
        """Compare latency across multiple exchanges."""
        comparison = {}
        
        for exchange in exchanges:
            latency = self.estimate_latency(exchange)
            tier = self.get_exchange_tier(exchange)
            protocol = self.get_optimal_protocol(exchange)
            
            comparison[exchange] = {
                'estimated_latency_ms': latency,
                'tier': tier.name,
                'optimal_protocol': protocol.value,
                'relative_rank': self._calculate_rank(latency)
            }
        
        # Sort by latency
        sorted_comparison = dict(sorted(
            comparison.items(), 
            key=lambda x: x[1]['estimated_latency_ms']
        ))
        
        return sorted_comparison
    
    def _calculate_rank(self, latency: float) -> str:
        """Calculate relative rank based on latency."""
        if latency < 1:
            return "Excellent"
        elif latency < 5:
            return "Good"
        elif latency < 20:
            return "Average"
        elif latency < 50:
            return "Poor"
        else:
            return "Unacceptable"
    
    def generate_latency_matrix(self, exchanges: List[str]) -> pd.DataFrame:
        """Generate latency matrix for multiple exchanges."""
        matrix_data = []
        
        for exchange in exchanges:
            for protocol in ProtocolType:
                latency = self.estimate_latency(exchange, protocol)
                matrix_data.append({
                    'exchange': exchange,
                    'protocol': protocol.value,
                    'latency_ms': latency,
                    'tier': self.get_exchange_tier(exchange).name
                })
        
        df = pd.DataFrame(matrix_data)
        
        # Pivot for better visualization
        pivot_df = df.pivot_table(
            index='exchange',
            columns='protocol',
            values='latency_ms',
            aggfunc='mean'
        )
        
        return pivot_df


# Simple function for backward compatibility
def estimate_latency(tier: ExchangeTier, protocol: ProtocolType) -> float:
    """
    Estimate latency based on tier and protocol.
    
    Returns:
        Latency in milliseconds
    """
    base_latency = {
        ExchangeTier.TIER_1: 0.5,
        ExchangeTier.TIER_2: 2.0,
        ExchangeTier.TIER_3: 10.0,
        ExchangeTier.TIER_4: 30.0
    }
    
    protocol_multiplier = {
        ProtocolType.HFT: 0.5,
        ProtocolType.FIX: 1.0,
        ProtocolType.WEBSOCKET: 1.2,
        ProtocolType.REST: 2.0
    }
    
    return base_latency[tier] * protocol_multiplier[protocol]