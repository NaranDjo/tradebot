"""
Geographic and network latency modeling v4.0.
Based on speed of light constraints and empirical measurements.
"""

import numpy as np
from typing import Dict, List, Tuple
from dataclasses import dataclass
import math


@dataclass
class NetworkNode:
    """Network node with geographic coordinates."""
    name: str
    city: str
    country: str
    latitude: float  # Degrees
    longitude: float  # Degrees
    data_center: str
    provider: str
    connection_type: str  # 'fiber', 'microwave', 'satellite'
    
    def distance_to(self, other: 'NetworkNode') -> float:
        """Calculate great-circle distance in km."""
        # Haversine formula
        R = 6371.0  # Earth radius in km
        
        lat1 = math.radians(self.latitude)
        lon1 = math.radians(self.longitude)
        lat2 = math.radians(other.latitude)
        lon2 = math.radians(other.longitude)
        
        dlat = lat2 - lat1
        dlon = lon2 - lon1
        
        a = math.sin(dlat/2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon/2)**2
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
        
        return R * c


@dataclass
class NetworkLink:
    """Network link between two nodes."""
    from_node: NetworkNode
    to_node: NetworkNode
    distance_km: float
    propagation_speed: float  # Fraction of speed of light (c)
    additional_delay_ms: float  # Switching/routing delays
    
    @property
    def theoretical_min_latency_ms(self) -> float:
        """Theoretical minimum latency based on speed of light."""
        speed_of_light_km_ms = 299792.458  # km/s = km/ms * 1000
        propagation_time = self.distance_km / (speed_of_light_km_ms * self.propagation_speed)
        return propagation_time * 1000  # Convert to ms
    
    @property
    def estimated_latency_ms(self) -> float:
        """Estimated realistic latency."""
        return self.theoretical_min_latency_ms + self.additional_delay_ms


class NetworkTopology:
    """Global network topology model."""
    
    # Major financial hubs
    NODES = {
        "nyc": NetworkNode(
            name="nyc",
            city="New York",
            country="USA",
            latitude=40.7128,
            longitude=-74.0060,
            data_center="NY4",
            provider="Equinix",
            connection_type="fiber"
        ),
        "ldn": NetworkNode(
            name="ldn",
            city="London",
            country="UK",
            latitude=51.5074,
            longitude=-0.1278,
            data_center="LD4",
provider="Interxion",
            connection_type="fiber"
        ),
        "tk": NetworkNode(
            name="tk",
            city="Tokyo",
            country="Japan",
            latitude=35.6762,
            longitude=139.6503,
            data_center="TY3",
            provider="Equinix",
            connection_type="fiber"
        ),
        "sg": NetworkNode(
            name="sg",
            city="Singapore",
            country="Singapore",
            latitude=1.3521,
            longitude=103.8198,
            data_center="SG1",
            provider="Global Switch",
            connection_type="fiber"
        ),
        "hk": NetworkNode(
            name="hk",
            city="Hong Kong",
            country="China",
            latitude=22.3193,
            longitude=114.1694,
            data_center="HK1",
            provider="NTT",
            connection_type="microwave"  // Microwave for ultra-low latency
        )
    }
    
    # Empirical link characteristics
    LINK_PROFILES = {
        ("nyc", "ldn"): {
            "propagation_speed": 0.67,  # Fiber optic (2/3 c)
            "additional_delay_ms": 8.0
        },
        ("nyc", "tk"): {
            "propagation_speed": 0.65,
            "additional_delay_ms": 25.0
        },
        ("ldn", "sg"): {
            "propagation_speed": 0.66,
            "additional_delay_ms": 20.0
        },
        ("hk", "sg"): {
            "propagation_speed": 0.95,  // Microwave (near speed of light)
            "additional_delay_ms": 0.5
        }
    }
    
    def __init__(self, client_location: str, exchange_location: str):
        self.client = self.NODES[client_location]
        self.exchange = self.NODES[exchange_location]
        
        # Calculate or retrieve link
        key = (client_location, exchange_location)
        if key in self.LINK_PROFILES:
            profile = self.LINK_PROFILES[key]
        else:
            # Reverse direction
            rev_key = (exchange_location, client_location)
            if rev_key in self.LINK_PROFILES:
                profile = self.LINK_PROFILES[rev_key]
            else:
                # Default fiber profile
                profile = {
                    "propagation_speed": 0.67,
                    "additional_delay_ms": 15.0
                }
        
        distance = self.client.distance_to(self.exchange)
        self.link = NetworkLink(
            from_node=self.client,
            to_node=self.exchange,
            distance_km=distance,
            propagation_speed=profile["propagation_speed"],
            additional_delay_ms=profile["additional_delay_ms"]
        )
    
    def get_round_trip_latency(self, protocol_overhead_ms: float = 0.0) -> float:
        """
        Get round-trip latency.
        
        Args:
            protocol_overhead_ms: Additional protocol processing time
            
        Returns:
            Total RTT in milliseconds
        """
        one_way = self.link.estimated_latency_ms
        rtt = one_way * 2 + protocol_overhead_ms
        
        # Add random jitter (5% of RTT)
        jitter = np.random.normal(0, rtt * 0.05)
        return max(0.1, rtt + jitter)
    
    def get_microwave_latency(self) -> float:
        """Get latency if microwave link is available."""
        if self.link.from_node.connection_type == "microwave":
            # Microwave is much faster
            microwave_speed = 0.98  # 98% of speed of light
            microwave_latency = (self.link.distance_km / 
                               (299792.458 * microwave_speed)) * 1000
            return microwave_latency + 0.5  # Small additional delay
        else:
            return self.link.estimated_latency_ms
    
    def get_latency_breakdown(self) -> Dict:
        """Get detailed latency breakdown."""
        return {
            "distance_km": self.link.distance_km,
            "theoretical_min_ms": self.link.theoretical_min_latency_ms,
            "propagation_delay_ms": self.link.theoretical_min_latency_ms,
            "additional_delay_ms": self.link.
additional_delay_ms,
            "estimated_one_way_ms": self.link.estimated_latency_ms,
            "estimated_rtt_ms": self.link.estimated_latency_ms * 2,
            "microwave_available": self.link.from_node.connection_type == "microwave",
            "microwave_latency_ms": self.get_microwave_latency() if 
                                   self.link.from_node.connection_type == "microwave" else None
        }
