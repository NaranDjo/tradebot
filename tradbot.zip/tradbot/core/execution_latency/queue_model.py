"""
Order queue simulation with FIFO and Pro-Rata matching v4.0.
Models exchange matching engine behavior.
"""

from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass
import numpy as np
from enum import Enum
from collections import defaultdict
import heapq


class MatchingAlgorithm(Enum):
    """Order matching algorithms."""
    FIFO = "fifo"              # First-In-First-Out
    PRO_RATA = "pro_rata"      // Proportional allocation
    PRICE_TIME = "price_time"  // Price then time priority
    HYBRID = "hybrid"          // Combination


@dataclass
class OrderBookLevel:
    """Single price level in order book."""
    price: float
    total_volume: float = 0.0
    orders: List[Tuple[str, float, float]] = None  # (order_id, volume, timestamp)
    
    def __post_init__(self):
        if self.orders is None:
            self.orders = []
    
    def add_order(self, order_id: str, volume: float, timestamp: float):
        """Add order to this price level."""
        self.orders.append((order_id, volume, timestamp))
        self.total_volume += volume
    
    def remove_order(self, order_id: str) -> float:
        """Remove order and return its volume."""
        for i, (oid, vol, ts) in enumerate(self.orders):
            if oid == order_id:
                self.orders.pop(i)
                self.total_volume -= vol
                return vol
        return 0.0
    
    def get_orders_by_time(self) -> List[Tuple[str, float, float]]:
        """Get orders sorted by timestamp (oldest first)."""
        return sorted(self.orders, key=lambda x: x[2])


@dataclass
class VirtualOrderBook:
    """Virtual order book for queue simulation."""
    symbol: str
    matching_algorithm: MatchingAlgorithm
    tick_size: float = 0.01
    
    # Order books
    bids: Dict[float, OrderBookLevel] = None
    asks: Dict[float, OrderBookLevel] = None
    
    # Order tracking
    order_timestamps: Dict[str, float] = None
    
    def __post_init__(self):
        if self.bids is None:
            self.bids = defaultdict(lambda: OrderBookLevel(price=0))
        if self.asks is None:
            self.asks = defaultdict(lambda: OrderBookLevel(price=0))
        if self.order_timestamps is None:
            self.order_timestamps = {}
    
    def add_limit_order(self, order_id: str, side: str, price: float, 
                       volume: float, timestamp: float):
        """
        Add limit order to the book.
        
        Args:
            order_id: Unique order identifier
            side: 'buy' or 'sell'
            price: Order price
            volume: Order volume
            timestamp: Order timestamp
        """
        # Round to tick size
        price = round(price / self.tick_size) * self.tick_size
        
        if side == 'buy':
            level = self.bids[price]
            level.price = price
            level.add_order(order_id, volume, timestamp)
        else:  # sell
            level = self.asks[price]
            level.price = price
            level.add_order(order_id, volume, timestamp)
        
        self.order_timestamps[order_id] = timestamp
    
    def match_market_order(self, side: str, volume: float, 
                          timestamp: float) -> Tuple[float, List[Tuple]]:
        """
        Match a market order against the book.
        
        Returns:
            (average_price, list of (order_id, matched_volume, price))
        """
        matched_orders = []
        remaining_volume = volume
        total_cost = 0.0
        
        if side == 'buy':
            # Match against asks (sell orders)
price_levels = sorted(self.asks.keys())  # Ascending price
            for price in price_levels:
                if remaining_volume <= 0:
                    break
                
                level = self.asks[price]
                matched = self._match_at_level(
                    level, remaining_volume, timestamp, side
                )
                
                for order_id, matched_vol in matched:
                    matched_orders.append((order_id, matched_vol, price))
                    total_cost += matched_vol * price
                    remaining_volume -= matched_vol
                
                # Remove empty levels
                if level.total_volume == 0:
                    del self.asks[price]
        
        else:  # sell
            # Match against bids (buy orders)
            price_levels = sorted(self.bids.keys(), reverse=True)  # Descending price
            for price in price_levels:
                if remaining_volume <= 0:
                    break
                
                level = self.bids[price]
                matched = self._match_at_level(
                    level, remaining_volume, timestamp, side
                )
                
                for order_id, matched_vol in matched:
                    matched_orders.append((order_id, matched_vol, price))
                    total_cost += matched_vol * price
                    remaining_volume -= matched_vol
                
                # Remove empty levels
                if level.total_volume == 0:
                    del self.bids[price]
        
        avg_price = total_cost / (volume - remaining_volume) if (volume - remaining_volume) > 0 else 0
        return avg_price, matched_orders
    
    def _match_at_level(self, level: OrderBookLevel, volume: float,
                       timestamp: float, side: str) -> List[Tuple[str, float]]:
        """
        Match volume at a specific price level.
        
        Returns:
            List of (order_id, matched_volume)
        """
        if self.matching_algorithm == MatchingAlgorithm.FIFO:
            return self._match_fifo(level, volume, timestamp)
        elif self.matching_algorithm == MatchingAlgorithm.PRO_RATA:
            return self._match_pro_rata(level, volume, timestamp)
        elif self.matching_algorithm == MatchingAlgorithm.PRICE_TIME:
            return self._match_price_time(level, volume, timestamp, side)
        else:  # HYBRID
            return self._match_hybrid(level, volume, timestamp)
    
    def _match_fifo(self, level: OrderBookLevel, volume: float, 
                   timestamp: float) -> List[Tuple[str, float]]:
        """FIFO matching (time priority)."""
        matched = []
        remaining = volume
        
        for order_id, order_vol, order_ts in level.get_orders_by_time():
            if remaining <= 0:
                break
            
            match_vol = min(order_vol, remaining)
            matched.append((order_id, match_vol))
            
            # Update order
            for i, (oid, vol, ts) in enumerate(level.orders):
                if oid == order_id:
                    if match_vol == vol:
                        level.orders.pop(i)
                    else:
                        level.orders[i] = (oid, vol - match_vol, ts)
                    break
            
            level.total_volume -= match_vol
            remaining -= match_vol
        
        return matched
    
    def _match_pro_rata(self, level: OrderBookLevel, volume: float,
                       timestamp: float) -> List[Tuple[str, float]]:
        """Pro-Rata matching (proportional allocation)."""
        if level.total_volume == 0:
            return []
        
        matched = []
        allocation_ratio = volume / level.total_volume
        
        for order_id, order_vol, order_ts in level.orders:
            allocated = order_vol * allocation_ratio
            matched.append((order_id, allocated))
        
        # Update orders
        new_orders = []
for i, (order_id, order_vol, order_ts) in enumerate(level.orders):
            allocated = order_vol * allocation_ratio
            remaining_vol = order_vol - allocated
            
            if remaining_vol > 0.0001:  # Avoid floating point issues
                new_orders.append((order_id, remaining_vol, order_ts))
        
        level.orders = new_orders
        level.total_volume = sum(vol for _, vol, _ in new_orders)
        
        return matched
    
    def _match_price_time(self, level: OrderBookLevel, volume: float,
                         timestamp: float, side: str) -> List[Tuple[str, float]]:
        """Price-Time priority (common in traditional exchanges)."""
        # Similar to FIFO but with price priority already handled
        return self._match_fifo(level, volume, timestamp)
    
    def _match_hybrid(self, level: OrderBookLevel, volume: float,
                     timestamp: float) -> List[Tuple[str, float]]:
        """Hybrid matching (FIFO for small, Pro-Rata for large)."""
        if volume < 100:  # Small order threshold
            return self._match_fifo(level, volume, timestamp)
        else:
            return self._match_pro_rata(level, volume, timestamp)
    
    def get_best_bid_ask(self) -> Tuple[Optional[float], Optional[float]]:
        """Get best bid and ask prices."""
        best_bid = max(self.bids.keys()) if self.bids else None
        best_ask = min(self.asks.keys()) if self.asks else None
        return best_bid, best_ask
    
    def get_market_depth(self, levels: int = 10) -> Dict:
        """Get market depth for analysis."""
        bids = sorted(self.bids.items(), key=lambda x: x[0], reverse=True)[:levels]
        asks = sorted(self.asks.items(), key=lambda x: x[0])[:levels]
        
        return {
            'bids': [(price, level.total_volume) for price, level in bids],
            'asks': [(price, level.total_volume) for price, level in asks],
            'spread': asks[0][0] - bids[0][0] if bids and asks else None,
            'total_bid_volume': sum(level.total_volume for _, level in bids),
            'total_ask_volume': sum(level.total_volume for _, level in asks),
            'order_count': sum(len(level.orders) for _, level in list(bids) + list(asks))
        }
