"""
Advanced execution metrics v4.0.
Comprehensive metrics for execution quality analysis.
"""

import numpy as np
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime, timedelta
from scipy import stats


@dataclass
class ExecutionMetrics:
    """Comprehensive execution metrics."""
    # Basic metrics
    total_trades: int
    profitable_trades: int
    total_pnl: float
    total_volume: float
    
    # Execution quality
    avg_slippage_bps: float
    avg_implementation_shortfall_bps: float
    avg_market_impact_bps: float
    avg_adverse_selection_bps: float
    
    # Latency metrics
    avg_execution_latency_ms: float
    p95_execution_latency_ms: float
    p99_execution_latency_ms: float
    
    # Fill quality
    fill_rate: float  // Percentage of orders filled
    partial_fill_rate: float
    rejection_rate: float
    
    # Cost metrics
    total_commission: float
    total_fees: float
    total_execution_cost: float
    cost_as_percent_of_pnl: float
    
    # Risk metrics
    max_intraday_drawdown: float
    sharpe_ratio: float
    sortino_ratio: float
    calmar_ratio: float
    
    # Advanced metrics
    information_ratio: float
    tracking_error_bps: float
    realized_vs_expected_slippage_ratio: float
    alpha_decay_cost_bps: float
    
    def to_dict(self) -> Dict:
        """Convert to dictionary."""
        return {k: v for k, v in self.__dict__.items() if not k.startswith('_')}


class ExecutionQualityAnalyzer:
    """
    Analyzes execution quality and provides comprehensive metrics.
    """
    
    def __init__(self):
        self.trade_history: List[Dict] = []
        self.order_history: List[Dict] = []
        self.metrics_history: List[ExecutionMetrics] = []
        
    def add_trade(self, trade: Dict):
        """Add a completed trade to analyzer."""
        self.trade_history.append(trade)
        
    def add_order(self, order: Dict):
        """Add an order (filled or not) to analyzer."""
        self.order_history.append(order)
    
    def calculate_metrics(self, lookback_period: Optional[timedelta] = None) -> ExecutionMetrics:
        """
        Calculate comprehensive execution metrics.
        
        Args:
            lookback_period: Optional period to analyze (None = all history)
            
        Returns:
            Execution metrics
        """
        # Filter trades by time if needed
        if lookback_period:
            cutoff_time = datetime.now() - lookback_period
            trades = [t for t in self.trade_history 
                     if datetime.fromisoformat(t['timestamp']) >= cutoff_time]
            orders = [o for o in self.order_history 
                     if datetime.fromisoformat(o['timestamp']) >= cutoff_time]
        else:
            trades = self.trade_history
            orders = self.order_history
        
        if not trades:
            return ExecutionMetrics(
                total_trades=0,
                profitable_trades=0,
                total_pnl=0.0,
                total_volume=0.0,
                avg_slippage_bps=0.0,
                avg_implementation_shortfall_bps=0.0,
                avg_market_impact_bps=0.0,
                avg_adverse_selection_bps=0.0,
                avg_execution_latency_ms=0.0,
                p95_execution_latency_ms=0.0,
                p99_execution_latency_ms=0.0,
                fill_rate=0.0,
                partial_fill_rate=0.0,
                rejection_rate=0.0,
                total_commission=0.0,
                total_fees=0.0,
                total_execution_cost=0.0,
                cost_as_percent_of_pnl=0.0,
                max_intraday_drawdown=0.0,
                sharpe_ratio=0.0,
                sortino_ratio=0.0,
                calmar_ratio=0.0,
                information_ratio=0.0,
                tracking_error_bps=0.0,
                realized_vs_expected_slippage_ratio=0.0,
                alpha_decay_cost_bps=0.0
            )
        
        # Calculate basic metrics
        total_trades = len(trades)
        profitable_trades = sum(1 for t in trades if t.get('pnl', 0) > 0)
        total_pnl = sum(t.get('pnl', 0) for t in trades)
        total_volume = sum(t.get('volume', 0) for t in trades)
        
        # Execution quality metrics
        slippages = [t.get('slippage_bps', 0) for t in trades if 'slippage_bps' in t]
        avg_slippage_bps = np.mean(slippages) if slippages else 0.0
        
        implementation_shortfalls = [t.get('implementation_shortfall_bps', 0) 
                                   for t in trades if 'implementation_shortfall_bps' in t]
        avg_implementation_shortfall_bps = np.mean(implementation_shortfalls) \
                                         if implementation_shortfalls else 0.0
        
        market_impacts = [t.get('market_impact_bps', 0) 
                         for t in trades if 'market_impact_bps' in t]
        avg_market_impact_bps = np.mean(market_impacts) if market_impacts else 0.0
        
        adverse_selections = [t.get('adverse_selection_bps', 0) 
                            for t in trades if 'adverse_selection_bps' in t]
        avg_adverse_selection_bps = np.mean(adverse_selections) \
                                   if adverse_selections else 0.0
        
        # Latency metrics
        latencies = [t.get('execution_latency_ms', 0) 
                    for t in trades if 'execution_latency_ms' in t]
        avg_execution_latency_ms = np.mean(latencies) if latencies else 0.0
        p95_execution_latency_ms = np.percentile(latencies, 95) if latencies else 0.0
        p99_execution_latency_ms = np.percentile(latencies, 99) if latencies else 0.0
        
        # Fill quality metrics
        filled_orders = [o for o in orders if o.get('status') in ['FILLED', 'PARTIALLY_FILLED']]
        fully_filled = [o for o in orders if o.get('status') == 'FILLED']
        partially_filled = [o for o in orders if o.get('status') == 'PARTIALLY_FILLED']
        rejected_orders = [o for o in orders if o.get('status') == 'REJECTED']
        
        total_orders = len(orders)
        fill_rate = len(fully_filled) / total_orders if total_orders > 0 else 0.0
        partial_fill_rate = len(partially_filled) / total_orders if total_orders > 0 else 0.0
        rejection_rate = len(rejected_orders) / total_orders if total_orders > 0 else 0.0
        
        # Cost metrics
        total_commission = sum(t.get('commission', 0) for t in trades)
        total_fees = sum(t.get('fee', 0) for t in trades)
        total_execution_cost = total_commission + total_fees + \
                             sum(t.get('slippage_cost', 0) for t in trades)
        cost_as_percent_of_pnl = (total_execution_cost / abs(total_pnl) * 100) \
                                if total_pnl != 0 else 0.0
        
        # Risk metrics
        pnl_series = self._calculate_pnl_series(trades)
        max_intraday_drawdown = self._calculate_max_drawdown(pnl_series)
        sharpe_ratio = self._calculate_sharpe_ratio(pnl_series)
        sortino_ratio = self._calculate_sortino_ratio(pnl_series)
        calmar_ratio = self._calculate_calmar_ratio(pnl_series, max_intraday_drawdown)
        
        # Advanced metrics
        information_ratio = self._calculate_information_ratio(pnl_series)
        tracking_error_bps = self._calculate_tracking_error(pnl_series)
        
        realized_slippages = [t.get('realized_slippage_bps', 0) 
                             for t in trades if 'realized_slippage_bps' in t]
        expected_slippages = [t.get('expected_slippage_bps', 0) 
                             for t in trades if 'expected_slippage_bps' in t]
        
        if expected_slippages and np.mean(expected_slippages) > 0:
            realized_vs_expected_slippage_ratio = np.mean(realized_slippages) / np.mean(expected_slippages)
        else:
            realized_vs_expected_slippage_ratio = 0.0
        
        alpha_decay_costs = [t.get('alpha_decay_cost_bps', 0) 
                           for t in trades if 'alpha_decay_cost_bps' in t]
        alpha_decay_cost_bps = np.mean(alpha_decay_costs) if alpha_decay_costs else 0.0
        
        # Create metrics object
        metrics = ExecutionMetrics(
            total_trades=total_trades,
            profitable_trades=profitable_trades,
            total_pnl=total_pnl,
            total_volume=total_volume,
            avg_slippage_bps=avg_slippage_bps,
            avg_implementation_shortfall_bps=avg_implementation_shortfall_bps,
            avg_market_impact_bps=avg_market_impact_bps,
            avg_adverse_selection_bps=avg_adverse_selection_bps,
            avg_execution_latency_ms=avg_execution_latency_ms,
            p95_execution_latency_ms=p95_execution_latency_ms,
            p99_execution_latency_ms=p99_execution_latency_ms,
            fill_rate=fill_rate,
            partial_fill_rate=partial_fill_rate,
            rejection_rate=rejection_rate,
            total_commission=total_commission,
            total_fees=total_fees,
            total_execution_cost=total_execution_cost,
            cost_as_percent_of_pnl=cost_as_percent_of_pnl,
            max_intraday_drawdown=max_intraday_drawdown,
            sharpe_ratio=sharpe_ratio,
            sortino_ratio=sortino_ratio,
            calmar_ratio=calmar_ratio,
            information_ratio=information_ratio,
            tracking_error_bps=tracking_error_bps,
            realized_vs_expected_slippage_ratio=realized_vs_expected_slippage_ratio,
            alpha_decay_cost_bps=alpha_decay_cost_bps
        )
        
        self.metrics_history.append(metrics)
        return metrics
    
    def _calculate_pnl_series(self, trades: List[Dict]) -> np.ndarray:
        """Calculate cumulative PnL series."""
        if not trades:
            return np.array([])
        
        # Sort trades by timestamp
        sorted_trades = sorted(trades, key=lambda x: x.get('timestamp', ''))
        
        # Calculate cumulative PnL
        cumulative_pnl = 0.0
        pnl_series = []
        
        for trade in sorted_trades:
            cumulative_pnl += trade.get('pnl', 0)
            pnl_series.append(cumulative_pnl)
        
        return np.array(pnl_series)
    
    def _calculate_max_drawdown(self, pnl_series: np.ndarray) -> float:
        """Calculate maximum drawdown from PnL series."""
        if len(pnl_series) < 2:
            return 0.0
        
        peak = pnl_series[0]
        max_dd = 0.0
        
        for value in pnl_series:
            if value > peak:
                peak = value
            
            dd = (peak - value) / peak if peak > 0 else 0.0
            if dd > max_dd:
                max_dd = dd
        
        return max_dd
    
    def _calculate_sharpe_ratio(self, pnl_series: np.ndarray, 
                               risk_free_rate: float = 0.02) -> float:
        """Calculate annualized Sharpe ratio."""
        if len(pnl_series) < 2:
            return 0.0
        
        returns = np.diff(pnl_series) / np.abs(pnl_series[:-1])
        returns = returns[~np.isnan(returns)]
        
        if len(returns) < 2:
            return 0.0
        
        excess_returns = returns - risk_free_rate / 252  // Daily risk-free rate
        sharpe = np.mean(excess_returns) / np.std(excess_returns) * np.sqrt(252)
        
        return sharpe if not np.isnan(sharpe) else 0.0
    
    def _calculate_sortino_ratio(self, pnl_series: np.ndarray,
                                risk_free_rate: float = 0.02,
                                target_return: float = 0.0) -> float:
        """Calculate Sortino ratio."""
        if len(pnl_series) < 2:
            return 0.0
        
        returns = np.diff(pnl_series) / np.abs(pnl_series[:-1])
        returns = returns[~np.isnan(returns)]
        
        if len(returns) < 2:
            return 0.0
        
        excess_returns = returns - risk_free_rate / 252
        downside_returns = returns[returns < target_return]
        
        if len(downside_returns) < 2:
            return 0.0
        
        downside_std = np.std(downside_returns)
        if downside_std == 0:
            return 0.0
        
        sortino = np.mean(excess_returns) / downside_std * np.sqrt(252)
        return sortino if not np.isnan(sortino) else 0.0
    
    def _calculate_calmar_ratio(self, pnl_series: np.ndarray,
                               max_drawdown: float,
                               risk_free_rate: float = 0.02) -> float:
        """Calculate Calmar ratio."""
        if len(pnl_series) < 2 or max_drawdown == 0:
            return 0.0
        
        # Calculate annualized return
        total_return = (pnl_series[-1] - pnl_series[0]) / abs(pnl_series[0]) \
                      if pnl_series[0] != 0 else 0.0
        
        # Simple annualization (assuming daily data)
        n_days = len(pnl_series)
        if n_days > 252:
            annualized_return = (1 + total_return) ** (252 / n_days) - 1
        else:
            annualized_return = total_return * (252 / n_days) if n_days > 0 else 0.0
        
        excess_return = annualized_return - risk_free_rate
        
        calmar = excess_return / max_drawdown if max_drawdown > 0 else 0.0
        return calmar
    
    def _calculate_information_ratio(self, pnl_series: np.ndarray,
                                   benchmark_returns: Optional[np.ndarray] = None) -> float:
        """Calculate Information ratio."""
        if len(pnl_series) < 2:
            return 0.0
        
        returns = np.diff(pnl_series) / np.abs(pnl_series[:-1])
        returns = returns[~np.isnan(returns)]
        
        if len(returns) < 2:
            return 0.0
        
        if benchmark_returns is None:
            # Use zero as benchmark (absolute return)
            benchmark = np.zeros_like(returns)
        else:
            benchmark = benchmark_returns
        
        if len(benchmark) != len(returns):
            return 0.0
        
        active_returns = returns - benchmark
        information_ratio = np.mean(active_returns) / np.std(active_returns) * np.sqrt(252)
        
        return information_ratio if not np.isnan(information_ratio) else 0.0
    
    def _calculate_tracking_error(self, pnl_series: np.ndarray,
                                 benchmark_returns: Optional[np.ndarray] = None) -> float:
        """Calculate tracking error in basis points."""
        if len(pnl_series) < 2:
            return 0.0
        
        returns = np.diff(pnl_series) / np.abs(pnl_series[:-1])
        returns = returns[~np.isnan(returns)]
        
        if len(returns) < 2:
            return 0.0
        
        if benchmark_returns is None:
            # Use zero as benchmark
            benchmark = np.zeros_like(returns)
        else:
            benchmark = benchmark_returns
        
        if len(benchmark) != len(returns):
            return 0.0
        
        tracking_error = np.std(returns - benchmark) * np.sqrt(252) * 10000  // Convert to bps
        return tracking_error
    
    def calculate_vwap_performance(self, symbol: str, 
                                  start_time: datetime,
                                  end_time: datetime) -> Dict:
        """
        Calculate VWAP performance for a symbol in a time period.
        
        Args:
            symbol: Trading symbol
            start_time: Start of period
            end_time: End of period
            
        Returns:
            VWAP performance metrics
        """
        # Filter trades for symbol and time period
        trades = [t for t in self.trade_history 
                 if t.get('symbol') == symbol and
                 start_time <= datetime.fromisoformat(t['timestamp']) <= end_time]
        
        if not trades:
            return {}
        
        # Calculate VWAP
        total_value = sum(t.get('price', 0) * t.get('volume', 0) for t in trades)
        total_volume = sum(t.get('volume', 0) for t in trades)
        
        if total_volume == 0:
            return {}
        
        vwap = total_value / total_volume
        
        # Calculate arrival price (first trade price in period)
        first_trade = min(trades, key=lambda x: x['timestamp'])
        arrival_price = first_trade.get('price', 0)
        
        # Calculate VWAP slippage
        vwap_slippage_bps = ((vwap - arrival_price) / arrival_price * 10000) \
                           if arrival_price > 0 else 0.0
        
        # Calculate volume participation
        # This would need market volume data for proper calculation
        # Simplified: assume uniform participation
        
        return {
            'symbol': symbol,
            'period_start': start_time.isoformat(),
            'period_end': end_time.isoformat(),
            'vwap_price': vwap,
            'arrival_price': arrival_price,
            'vwap_slippage_bps': vwap_slippage_bps,
            'total_volume': total_volume,
            'n_trades': len(trades),
            'volume_distribution': self._calculate_volume_distribution(trades),
            'time_distribution': self._calculate_time_distribution(trades, start_time, end_time)
        }
    
    def _calculate_volume_distribution(self, trades: List[Dict]) -> Dict:
        """Calculate volume distribution across trades."""
        if not trades:
            return {}
        
        volumes = [t.get('volume', 0) for t in trades]
        
        return {
            'min_volume': min(volumes),
            'max_volume': max(volumes),
            'avg_volume': np.mean(volumes),
            'median_volume': np.median(volumes),
            'std_volume': np.std(volumes) if len(volumes) > 1 else 0.0,
            'volume_concentration': self._calculate_gini_coefficient(volumes)
        }
    
    def _calculate_time_distribution(self, trades: List[Dict],
                                   start_time: datetime,
                                   end_time: datetime) -> Dict:
        """Calculate time distribution of trades."""
        if not trades:
            return {}
        
        total_duration = (end_time - start_time).total_seconds()
        
        # Convert timestamps to seconds from start
        trade_times = []
        for trade in trades:
            trade_time = datetime.fromisoformat(trade['timestamp'])
            seconds_from_start = (trade_time - start_time).total_seconds()
            trade_times.append(seconds_from_start)
        
        trade_times.sort()
        
        # Calculate time intervals
        if len(trade_times) > 1:
            intervals = [trade_times[i+1] - trade_times[i] 
                        for i in range(len(trade_times)-1)]
            avg_interval = np.mean(intervals)
            std_interval = np.std(intervals) if len(intervals) > 1 else 0.0
        else:
            avg_interval = total_duration
            std_interval = 0.0
        
        # Calculate time concentration
        time_concentration = 1.0 - (len(trades) * avg_interval / total_duration) \
                           if total_duration > 0 else 0.0
        
        return {
            'first_trade_seconds': trade_times[0] if trade_times else 0.0,
            'last_trade_seconds': trade_times[-1] if trade_times else 0.0,
            'avg_interval_seconds': avg_interval,
            'std_interval_seconds': std_interval,
            'time_concentration': time_concentration,
            'trades_per_hour': len(trades) / (total_duration / 3600) \
                              if total_duration > 0 else 0.0
        }
    
    def _calculate_gini_coefficient(self, values: List[float]) -> float:
        """Calculate Gini coefficient for concentration measurement."""
        if not values or len(values) < 2:
            return 0.0
        
        values = np.sort(values)
        n = len(values)
        index = np.arange(1, n + 1)
        
        gini = (np.sum((2 * index - n - 1) * values)) / (n * np.sum(values))
        
        return gini if not np.isnan(gini) else 0.0
    
    def calculate_best_execution_analysis(self) -> Dict:
        """
        Analyze best execution compliance.
        
        Returns:
            Best execution analysis
        """
        if not self.trade_history:
            return {}
        
        # Calculate price improvement
        price_improvements = []
        for trade in self.trade_history:
            if 'arrival_price' in trade and 'execution_price' in trade:
                if trade.get('direction') == 'BUY':
                    improvement = trade['arrival_price'] - trade['execution_price']
                else:  // SELL
                    improvement = trade['execution_price'] - trade['arrival_price']
                
                if trade['arrival_price'] > 0:
                    improvement_bps = improvement / trade['arrival_price'] * 10000
                    price_improvements.append(improvement_bps)
        
        # Calculate market share (simplified)
        # This would need total market volume data
        
        # Calculate speed of execution
        execution_speeds = [t.get('execution_latency_ms', 0) 
                           for t in self.trade_history 
                           if 'execution_latency_ms' in t]
        
        # Calculate fill rate by order type
        order_types = set(o.get('order_type') for o in self.order_history)
        fill_rate_by_type = {}
        
        for order_type in order_types:
            type_orders = [o for o in self.order_history 
                          if o.get('order_type') == order_type]
            filled = [o for o in type_orders 
                     if o.get('status') in ['FILLED', 'PARTIALLY_FILLED']]
            
            fill_rate_by_type[order_type] = len(filled) / len(type_orders) \
                                           if type_orders else 0.0
        
        return {
            'price_improvement': {
                'avg_bps': np.mean(price_improvements) if price_improvements else 0.0,
                'positive_percentage': sum(1 for x in price_improvements if x > 0) / 
                                      len(price_improvements) * 100 
                                      if price_improvements else 0.0,
                'negative_percentage': sum(1 for x in price_improvements if x < 0) / 
                                      len(price_improvements) * 100 
                                      if price_improvements else 0.0
            },
            'execution_speed': {
                'avg_ms': np.mean(execution_speeds) if execution_speeds else 0.0,
                'p95_ms': np.percentile(execution_speeds, 95) if execution_speeds else 0.0,
                'p99_ms': np.percentile(execution_speeds, 99) if execution_speeds else 0.0
            },
            'fill_quality': {
                'overall_fill_rate': self.metrics_history[-1].fill_rate 
                                   if self.metrics_history else 0.0,
                'fill_rate_by_order_type': fill_rate_by_type,
                'partial_fill_impact': self._calculate_partial_fill_impact()
            },
            'best_execution_score': self._calculate_best_execution_score(),
            'regulatory_compliance': self._check_regulatory_compliance()
        }
    
    def _calculate_partial_fill_impact(self) -> Dict:
        """Calculate impact of partial fills."""
        partial_fills = [o for o in self.order_history 
                        if o.get('status') == 'PARTIALLY_FILLED']
        
        if not partial_fills:
            return {'n_partial_fills': 0, 'avg_completion_rate': 0.0}
        
        completion_rates = []
        for order in partial_fills:
            requested = order.get('size', 0)
            executed = order.get('executed_size', 0)
            if requested > 0:
                completion_rates.append(executed / requested)
        
        return {
            'n_partial_fills': len(partial_fills),
            'avg_completion_rate': np.mean(completion_rates) if completion_rates else 0.0,
            'min_completion_rate': min(completion_rates) if completion_rates else 0.0,
            'max_completion_rate': max(completion_rates) if completion_rates else 0.0,
            'completion_rate_std': np.std(completion_rates) if len(completion_rates) > 1 else 0.0
        }
    
    def _calculate_best_execution_score(self) -> Dict:
        """Calculate best execution score (0-100)."""
        if not self.metrics_history:
            return {'score': 0, 'components': {}}
        
        latest_metrics = self.metrics_history[-1]
        
        # Score components (each 0-20 points, total 100)
        components = {}
        
        # 1. Price improvement (20 points)
        # Positive improvement gets higher score
        price_score = min(20, max(0, 10 + latest_metrics.avg_slippage_bps * -10))
        components['price_improvement'] = price_score
        
        # 2. Execution speed (20 points)
        # Faster is better
        if latest_metrics.avg_execution_latency_ms < 10:
            speed_score = 20
        elif latest_metrics.avg_execution_latency_ms < 50:
            speed_score = 15
        elif latest_metrics.avg_execution_latency_ms < 100:
            speed_score = 10
        elif latest_metrics.avg_execution_latency_ms < 500:
            speed_score = 5
        else:
            speed_score = 0
        components['execution_speed'] = speed_score
        
        # 3. Fill rate (20 points)
        fill_score = latest_metrics.fill_rate * 20
        components['fill_rate'] = fill_score
        
        # 4. Cost efficiency (20 points)
        # Lower costs relative to PnL is better
        if latest_metrics.cost_as_percent_of_pnl < 10:
            cost_score = 20
        elif latest_metrics.cost_as_percent_of_pnl < 20:
            cost_score = 15
        elif latest_metrics.cost_as_percent_of_pnl < 30:
            cost_score = 10
        elif latest_metrics.cost_as_percent_of_pnl < 50:
            cost_score = 5
        else:
            cost_score = 0
        components['cost_efficiency'] = cost_score
        
        # 5. Consistency (20 points)
        # Low variance in execution quality
        if len(self.metrics_history) >= 5:
            recent_slippages = [m.avg_slippage_bps for m in self.metrics_history[-5:]]
            consistency = 1.0 / (1.0 + np.std(recent_slippages))
            consistency_score = consistency * 20
        else:
            consistency_score = 10
        components['consistency'] = consistency_score
        
        total_score = sum(components.values())
        
        return {
            'score': total_score,
            'components': components,
            'grade': 'A' if total_score >= 90 else
                    'B' if total_score >= 80 else
                    'C' if total_score >= 70 else
                    'D' if total_score >= 60 else 'F'
        }
    
    def _check_regulatory_compliance(self) -> Dict:
        """Check regulatory compliance for best execution."""
        if not self.metrics_history:
            return {'compliant': False, 'violations': []}
        
        latest_metrics = self.metrics_history[-1]
        violations = []
        
        # MiFID II / Reg NMS compliance checks
        
        # 1. Price improvement check
        if latest_metrics.avg_slippage_bps > 10:  // More than 10 bps slippage
            violations.append({
                'rule': 'PRICE_IMPROVEMENT',
                'description': 'Average slippage exceeds 10 bps',
                'value': f'{latest_metrics.avg_slippage_bps:.2f} bps',
                'threshold': '10 bps'
            })
        
        # 2. Fill rate check
        if latest_metrics.fill_rate < 0.8:  // Less than 80% fill rate
            violations.append({
                'rule': 'FILL_RATE',
                'description': 'Fill rate below 80%',
                'value': f'{latest_metrics.fill_rate:.1%}',
                'threshold': '80%'
            })
        
        # 3. Execution speed check
        if latest_metrics.p95_execution_latency_ms > 1000:  // More than 1 second
            violations.append({
                'rule': 'EXECUTION_SPEED',
                'description': '95th percentile execution latency exceeds 1 second',
                'value': f'{latest_metrics.p95_execution_latency_ms:.0f} ms',
                'threshold': '1000 ms'
            })
        
        # 4. Cost transparency
        if latest_metrics.cost_as_percent_of_pnl > 50:  // Costs > 50% of PnL
            violations.append({
                'rule': 'COST_TRANSPARENCY',
                'description': 'Execution costs exceed 50% of PnL',
                'value': f'{latest_metrics.cost_as_percent_of_pnl:.1%}',
                'threshold': '50%'
            })
        
        return {
            'compliant': len(violations) == 0,
            'violations': violations,
            'checks_performed': 4,
            'checks_passed': 4 - len(violations)
        }
    
    def generate_execution_report(self) -> Dict:
        """Generate comprehensive execution report."""
        latest_metrics = self.metrics_history[-1] if self.metrics_history else None
        
        if not latest_metrics:
            return {}
        
        best_execution = self.calculate_best_execution_analysis()
        regulatory_compliance = self._check_regulatory_compliance()
        
        # Performance attribution
        performance_attribution = self._calculate_performance_attribution()
        
        # Benchmark comparison
        benchmark_comparison = self._compare_to_benchmarks()
        
        # Recommendations
        recommendations = self._generate_recommendations(latest_metrics, best_execution)
        
        return {
            'summary': {
                'period_analyzed': {
                    'start': self.trade_history[0]['timestamp'] if self.trade_history else None,
                    'end': self.trade_history[-1]['timestamp'] if self.trade_history else None,
                    'n_days': len(set(t['timestamp'][:10] for t in self.trade_history)) 
                             if self.trade_history else 0
                },
                'key_metrics': latest_metrics.to_dict(),
                'best_execution_score': best_execution.get('best_execution_score', {}),
                'regulatory_compliance': regulatory_compliance
            },
            'detailed_analysis': {
                'performance_attribution': performance_attribution,
                'benchmark_comparison': benchmark_comparison,
                'cost_breakdown': self._calculate_cost_breakdown(),
                'execution_quality_trends': self._analyze_execution_trends()
            },
            'recommendations': recommendations,
            'appendix': {
                'methodology': 'Execution quality analysis based on MiFID II best execution principles',
                'risk_disclosures': 'Past performance is not indicative of future results',
                'data_quality': self._assess_data_quality()
            }
        }
    
    def _calculate_performance_attribution(self) -> Dict:
        """Attribute performance to different factors."""
        if not self.trade_history:
            return {}
        
        # Simplified attribution
        total_pnl = sum(t.get('pnl', 0) for t in self.trade_history)
        
        # Attribute to market moves vs alpha
        # This is simplified - real attribution would need benchmark
        market_pnl = total_pnl * 0.6  // Assume 60% market
        alpha_pnl = total_pnl * 0.4   // Assume 40% alpha
        
        # Execution costs
        execution_costs = sum(t.get('commission', 0) + t.get('fee', 0) + 
                             t.get('slippage_cost', 0) for t in self.trade_history)
        
        # Net performance
        net_pnl = total_pnl - execution_costs
        
        return {
            'gross_performance': {
                'total': total_pnl,
                'market_contribution': market_pnl,
                'alpha_contribution': alpha_pnl,
                'market_contribution_pct': (market_pnl / total_pnl * 100) if total_pnl != 0 else 0.0,
                'alpha_contribution_pct': (alpha_pnl / total_pnl * 100) if total_pnl != 0 else 0.0
            },
            'costs': {
                'total': execution_costs,
                'as_percent_of_gross': (execution_costs / total_pnl * 100) if total_pnl != 0 else 0.0,
                'breakdown': {
                    'commissions': sum(t.get('commission', 0) for t in self.trade_history),
                    'fees': sum(t.get('fee', 0) for t in self.trade_history),
                    'slippage': sum(t.get('slippage_cost', 0) for t in self.trade_history),
                    'adverse_selection': sum(t.get('adverse_selection_cost', 0) 
                                           for t in self.trade_history 
                                           if 'adverse_selection_cost' in t)
                }
            },
            'net_performance': {
                'total': net_pnl,
                'net_vs_gross_ratio': (net_pnl / total_pnl) if total_pnl != 0 else 0.0
            }
        }
    
    def _compare_to_benchmarks(self) -> Dict:
        """Compare execution to benchmarks."""
        # Simplified - real implementation would fetch benchmark data
        if not self.trade_history:
            return {}
        
        latest_metrics = self.metrics_history[-1]
        
        # Industry benchmarks (simplified)
        industry_benchmarks = {
            'avg_slippage_bps': 5.0,      // Industry average
            'fill_rate': 0.85,            // Industry average
            'execution_latency_ms': 50.0,  // Industry average
            'sharpe_ratio': 1.5           // Good benchmark
        }
        
        comparison = {}
        for metric, benchmark in industry_benchmarks.items():
            actual = getattr(latest_metrics, metric, 0)
            
            if metric in ['avg_slippage_bps', 'execution_latency_ms']:
                # Lower is better
                comparison[metric] = {
                    'actual': actual,
                    'benchmark': benchmark,
                    'vs_benchmark': ((benchmark - actual) / benchmark * 100) 
                                   if benchmark > 0 else 0.0,
                    'better': actual < benchmark
                }
            else:
                # Higher is better
                comparison[metric] = {
                    'actual': actual,
                    'benchmark': benchmark,
                    'vs_benchmark': ((actual - benchmark) / benchmark * 100) 
                                   if benchmark > 0 else 0.0,
                    'better': actual > benchmark
                }
        
        return {
            'industry_benchmarks': comparison,
            'overall_ranking': self._calculate_overall_ranking(comparison),
            'percentile_estimates': self._estimate_percentiles(latest_metrics)
        }
    
    def _calculate_overall_ranking(self, comparison: Dict) -> Dict:
        """Calculate overall ranking vs benchmarks."""
        if not comparison:
            return {}
        
        # Count better/worse metrics
        better = sum(1 for metric in comparison.values() if metric['better'])
        total = len(comparison)
        
        score = better / total * 100 if total > 0 else 0.0
        
        return {
            'score': score,
            'better_than_benchmark': f'{better}/{total} metrics',
            'ranking': 'TOP_QUARTILE' if score >= 75 else
                      'ABOVE_AVERAGE' if score >= 50 else
                      'BELOW_AVERAGE' if score >= 25 else
                      'BOTTOM_QUARTILE'
        }
    
    def _estimate_percentiles(self, metrics: ExecutionMetrics) -> Dict:
        """Estimate percentile rankings for metrics."""
        # Simplified percentiles based on industry data
        # Real implementation would use historical distribution
        
        percentiles = {}
        
        # Slippage percentiles (lower is better)
        if metrics.avg_slippage_bps < 2:
            percentiles['slippage'] = 90
        elif metrics.avg_slippage_bps < 5:
            percentiles['slippage'] = 70
        elif metrics.avg_slippage_bps < 10:
            percentiles['slippage'] = 50
        elif metrics.avg_slippage_bps < 20:
            percentiles['slippage'] = 30
        else:
            percentiles['slippage'] = 10
        
        # Fill rate percentiles (higher is better)
        if metrics.fill_rate > 0.95:
            percentiles['fill_rate'] = 90
        elif metrics.fill_rate > 0.90:
            percentiles['fill_rate'] = 70
        elif metrics.fill_rate > 0.85:
            percentiles['fill_rate'] = 50
        elif metrics.fill_rate > 0.80:
            percentiles['fill_rate'] = 30
        else:
            percentiles['fill_rate'] = 10
        
        # Sharpe ratio percentiles (higher is better)
        if metrics.sharpe_ratio > 2.0:
            percentiles['sharpe_ratio'] = 90
        elif metrics.sharpe_ratio > 1.5:
            percentiles['sharpe_ratio'] = 70
        elif metrics.sharpe_ratio > 1.0:
            percentiles['sharpe_ratio'] = 50
        elif metrics.sharpe_ratio > 0.5:
            percentiles['sharpe_ratio'] = 30
        else:
            percentiles['sharpe_ratio'] = 10
        
        return percentiles
    
    def _calculate_cost_breakdown(self) -> Dict:
        """Calculate detailed cost breakdown."""
        if not self.trade_history:
            return {}
        
        total_costs = 0.0
        cost_components = {
            'commissions': 0.0,
            'fees': 0.0,
            'slippage': 0.0,
            'market_impact': 0.0,
            'adverse_selection': 0.0,
            'opportunity_cost': 0.0,
            'alpha_decay': 0.0
        }
        
        for trade in self.trade_history:
            cost_components['commissions'] += trade.get('commission', 0)
            cost_components['fees'] += trade.get('fee', 0)
            cost_components['slippage'] += trade.get('slippage_cost', 0)
            cost_components['market_impact'] += trade.get('market_impact_cost', 0)
            cost_components['adverse_selection'] += trade.get('adverse_selection_cost', 0)
            cost_components['opportunity_cost'] += trade.get('opportunity_cost', 0)
            cost_components['alpha_decay'] += trade.get('alpha_decay_cost', 0)
        
        total_costs = sum(cost_components.values())
        
        # Calculate percentages
        if total_costs > 0:
            cost_percentages = {k: v / total_costs * 100 for k, v in cost_components.items()}
        else:
            cost_percentages = {k: 0.0 for k in cost_components.keys()}
        
        return {
            'total_costs': total_costs,
            'absolute_costs': cost_components,
            'relative_costs': cost_percentages,
            'largest_cost_component': max(cost_components.items(), key=lambda x: x[1])[0] 
                                     if total_costs > 0 else None,
            'cost_efficiency_score': self._calculate_cost_efficiency_score(cost_components)
        }
    
    def _calculate_cost_efficiency_score(self, cost_components: Dict) -> float:
        """Calculate cost efficiency score (0-100)."""
        total_costs = sum(cost_components.values())
        
        if total_costs == 0:
            return 100.0
        
        # Penalize high adverse selection and opportunity costs
        adverse_ratio = cost_components['adverse_selection'] / total_costs
        opportunity_ratio = cost_components['opportunity_cost'] / total_costs
        
        # Base score
        base_score = 70.0
        
        # Adjust for adverse selection
        if adverse_ratio > 0.3:
            base_score -= 30
        elif adverse_ratio > 0.2:
            base_score -= 20
        elif adverse_ratio > 0.1:
            base_score -= 10
        
        # Adjust for opportunity cost
        if opportunity_ratio > 0.2:
            base_score -= 20
        elif opportunity_ratio > 0.1:
            base_score -= 10
        
        return max(0.0, min(100.0, base_score))
    
    def _analyze_execution_trends(self) -> Dict:
        """Analyze trends in execution quality over time."""
        if len(self.metrics_history) < 5:
            return {}
        
        recent_metrics = self.metrics_history[-10:]  // Last 10 periods
        
        trends = {}
        metrics_to_analyze = [
            'avg_slippage_bps',
            'fill_rate', 
            'avg_execution_latency_ms',
            'sharpe_ratio'
        ]
        
        for metric in metrics_to_analyze:
            values = [getattr(m, metric) for m in recent_metrics]
            
            if len(values) >= 3:
                # Calculate trend
                x = np.arange(len(values))
                slope, _ = np.polyfit(x, values, 1)
                
                # Calculate percentage change
                if values[0] != 0:
                    pct_change = ((values[-1] - values[0]) / abs(values[0])) * 100
                else:
                    pct_change = 0.0
                
                # Determine direction
                if abs(slope) < 0.01:  // Flat
                    direction = 'FLAT'
                elif slope > 0:
                    if metric in ['avg_slippage_bps', 'avg_execution_latency_ms']:
                        direction = 'DETERIORATING'  // Higher is worse
                    else:
                        direction = 'IMPROVING'  // Higher is better
                else:
                    if metric in ['avg_slippage_bps', 'avg_execution_latency_ms']:
                        direction = 'IMPROVING'  // Lower is better
                    else:
                        direction = 'DETERIORATING'  // Lower is worse
                
                trends[metric] = {
                    'current': values[-1],
                    'trend_slope': slope,
                    'percent_change': pct_change,
                    'direction': direction,
                    'volatility': np.std(values) if len(values) > 1 else 0.0
                }
        
        return trends
    
    def _assess_data_quality(self) -> Dict:
        """Assess quality of execution data."""
        if not self.trade_history:
            return {'quality_score': 0, 'issues': []}
        
        issues = []
        score = 100
        
        # Check 1: Missing fields
        required_fields = ['timestamp', 'symbol', 'price', 'volume', 'pnl']
        for trade in self.trade_history[:10]:  // Sample check
            missing = [field for field in required_fields if field not in trade]
            if missing:
                issues.append(f'Missing fields in trades: {missing}')
                score -= 10
                break
        
        # Check 2: Data consistency
        prices = [t.get('price', 0) for t in self.trade_history]
        if any(p <= 0 for p in prices):
            issues.append('Invalid prices (<= 0) found')
            score -= 10
        
        volumes = [t.get('volume', 0) for t in self.trade_history]
        if any(v <= 0 for v in volumes):
            issues.append('Invalid volumes (<= 0) found')
            score -= 10
        
        # Check 3: Timestamp consistency
        timestamps = [t.get('timestamp') for t in self.trade_history]
        try:
            datetime_objects = [datetime.fromisoformat(ts) for ts in timestamps if ts]
            if len(datetime_objects) > 1:
                # Check for reasonable timestamps (not in future)
                now = datetime.now()
                future_timestamps = sum(1 for ts in datetime_objects if ts > now)
                if future_timestamps > 0:
                    issues.append(f'{future_timestamps} timestamps in the future')
                    score -= 20
        except:
            issues.append('Invalid timestamp format')
            score -= 20
        
        # Check 4: Data completeness
        n_trades = len(self.trade_history)
        n_orders = len(self.order_history)
        
        if n_orders > 0:
            fill_rate = n_trades / n_orders
            if fill_rate > 1.5 or fill_rate < 0.5:
                issues.append(f'Suspicious fill rate: {fill_rate:.2f}')
                score -= 10
        
        return {
            'quality_score': max(0, score),
            'issues': issues,
            'data_volume': {
                'trades': n_trades,
                'orders': n_orders,
                'period_covered_days': self._calculate_period_covered()
            },
            'recommendations': self._generate_data_quality_recommendations(issues)
        }
    
    def _calculate_period_covered(self) -> int:
        """Calculate number of days covered by data."""
        if not self.trade_history:
            return 0
        
        timestamps = [t.get('timestamp') for t in self.trade_history]
        try:
            dates = [datetime.fromisoformat(ts).date() for ts in timestamps if ts]
            unique_dates = len(set(dates))
            return unique_dates
        except:
            return 0
    
    def _generate_data_quality_recommendations(self, issues: List[str]) -> List[str]:
        """Generate recommendations for improving data quality."""
        recommendations = []
        
        if 'Missing fields' in str(issues):
            recommendations.append('Add missing required fields to trade records')
        
        if 'Invalid prices' in str(issues) or 'Invalid volumes' in str(issues):
            recommendations.append('Implement data validation for prices and volumes')
        
        if 'timestamps in the future' in str(issues):
            recommendations.append('Fix timestamp generation logic')
        
        if 'Invalid timestamp format' in str(issues):
            recommendations.append('Standardize timestamp format to ISO 8601')
        
        if 'Suspicious fill rate' in str(issues):
            recommendations.append('Review order/trade matching logic')
        
        if not recommendations and issues:
            recommendations.append('Review data collection and validation processes')
        
        if not issues:
            recommendations.append('Data quality is good - maintain current processes')
        
        return recommendations
    
    def _generate_recommendations(self, metrics: ExecutionMetrics,
                                 best_execution: Dict) -> List[Dict]:
        """Generate recommendations for improving execution."""
        recommendations = []
        
        # Check slippage
        if metrics.avg_slippage_bps > 10:
            recommendations.append({
                'priority': 'HIGH',
                'area': 'Execution Quality',
                'recommendation': 'Reduce average slippage',
                'action': 'Consider using limit orders or VWAP/TWAP strategies',
                'expected_impact': 'Medium',
                'current_value': f'{metrics.avg_slippage_bps:.2f} bps',
                'target': '< 5 bps'
            })
        
        # Check fill rate
        if metrics.fill_rate < 0.8:
            recommendations.append({
                'priority': 'HIGH',
                'area': 'Fill Quality',
                'recommendation': 'Improve fill rate',
                'action': 'Review order placement timing and sizes',
                'expected_impact': 'High',
                'current_value': f'{metrics.fill_rate:.1%}',
                'target': '> 85%'
            })
        
        # Check latency
        if metrics.p95_execution_latency_ms > 1000:
            recommendations.append({
                'priority': 'MEDIUM',
                'area': 'Execution Speed',
                'recommendation': 'Reduce execution latency',
                'action': 'Review network infrastructure and exchange connectivity',
                'expected_impact': 'Medium',
                'current_value': f'{metrics.p95_execution_latency_ms:.0f} ms',
                'target': '< 500 ms'
            })
        
        # Check costs
        if metrics.cost_as_percent_of_pnl > 30:
            recommendations.append({
                'priority': 'HIGH',
                'area': 'Cost Efficiency',
                'recommendation': 'Reduce execution costs',
                'action': 'Analyze cost breakdown and optimize largest cost components',
                'expected_impact': 'High',
                'current_value': f'{metrics.cost_as_percent_of_pnl:.1%}',
                'target': '< 20%'
            })
        
        # Check adverse selection
        if metrics.avg_adverse_selection_bps > 5:
            recommendations.append({
                'priority': 'MEDIUM',
                'area': 'Adverse Selection',
                'recommendation': 'Reduce adverse selection costs',
                'action': 'Avoid trading during high toxicity periods',
                'expected_impact': 'Medium',
                'current_value': f'{metrics.avg_adverse_selection_bps:.2f} bps',
                'target': '< 2 bps'
            })
        
        # Check best execution score
        best_exec_score = best_execution.get('best_execution_score', {}).get('score', 0)
        if best_exec_score < 70:
            recommendations.append({
                'priority': 'HIGH',
                'area': 'Best Execution',
                'recommendation': 'Improve best execution compliance',
                'action': 'Review and optimize across all execution quality dimensions',
                'expected_impact': 'High',
                'current_value': f'{best_exec_score:.0f}/100',
                'target': '> 80/100'
            })
        
        return recommendations