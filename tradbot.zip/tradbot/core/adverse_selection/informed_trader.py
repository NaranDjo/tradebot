"""
Probability of Informed Trading (PIN/VPIN) models v4.0.
Models informed vs uninformed trader behavior.
"""

import numpy as np
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from collections import deque
import math


@dataclass
class TradeClassification:
    """Classification of a trade as buy/sell and informed/uninformed."""
    timestamp: float
    price: float
    volume: float
    classification: str  # 'INFORMED_BUY', 'INFORMED_SELL', 'UNINFORMED_BUY', 'UNINFORMED_SELL'
    confidence: float  # Classification confidence (0-1)


class InformedTraderModel:
    """
    Models probability of informed trading using PIN framework.
    
    Based on: Easley, D., Kiefer, N., et al. (1996) "Liquidity, Information, 
    and Infrequently Traded Stocks."
    """
    
    def __init__(self, volume_bar_size: float = 1000.0, 
                 window_size: int = 100):
        """
        Args:
            volume_bar_size: Size of volume bars for classification
            window_size: Rolling window for parameter estimation
        """
        self.volume_bar_size = volume_bar_size
        self.window_size = window_size
        
        # PIN model parameters
        self.alpha = 0.5      # Probability of information event
        self.delta = 0.5      # Probability good news given information event
        self.mu = 1.0         # Arrival rate of informed traders
        self.epsilon_b = 1.0  # Arrival rate of uninformed buyers
        self.epsilon_s = 1.0  # Arrival rate of uninformed sellers
        
        # State tracking
        self.trade_history: List[TradeClassification] = []
        self.volume_bar_history: deque = deque(maxlen=window_size * 10)
        self.pin_history: List[float] = []
        
    def classify_trade(self, timestamp: float, price: float, 
                      volume: float, order_flow: str) -> TradeClassification:
        """
        Classify a trade as informed/uninformed.
        
        Args:
            order_flow: 'BUY' or 'SELL'
            
        Returns:
            Trade classification
        """
        # Calculate PIN-based probability
        pin_prob = self.calculate_pin()
        
        # Factors affecting classification
        factors = self._calculate_classification_factors(
            price, volume, order_flow
        )
        
        # Informed probability combines PIN and factors
        informed_prob = pin_prob * factors['informed_factor']
        
        # Make classification
        if informed_prob > 0.7:
            classification = f'INFORMED_{order_flow}'
            confidence = informed_prob
        elif informed_prob > 0.4:
            # Ambiguous - use volume-based classification
            if volume > self.volume_bar_size * 2:
                classification = f'INFORMED_{order_flow}'
                confidence = 0.6
            else:
                classification = f'UNINFORMED_{order_flow}'
                confidence = 0.6
        else:
            classification = f'UNINFORMED_{order_flow}'
            confidence = 1.0 - informed_prob
        
        classification_obj = TradeClassification(
            timestamp=timestamp,
            price=price,
            volume=volume,
            classification=classification,
            confidence=confidence
        )
        
        self.trade_history.append(classification_obj)
        self._update_volume_bars(classification_obj)
        
        return classification_obj
    
    def _calculate_classification_factors(self, price: float, volume: float,
                                        order_flow: str) -> Dict:
        """Calculate factors affecting informed classification."""
        factors = {
            'informed_factor': 0.5,  # Base
            'volume_factor': 0.0,
            'price_factor': 0.0,
            'timing_factor': 0.0
        }
        
        # Volume factor (large trades more likely informed)
        if volume > self.volume_bar_size * 3:
            factors['volume_factor'] = 0.8
        elif volume > self.volume_bar_size:
            factors['volume_factor'] = 0.4
        else:
            factors['volume_factor'] = 0.1
        
        # Price factor (aggressive moves more likely informed)
        # This would require price history - simplified
        factors['price_factor'] = 0.3
        
        # Timing factor (clustered trades more likely informed)
        if len(self.trade_history) > 0:
            last_trade = self.trade_history[-1]
            time_diff = (abs(last_trade.timestamp) / 1000) if hasattr(last_trade, 'timestamp') else 1.0
            if time_diff < 1.0:  # Trades within 1 second
                factors['timing_factor'] = 0.5
        
        # Combine factors
        factors['informed_factor'] = min(0.95, 0.5 + 
            factors['volume_factor'] * 0.3 +
            factors['price_factor'] * 0.15 +
            factors['timing_factor'] * 0.05)
        
        return factors
    
    def _update_volume_bars(self, trade: TradeClassification):
        """Update volume bars for VPIN calculation."""
        self.volume_bar_history.append(trade)
        
        # Re-estimate parameters when we have enough data
        if len(self.volume_bar_history) >= self.window_size:
            self._estimate_parameters()
    
    def _estimate_parameters(self):
        """Estimate PIN model parameters using EM algorithm."""
        # Simplified estimation - in production use full EM algorithm
        
        # Count buys and sells in window
        recent_trades = list(self.volume_bar_history)[-self.window_size:]
        
        buy_trades = [t for t in recent_trades if 'BUY' in t.classification]
        sell_trades = [t for t in recent_trades if 'SELL' in t.classification]
        
        informed_buys = [t for t in buy_trades if 'INFORMED' in t.classification]
        informed_sells = [t for t in sell_trades if 'INFORMED' in t.classification]
        
        n_buys = len(buy_trades)
        n_sells = len(sell_trades)
        n_informed_buys = len(informed_buys)
        n_informed_sells = len(informed_sells)
        
        if n_buys + n_sells == 0:
            return
        
        # Simplified parameter updates
        self.alpha = min(0.95, (n_informed_buys + n_informed_sells) / (n_buys + n_sells))
        
        if n_informed_buys + n_informed_sells > 0:
            self.delta = n_informed_buys / (n_informed_buys + n_informed_sells)
        
        # Arrival rates
        time_window = 1.0  # Assume 1-hour window for simplicity
        self.mu = (n_informed_buys + n_informed_sells) / time_window
        self.epsilon_b = max(0.1, n_buys / time_window - self.mu * self.delta)
        self.epsilon_s = max(0.1, n_sells / time_window - self.mu * (1 - self.delta))
    
    def calculate_pin(self) -> float:
        """
        Calculate Probability of Informed Trading (PIN).
        
        PIN = (α * μ) / (α * μ + ε_b + ε_s)
        """
        numerator = self.alpha * self.mu
        denominator = numerator + self.epsilon_b + self.epsilon_s
        
        if denominator == 0:
            return 0.0
        
        return numerator / denominator
    
    def calculate_vpin(self, volume_bars: int = 50) -> float:
        """
        Calculate Volume-synchronized PIN.
        
        VPIN = Σ|V_buy - V_sell| / (V_buy + V_sell) over volume bars
        """
        if len(self.volume_bar_history) < volume_bars:
            return 0.0
        
        recent_bars = list(self.volume_bar_history)[-volume_bars:]
        
        total_volume = sum(t.volume for t in recent_bars)
        buy_volume = sum(t.volume for t in recent_bars if 'BUY' in t.classification)
        sell_volume = sum(t.volume for t in recent_bars if 'SELL' in t.classification)
        
        if total_volume == 0:
            return 0.0
        
        volume_imbalance = abs(buy_volume - sell_volume)
        vpin = volume_imbalance / total_volume
        
        self.pin_history.append(vpin)
        return vpin
    
    def predict_informed_flow(self, horizon_minutes: int = 5) -> Dict:
        """
        Predict informed trading flow in the near future.
        
        Returns:
            Prediction of informed trading probability
        """
        pin = self.calculate_pin()
        vpin = self.calculate_vpin()
        
        # Combine PIN and VPIN
        combined_prob = (pin + vpin) / 2
        
        # Adjust based on recent trends
        if len(self.pin_history) >= 10:
            recent_pin = np.mean(self.pin_history[-10:])
            trend = combined_prob - recent_pin
        else:
            trend = 0.0
        
        # Prediction
        prediction = min(0.95, combined_prob + trend * 0.5)
        
        return {
            'pin': pin,
            'vpin': vpin,
            'combined_probability': combined_prob,
            'predicted_probability': prediction,
            'trend': trend,
            'horizon_minutes': horizon_minutes,
            'confidence': self._calculate_prediction_confidence(),
            'recommendation': self._generate_recommendation(prediction)
        }
    
    def _calculate_prediction_confidence(self) -> float:
        """Calculate confidence in prediction."""
        if len(self.trade_history) < 100:
            return 0.3
        
        # Confidence based on data quantity and parameter stability
        data_confidence = min(1.0, len(self.trade_history) / 1000)
        
        # Parameter stability (simplified)
        if len(self.pin_history) >= 20:
            pin_std = np.std(self.pin_history[-20:])
            stability = 1.0 / (1.0 + pin_std * 10)
        else:
            stability = 0.5
        
        return data_confidence * stability
    
    def _generate_recommendation(self, informed_prob: float) -> str:
        """Generate trading recommendation based on informed probability."""
        if informed_prob > 0.7:
            return "HIGH_INFORMED_FLOW - Avoid trading, high adverse selection risk"
        elif informed_prob > 0.4:
            return "MODERATE_INFORMED_FLOW - Reduce position sizes, use limit orders"
        elif informed_prob > 0.2:
            return "LOW_INFORMED_FLOW - Normal trading conditions"
        else:
            return "VERY_LOW_INFORMED_FLOW - Favorable trading conditions"
    
    def get_market_microstructure_metrics(self) -> Dict:
        """Get comprehensive market microstructure metrics."""
        pin = self.calculate_pin()
        vpin = self.calculate_vpin()
        
        recent_trades = list(self.volume_bar_history)[-self.window_size:] \
                       if len(self.volume_bar_history) >= self.window_size \
                       else list(self.volume_bar_history)
        
        if not recent_trades:
            return {}
        
        # Classify trades
        informed_buys = [t for t in recent_trades 
                        if t.classification == 'INFORMED_BUY']
        informed_sells = [t for t in recent_trades 
                         if t.classification == 'INFORMED_SELL']
        uninformed_buys = [t for t in recent_trades 
                          if t.classification == 'UNINFORMED_BUY']
        uninformed_sells = [t for t in recent_trades 
                           if t.classification == 'UNINFORMED_SELL']
        
        # Calculate metrics
        total_volume = sum(t.volume for t in recent_trades)
        informed_volume = sum(t.volume for t in informed_buys + informed_sells)
        uninformed_volume = sum(t.volume for t in uninformed_buys + uninformed_sells)
        
        buy_pressure = sum(t.volume for t in informed_buys + uninformed_buys)
        sell_pressure = sum(t.volume for t in informed_sells + uninformed_sells)
        
        order_imbalance = (buy_pressure - sell_pressure) / total_volume \
                         if total_volume > 0 else 0.0
        
        return {
            'pin': pin,
            'vpin': vpin,
            'informed_volume_ratio': informed_volume / total_volume 
                                    if total_volume > 0 else 0.0,
            'informed_trade_ratio': (len(informed_buys) + len(informed_sells)) 
                                   / len(recent_trades) if recent_trades else 0.0,
            'order_imbalance': order_imbalance,
            'buy_pressure_ratio': buy_pressure / total_volume 
                                 if total_volume > 0 else 0.5,
            'sell_pressure_ratio': sell_pressure / total_volume 
                                  if total_volume > 0 else 0.5,
            'informed_buy_ratio': sum(t.volume for t in informed_buys) / buy_pressure 
                                 if buy_pressure > 0 else 0.0,
            'informed_sell_ratio': sum(t.volume for t in informed_sells) / sell_pressure 
                                  if sell_pressure > 0 else 0.0,
            'market_state': self._classify_market_state(pin, order_imbalance),
            'parameters': {
                'alpha': self.alpha,
                'delta': self.delta,
                'mu': self.mu,
                'epsilon_b': self.epsilon_b,
                'epsilon_s': self.epsilon_s
            }
        }
    
    def _classify_market_state(self, pin: float, order_imbalance: float) -> str:
        """Classify current market state."""
        if pin > 0.6:
            if order_imbalance > 0.1:
                return 'INFORMED_BUYING'
            elif order_imbalance < -0.1:
                return 'INFORMED_SELLING'
            else:
                return 'HIGH_INFORMATION_NO_DIRECTION'
        elif pin > 0.3:
            return 'MIXED_INFORMATION'
        else:
            if abs(order_imbalance) > 0.2:
                return 'UNINFORMED_TREND'
            else:
                return 'LIQUIDITY_PROVISION'