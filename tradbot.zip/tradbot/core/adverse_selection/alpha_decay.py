"""
Alpha decay modeling v4.0.
Models the decay of trading signal alpha over time.
"""

import numpy as np
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from enum import Enum
import math


class DecayModelType(Enum):
    """Types of alpha decay models."""
    EXPONENTIAL = "exponential"
    POWER_LAW = "power_law"
    LINEAR = "linear"
    HYPERBOLIC = "hyperbolic"


@dataclass
class DecayParameters:
    """Parameters for alpha decay model."""
    model_type: DecayModelType
    half_life_hours: float  # Time for alpha to decay to 50%
    decay_rate: float       # Decay rate parameter
    initial_alpha: float    # Initial alpha value
    minimum_alpha: float = 0.0  # Minimum alpha value (floor)
    
    def validate(self):
        """Validate decay parameters."""
        assert self.half_life_hours > 0, "Half-life must be positive"
        assert self.initial_alpha >= self.minimum_alpha, \
            "Initial alpha must be >= minimum alpha"
        
        if self.model_type == DecayModelType.EXPONENTIAL:
            assert self.decay_rate > 0, "Decay rate must be positive for exponential"
        elif self.model_type == DecayModelType.POWER_LAW:
            assert self.decay_rate != 0, "Decay exponent cannot be zero"


class AlphaDecayModel:
    """
    Models the decay of trading signal alpha over time.
    
    Different decay models:
    1. Exponential: α(t) = α₀ * exp(-λt)
    2. Power Law: α(t) = α₀ * (1 + t/τ)^{-β}
    3. Linear: α(t) = α₀ * max(0, 1 - t/T)
    4. Hyperbolic: α(t) = α₀ / (1 + γt)
    """
    
    def __init__(self, model_type: DecayModelType = DecayModelType.EXPONENTIAL,
                 half_life_hours: float = 24.0, initial_alpha: float = 10.0):
        """
        Args:
            model_type: Type of decay model
            half_life_hours: Time for alpha to decay to 50%
            initial_alpha: Initial alpha value (in basis points)
        """
        self.model_type = model_type
        self.half_life_hours = half_life_hours
        self.initial_alpha = initial_alpha
        
        # Calculate decay parameters based on half-life
        self.params = self._calculate_decay_parameters()
        
        # Tracking
        self.decay_history: List[Dict] = []
        self.model_fit_history: List[DecayParameters] = []
    
    def _calculate_decay_parameters(self) -> DecayParameters:
        """Calculate decay parameters from half-life."""
        if self.model_type == DecayModelType.EXPONENTIAL:
            # For exponential: α(t) = α₀ * exp(-λt)
            # Half-life: t_half = ln(2)/λ ⇒ λ = ln(2)/t_half
            decay_rate = math.log(2) / self.half_life_hours
        
        elif self.model_type == DecayModelType.POWER_LAW:
            # For power law: α(t) = α₀ * (1 + t/τ)^{-β}
            # At half-life: (1 + t_half/τ)^{-β} = 0.5
            # Choose τ = t_half, then β = 1 (simplification)
            decay_rate = 1.0  # β parameter
        
        elif self.model_type == DecayModelType.LINEAR:
            # For linear: α(t) = α₀ * max(0, 1 - t/T)
            # Half-life when t = T/2
            decay_rate = 1.0 / (self.half_life_hours * 2)  # 1/T
        
        elif self.model_type == DecayModelType.HYPERBOLIC:
            # For hyperbolic: α(t) = α₀ / (1 + γt)
            # Half-life when 1/(1 + γ*t_half) = 0.5 ⇒ γ = 1/t_half
            decay_rate = 1.0 / self.half_life_hours
        
        else:
            raise ValueError(f"Unknown decay model: {self.model_type}")
        
        return DecayParameters(
            model_type=self.model_type,
            half_life_hours=self.half_life_hours,
            decay_rate=decay_rate,
            initial_alpha=self.initial_alpha,
            minimum_alpha=0.0
        )
    
    def calculate_decay(self, initial_alpha: Optional[float] = None,
                       time_hours: float = 0.0) -> float:
        """
        Calculate remaining alpha after specified time.
        
        Args:
            initial_alpha: Initial alpha value (uses model default if None)
            time_hours: Time elapsed in hours
            
        Returns:
            Remaining alpha value
        """
        if initial_alpha is None:
            initial_alpha = self.params.initial_alpha
        
        if time_hours <= 0:
            return initial_alpha
        
        if self.model_type == DecayModelType.EXPONENTIAL:
            # α(t) = α₀ * exp(-λt)
            remaining = initial_alpha * math.exp(-self.params.decay_rate * time_hours)
        
        elif self.model_type == DecayModelType.POWER_LAW:
            # α(t) = α₀ * (1 + t/τ)^{-β}
            # Using τ = t_half
            tau = self.params.half_life_hours
            remaining = initial_alpha * (1 + time_hours / tau) ** -self.params.decay_rate
        
        elif self.model_type == DecayModelType.LINEAR:
            # α(t) = α₀ * max(0, 1 - t/T)
            T = 1.0 / self.params.decay_rate
            remaining = initial_alpha * max(0.0, 1.0 - time_hours / T)
        
        elif self.model_type == DecayModelType.HYPERBOLIC:
            # α(t) = α₀ / (1 + γt)
            remaining = initial_alpha / (1 + self.params.decay_rate * time_hours)
        
        else:
            remaining = initial_alpha
        
        # Apply minimum alpha floor
        remaining = max(self.params.minimum_alpha, remaining)
        
        # Record decay
        self.decay_history.append({
            'timestamp': time_hours,
            'initial_alpha': initial_alpha,
            'remaining_alpha': remaining,
            'decay_percentage': (initial_alpha - remaining) / initial_alpha * 100
                              if initial_alpha > 0 else 0.0
        })
        
        return remaining
    
    def calculate_decay_curve(self, max_time_hours: float = 168.0, 
                            n_points: int = 100) -> Dict:
        """
        Calculate complete decay curve.
        
        Args:
            max_time_hours: Maximum time for curve
            n_points: Number of points in curve
            
        Returns:
            Decay curve data
        """
        time_points = np.linspace(0, max_time_hours, n_points)
        alpha_points = []
        
        for t in time_points:
            alpha = self.calculate_decay(time_hours=t)
            alpha_points.append(alpha)
        
        # Calculate useful metrics
        time_to_25pct = self._find_time_for_decay(0.25)
        time_to_10pct = self._find_time_for_decay(0.10)
        time_to_1pct = self._find_time_for_decay(0.01)
        
        return {
            'model_type': self.model_type.value,
            'time_hours': time_points.tolist(),
            'alpha_values': alpha_points,
            'half_life_hours': self.params.half_life_hours,
            'initial_alpha': self.params.initial_alpha,
            'time_to_25pct_hours': time_to_25pct,
            'time_to_10pct_hours': time_to_10pct,
            'time_to_1pct_hours': time_to_1pct,
            'effective_lifetime_hours': time_to_10pct,  # When alpha decays to 10%
            'decay_rate': self.params.decay_rate
        }
    
    def _find_time_for_decay(self, remaining_fraction: float) -> float:
        """Find time when alpha decays to specified fraction."""
        if remaining_fraction <= 0 or remaining_fraction >= 1:
            return 0.0
        
        if self.model_type == DecayModelType.EXPONENTIAL:
            # α(t) = α₀ * exp(-λt) = α₀ * fraction
            # ⇒ t = -ln(fraction)/λ
            t = -math.log(remaining_fraction) / self.params.decay_rate
        
        elif self.model_type == DecayModelType.POWER_LAW:
            # α(t) = α₀ * (1 + t/τ)^{-β} = α₀ * fraction
            # ⇒ t = τ * (fraction^{-1/β} - 1)
            tau = self.params.half_life_hours
            t = tau * (remaining_fraction ** (-1/self.params.decay_rate) - 1)
        
        elif self.model_type == DecayModelType.LINEAR:
            # α(t) = α₀ * (1 - t/T) = α₀ * fraction
            # ⇒ t = T * (1 - fraction)
            T = 1.0 / self.params.decay_rate
            t = T * (1 - remaining_fraction)
        
        elif self.model_type == DecayModelType.HYPERBOLIC:
            # α(t) = α₀ / (1 + γt) = α₀ * fraction
            # ⇒ t = (1/fraction - 1)/γ
            t = (1/remaining_fraction - 1) / self.params.decay_rate
        
        else:
            t = 0.0
        
        return max(0.0, t)
    
    def estimate_from_data(self, observations: List[Tuple[float, float]]) -> bool:
        """
        Estimate decay parameters from observed data.
        
        Args:
            observations: List of (time_hours, alpha_value) pairs
            
        Returns:
            True if estimation successful
        """
        if len(observations) < 5:
            return False
        
        times, alphas = zip(*observations)
        times = np.array(times)
        alphas = np.array(alphas)
        
        # Normalize alphas
        if alphas[0] == 0:
            return False
        
        normalized = alphas / alphas[0]
        
        try:
            if self.model_type == DecayModelType.EXPONENTIAL:
                # Fit: ln(α) = ln(α₀) - λt
                log_alphas = np.log(normalized)
                valid_mask = np.isfinite(log_alphas) & (normalized > 0)
                
                if np.sum(valid_mask) < 3:
                    return False
                
                # Linear regression
                coeffs = np.polyfit(times[valid_mask], log_alphas[valid_mask], 1)
                self.params.decay_rate = -coeffs[0]  # λ
                self.params.half_life_hours = math.log(2) / self.params.decay_rate
            
            elif self.model_type == DecayModelType.POWER_LAW:
                # Fit: ln(α) = ln(α₀) - β * ln(1 + t/τ)
                # For simplicity, assume τ = median time
                tau = np.median(times)
                transformed = np.log(1 + times / tau)
                log_alphas = np.log(normalized)
                
                valid_mask = np.isfinite(log_alphas) & (normalized > 0)
                
                if np.sum(valid_mask) < 3:
                    return False
                
                coeffs = np.polyfit(transformed[valid_mask], log_alphas[valid_mask], 1)
                self.params.decay_rate = -coeffs[0]  # β
            
            # Update initial alpha to match first observation
            self.params.initial_alpha = alphas[0]
            
            # Record fit
            self.model_fit_history.append(self.params.copy())
            
            return True
        
        except Exception as e:
            print(f"Decay model estimation failed: {e}")
            return False
    
    def calculate_decay_cost(self, initial_alpha: float, latency_hours: float,
                           trade_size: float, price: float) -> Dict:
        """
        Calculate monetary cost of alpha decay due to latency.
        
        Args:
            initial_alpha: Initial alpha in bps
            latency_hours: Execution latency in hours
            trade_size: Trade size in base units
            price: Asset price
            
        Returns:
            Decay cost analysis
        """
        # Calculate remaining alpha
        remaining_alpha = self.calculate_decay(initial_alpha, latency_hours)
        decayed_alpha = initial_alpha - remaining_alpha
        
        # Calculate monetary value
        trade_value = trade_size * price
        decay_cost_bps = decayed_alpha
        decay_cost_dollars = decay_cost_bps / 10000 * trade_value  # bps to percentage
        
        # Opportunity cost (if we had executed instantly)
        instant_value = initial_alpha / 10000 * trade_value
        delayed_value = remaining_alpha / 10000 * trade_value
        opportunity_cost = instant_value - delayed_value
        
        return {
            'initial_alpha_bps': initial_alpha,
            'remaining_alpha_bps': remaining_alpha,
            'decayed_alpha_bps': decayed_alpha,
            'decay_percentage': decayed_alpha / initial_alpha * 100 
                              if initial_alpha > 0 else 0.0,
            'latency_hours': latency_hours,
            'trade_value_usd': trade_value,
            'decay_cost_bps': decay_cost_bps,
            'decay_cost_usd': decay_cost_dollars,
            'opportunity_cost_usd': opportunity_cost,
            'half_life_used': self.params.half_life_hours,
            'model_type': self.model_type.value,
            'cost_as_percent_of_trade': decay_cost_dollars / trade_value * 100 
                                       if trade_value > 0 else 0.0
        }
    
    def get_model_statistics(self) -> Dict:
        """Get comprehensive model statistics."""
        if not self.decay_history:
            return {}
        
        decay_percentages = [d['decay_percentage'] for d in self.decay_history]
        latencies = [d['timestamp'] for d in self.decay_history]
        
        return {
            'model_type': self.model_type.value,
            'parameters': {
                'half_life_hours': self.params.half_life_hours,
                'decay_rate': self.params.decay_rate,
                'initial_alpha': self.params.initial_alpha,
                'minimum_alpha': self.params.minimum_alpha
            },
            'statistics': {
                'n_observations': len(self.decay_history),
                'avg_decay_percentage': np.mean(decay_percentages) 
                                       if decay_percentages else 0.0,
                'max_decay_percentage': max(decay_percentages) 
                                       if decay_percentages else 0.0,
                'avg_latency_hours': np.mean(latencies) if latencies else 0.0,
                'model_fits': len(self.model_fit_history)
            },
            'decay_curve': self.calculate_decay_curve(max_time_hours=self.params.half_life_hours * 4),
            'performance_implications': self._calculate_performance_implications()
        }
    
    def _calculate_performance_implications(self) -> Dict:
        """Calculate performance implications of decay."""
        # Calculate effective trading window
        effective_window = self._find_time_for_decay(0.1)  # Time to 10% alpha
        
        # Calculate maximum acceptable latency
        max_latency_25pct = self._find_time_for_decay(0.75)  # Time losing 25% alpha
        max_latency_50pct = self._find_time_for_decay(0.50)  # Time losing 50% alpha
        
        return {
            'effective_trading_window_hours': effective_window,
            'max_latency_25pct_loss_hours': max_latency_25pct,
            'max_latency_50pct_loss_hours': max_latency_50pct,
            'recommended_max_latency_hours': min(max_latency_25pct, 1.0),  # Conservative
            'trading_frequency_hours': effective_window / 2,  # Trade at half of effective window
            'urgency_level': 'HIGH' if self.params.half_life_hours < 1.0 else
                           'MEDIUM' if self.params.half_life_hours < 12.0 else
                           'LOW'
        }