"""
Toxicity and adverse selection modeling v4.0.
Implements VPIN and Toxic Flow metrics.
"""

import numpy as np
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass
from collections import deque
import pandas as pd


@dataclass
class TradeBar:
    """Aggregated trade information for volume bars."""
    start_time: float
    end_time: float
    total_volume: float
    buy_volume: float
    sell_volume: float
    vpin: float = 0.0
    
    @property
    def volume_imbalance(self) -> float:
        """Volume imbalance (|buy - sell|)."""
        return abs(self.buy_volume - self.sell_volume)
    
    @property
    def toxic_ratio(self) -> float:
        """Toxic flow ratio."""
        if self.total_volume == 0:
            return 0.0
        return self.volume_imbalance / self.total_volume


class VPINCalculator:
    """
    Volume-synchronized Probability of Informed Trading (VPIN) calculator.
    
    Based on: Easley, D., et al. (2012) "Flow toxicity and liquidity 
    in a high-frequency world."
    """
    
    def __init__(self, volume_bars: int = 50, window_size: int = 100):
        """
        Args:
            volume_bars: Number of volume bars for VPIN calculation
            window_size: Rolling window size for VPIN smoothing
        """
        self.volume_bars = volume_bars
        self.window_size = window_size
        
        # Storage
        self.trade_history = []  # List of (timestamp, price, volume, side)
        self.volume_bars_history = deque(maxlen=volume_bars * 10)
        self.vpin_history = []
        
    def add_trade(self, timestamp: float, price: float, 
                 volume: float, side: str):
        """Add a trade to the calculator."""
        self.trade_history.append({
'timestamp': timestamp,
            'price': price,
            'volume': volume,
            'side': side  # 'buy' or 'sell'
        })
        
        # Update volume bars
        self._update_volume_bars()
        
    def _update_volume_bars(self):
        """Update volume bars based on accumulated trades."""
        if len(self.trade_history) < 10:  # Minimum trades
            return
        
        # Sort trades by time
        trades = sorted(self.trade_history, key=lambda x: x['timestamp'])
        
        # Create volume bars
        current_bar = None
        bars = []
        
        target_volume = sum(t['volume'] for t in trades) / self.volume_bars
        
        for trade in trades:
            if current_bar is None:
                current_bar = TradeBar(
                    start_time=trade['timestamp'],
                    end_time=trade['timestamp'],
                    total_volume=0,
                    buy_volume=0,
                    sell_volume=0
                )
            
            # Add trade to current bar
            current_bar.total_volume += trade['volume']
            current_bar.end_time = trade['timestamp']
            
            if trade['side'] == 'buy':
                current_bar.buy_volume += trade['volume']
            else:
                current_bar.sell_volume += trade['volume']
            
            # Check if bar is complete
            if current_bar.total_volume >= target_volume:
                # Calculate VPIN for this bar
                current_bar.vpin = current_bar.toxic_ratio
                bars.append(current_bar)
                current_bar = None
        
        # Update history
        if bars:
            self.volume_bars_history.extend(bars)
            self._calculate_vpin()
            
            # Clear processed trades
            last_timestamp = bars[-1].end_time
            self.trade_history = [
                t for t in self.trade_history 
                if t['timestamp'] > last_timestamp
            ]
    
    def _calculate_vpin(self):
        """Calculate VPIN from volume bars."""
        if len(self.volume_bars_history) < self.volume_bars:
            return
        
        # Get recent bars
        recent_bars = list(self.volume_bars_history)[-self.volume_bars:]
        
        # Calculate VPIN
        total_volume = sum(b.total_volume for b in recent_bars)
        if total_volume == 0:
            vpin = 0.0
        else:
            imbalance_sum = sum(b.volume_imbalance for b in recent_bars)
            vpin = imbalance_sum / total_volume
        
        self.vpin_history.append(vpin)
        
        return vpin
    
    def get_current_vpin(self, smoothed: bool = True) -> float:
        """Get current VPIN value."""
        if not self.vpin_history:
            return 0.0
        
        if smoothed and len(self.vpin_history) >= self.window_size:
            recent = self.vpin_history[-self.window_size:]
            return np.mean(recent)
        
        return self.vpin_history[-1]
    
    def get_toxic_flow_metrics(self) -> Dict:
        """Get comprehensive toxicity metrics."""
        if not self.volume_bars_history:
            return {}
        
        recent_bars = list(self.volume_bars_history)[-self.volume_bars:]
        
        toxic_ratios = [b.toxic_ratio for b in recent_bars]
        volume_imbalances = [b.volume_imbalance for b in recent_bars]
        
        return {
            'vpin': self.get_current_vpin(),
            'vpin_smoothed': self.get_current_vpin(smoothed=True),
            'avg_toxic_ratio': np.mean(toxic_ratios) if toxic_ratios else 0.0,
            'std_toxic_ratio': np.std(toxic_ratios) if len(toxic_ratios) > 1 else 0.0,
            'max_toxic_ratio': max(toxic_ratios) if toxic_ratios else 0.0,
            'volume_imbalance_mean': np.mean(volume_imbalances) if volume_imbalances else 0.0,
            'buy_volume_ratio': sum(b.buy_volume for b in recent_bars) / 
                               sum(b.total_volume for b in recent_bars)
if sum(b.total_volume for b in recent_bars) > 0 else 0.5,
            'n_bars': len(recent_bars),
            'toxicity_level': self._classify_toxicity()
        }
    
    def _classify_toxicity(self) -> str:
        """Classify current toxicity level."""
        vpin = self.get_current_vpin()
        
        if vpin < 0.1:
            return 'LOW'
        elif vpin < 0.25:
            return 'MODERATE'
        elif vpin < 0.4:
            return 'HIGH'
        else:
            return 'EXTREME'
    
    def predict_adverse_selection(self, order_size: float, 
                                 side: str) -> Dict:
        """
        Predict adverse selection impact for an order.
        
        Args:
            order_size: Order size in base currency
            side: 'buy' or 'sell'
            
        Returns:
            Adverse selection prediction metrics
        """
        vpin = self.get_current_vpin()
        
        # Base adverse selection probability
        base_prob = vpin * 0.8  # Scale VPIN to probability
        
        # Adjust for order size
        if order_size > 10000:  # Large order threshold
            size_factor = 1.5
        elif order_size > 1000:
            size_factor = 1.2
        else:
            size_factor = 1.0
        
        adverse_prob = min(0.95, base_prob * size_factor)
        
        # Expected impact (bps)
        base_impact = vpin * 10  # 10 bps per 1.0 VPIN
        expected_impact_bps = base_impact * size_factor
        
        return {
            'adverse_selection_probability': adverse_prob,
            'expected_impact_bps': expected_impact_bps,
            'vpin_contribution': vpin,
            'size_multiplier': size_factor,
            'recommendation': 'REJECT' if adverse_prob > 0.7 else 
                             'REDUCE_SIZE' if adverse_prob > 0.4 else 
                             'PROCEED'
        }
