"""
Small capital ($100) strategy for cheap altcoins.
Optimized for Bybit and small accounts.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
import warnings
warnings.filterwarnings('ignore')


@dataclass
class SmallCapStrategyConfig:
    """Configuration for small capital strategy."""
    # Capital management
    initial_capital: float = 100.0
    max_position_size_pct: float = 0.2  # 20% per trade
    max_open_positions: int = 3
    stop_loss_pct: float = 0.05  # 5% stop loss
    take_profit_pct: float = 0.10  # 10% take profit
    
    # Signal parameters
    rsi_period: int = 14
    rsi_overbought: float = 70.0
    rsi_oversold: float = 30.0
    
    bb_period: int = 20
    bb_std: float = 2.0
    
    ma_short: int = 9
    ma_long: int = 21
    
    volume_multiplier: float = 1.5  # Volume spike threshold
    
    # Risk management
    max_daily_loss_pct: float = 0.03  # 3% max daily loss
    cooldown_periods: int = 5  # Periods to wait after stop loss
    
    # Bybit-specific
    min_order_size: float = 1.0  # $1 minimum on Bybit
    maker_fee: float = 0.0001  # 0.01%
    taker_fee: float = 0.0006  # 0.06%


class SmallCapStrategy:
    """
    Strategy optimized for small capital on cheap altcoins.
    Uses RSI, Bollinger Bands, and volume analysis.
    """
    
    def __init__(self, config: Optional[SmallCapStrategyConfig] = None):
        self.config = config or SmallCapStrategyConfig()
        self.positions = {}
        self.trade_history = []
        self.daily_pnl = 0.0
        self.current_day = None
        self.cooldown = {}  # symbol -> periods remaining
        
    def calculate_signals(self, df: pd.DataFrame, symbol: str) -> Dict:
        """
        Calculate trading signals for a symbol.
        
        Returns:
            Dict with signals and metadata
        """
        if len(df) < 50:  # Need enough data
            return {'action': 'HOLD', 'confidence': 0.0}
        
        # Get latest data
        latest = df.iloc[-1]
        prev = df.iloc[-2]
        
        # Calculate indicators
        df = self._calculate_indicators(df)
        
        # Get indicator values
        rsi = df['rsi'].iloc[-1]
        bb_upper = df['bb_upper'].iloc[-1]
        bb_lower = df['bb_lower'].iloc[-1]
        bb_width = (bb_upper - bb_lower) / df['bb_middle'].iloc[-1]
        ma_short = df['ma_short'].iloc[-1]
        ma_long = df['ma_long'].iloc[-1]
        volume_avg = df['volume'].rolling(20).mean().iloc[-1]
        volume_ratio = latest['volume'] / volume_avg if volume_avg > 0 else 1.0
        
        # Check cooldown
        if symbol in self.cooldown and self.cooldown[symbol] > 0:
            self.cooldown[symbol] -= 1
            if self.cooldown[symbol] <= 0:
                del self.cooldown[symbol]
            else:
                return {'action': 'HOLD', 'reason': 'Cooldown'}
        
        # Generate signals
        signals = []
        confidences = []
        
        # Signal 1: RSI oversold with volume spike
        if (rsi < self.config.rsi_oversold and 
            volume_ratio > self.config.volume_multiplier and
            latest['close'] < bb_lower):
            signals.append('BUY')
            confidence = min(0.9, 
                           (self.config.rsi_oversold - rsi) / 20 * 0.5 +
                           min(1.0, (volume_ratio - 1) / 2) * 0.3 +
                           (bb_lower - latest['close']) / bb_lower * 2)
            confidences.append(confidence)
        
        # Signal 2: Golden cross (short MA crosses above long MA)
        if (ma_short > ma_long and 
            prev['ma_short'] <= prev['ma_long'] and
            volume_ratio > 1.2):
            signals.append('BUY')
            confidence = min(0.8, 
                           (ma_short - ma_long) / ma_long * 10 +
                           min(1.0, (volume_ratio - 1) / 2) * 0.2)
            confidences.append(confidence)
        
        # Signal 3: RSI overbought
        if (rsi > self.config.rsi_overbought and
            latest['close'] > bb_upper and
            symbol in self.positions):  # Only sell if we have position
            signals.append('SELL')
            confidence = min(0.9,
                           (rsi - self.config.rsi_overbought) / 20 * 0.6 +
                           (latest['close'] - bb_upper) / bb_upper * 2)
            confidences.append(confidence)
        
        # Signal 4: Death cross (short MA crosses below long MA)
        if (ma_short < ma_long and
            prev['ma_short'] >= prev['ma_long'] and
            symbol in self.positions):
            signals.append('SELL')
            confidence = min(0.7,
                           (ma_long - ma_short) / ma_long * 10)
            confidences.append(confidence)
        
        # Determine final action
        if not signals:
            return {'action': 'HOLD', 'confidence': 0.0}
        
        # Check if we have conflicting signals
        if 'BUY' in signals and 'SELL' in signals:
            # Take the higher confidence signal
            buy_conf = max([c for s, c in zip(signals, confidences) if s == 'BUY'], default=0)
            sell_conf = max([c for s, c in zip(signals, confidences) if s == 'SELL'], default=0)
            
            if buy_conf > sell_conf:
                action = 'BUY'
                confidence = buy_conf
            else:
                action = 'SELL'
                confidence = sell_conf
        else:
            action = signals[0]
            confidence = confidences[0]
        
        # Adjust position size based on confidence and volatility
        volatility = bb_width
        position_size_pct = min(
            self.config.max_position_size_pct,
            self.config.max_position_size_pct * confidence * (1 - min(1.0, volatility * 10))
        )
        
        # Check if we can open new position
        if action == 'BUY' and len(self.positions) >= self.config.max_open_positions:
            return {'action': 'HOLD', 'reason': 'Max positions reached'}
        
        return {
            'action': action,
            'confidence': confidence,
            'symbol': symbol,
            'price': latest['close'],
            'rsi': rsi,
            'bb_upper': bb_upper,
            'bb_lower': bb_lower,
            'ma_short': ma_short,
            'ma_long': ma_long,
            'volume_ratio': volume_ratio,
            'volatility': volatility,
            'position_size_pct': position_size_pct,
            'stop_loss': latest['close'] * (1 - self.config.stop_loss_pct) 
                         if action == 'BUY' else None,
            'take_profit': latest['close'] * (1 + self.config.take_profit_pct) 
                          if action == 'BUY' else None
        }
    
    def _calculate_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        """Calculate technical indicators."""
        # RSI
        delta = df['close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=self.config.rsi_period).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=self.config.rsi_period).mean()
        rs = gain / loss
        df['rsi'] = 100 - (100 / (1 + rs))
        
        # Bollinger Bands
        df['bb_middle'] = df['close'].rolling(window=self.config.bb_period).mean()
        bb_std = df['close'].rolling(window=self.config.bb_period).std()
        df['bb_upper'] = df['bb_middle'] + (bb_std * self.config.bb_std)
        df['bb_lower'] = df['bb_middle'] - (bb_std * self.config.bb_std)
        
        # Moving averages
        df['ma_short'] = df['close'].rolling(window=self.config.ma_short).mean()
        df['ma_long'] = df['close'].rolling(window=self.config.ma_long).mean()
        
        return df
    
    def execute_trade(self, signal: Dict, portfolio_value: float) -> Optional[Dict]:
        """
        Execute a trade based on signal.
        
        Returns:
            Trade execution details or None
        """
        if signal['action'] == 'HOLD':
            return None
        
        symbol = signal['symbol']
        price = signal['price']
        action = signal['action']
        
        # Calculate position size
        position_value = portfolio_value * signal['position_size_pct']
        
        # Check minimum order size
        if position_value < self.config.min_order_size:
            return None
        
        # Check if we already have a position
        if action == 'BUY' and symbol in self.positions:
            return None  # Already have position
        
        if action == 'SELL' and symbol not in self.positions:
            return None  # No position to sell
        
        # Execute trade
        trade = {
            'timestamp': pd.Timestamp.now(),
            'symbol': symbol,
            'action': action,
            'price': price,
            'size_usd': position_value,
            'confidence': signal['confidence'],
            'stop_loss': signal.get('stop_loss'),
            'take_profit': signal.get('take_profit'),
            'indicators': {
                'rsi': signal.get('rsi'),
                'bb_width': signal.get('volatility'),
                'volume_ratio': signal.get('volume_ratio')
            }
        }
        
        # Update positions
        if action == 'BUY':
            self.positions[symbol] = {
                'entry_price': price,
                'entry_time': pd.Timestamp.now(),
                'size_usd': position_value,
                'stop_loss': signal['stop_loss'],
                'take_profit': signal['take_profit']
            }
        elif action == 'SELL' and symbol in self.positions:
            position = self.positions.pop(symbol)
            trade['pnl'] = position_value - position['size_usd']
            trade['pnl_pct'] = (price - position['entry_price']) / position['entry_price']
            
            # Check if stopped out
            if price <= position['stop_loss'] * 0.99:  # Slightly below stop loss
                trade['exit_reason'] = 'STOP_LOSS'
                # Add to cooldown
                self.cooldown[symbol] = self.config.cooldown_periods
            elif price >= position['take_profit'] * 0.99:  # Slightly above take profit
                trade['exit_reason'] = 'TAKE_PROFIT'
            else:
                trade['exit_reason'] = 'SIGNAL'
        
        self.trade_history.append(trade)
        return trade
    
    def check_stop_losses(self, current_prices: Dict[str, float]) -> List[Dict]:
        """
        Check stop losses for all positions.
        
        Returns:
            List of triggered stop loss trades
        """
        triggered = []
        
        for symbol, position in list(self.positions.items()):
            if symbol in current_prices:
                current_price = current_prices[symbol]
                
                # Check stop loss
                if current_price <= position['stop_loss']:
                    # Trigger stop loss
                    trade = {
                        'timestamp': pd.Timestamp.now(),
                        'symbol': symbol,
                        'action': 'SELL',
                        'price': current_price,
                        'size_usd': position['size_usd'],
                        'pnl': position['size_usd'] * (current_price - position['entry_price']) / position['entry_price'],
                        'pnl_pct': (current_price - position['entry_price']) / position['entry_price'],
                        'exit_reason': 'STOP_LOSS',
                        'indicators': {'forced_exit': True}
                    }
                    
                    triggered.append(trade)
                    self.trade_history.append(trade)
                    del self.positions[symbol]
                    
                    # Add to cooldown
                    self.cooldown[symbol] = self.config.cooldown_periods
        
        return triggered
    
    def get_portfolio_summary(self, current_prices: Dict[str, float]) -> Dict:
        """Get current portfolio summary."""
        total_value = 0.0
        open_positions = []
        
        for symbol, position in self.positions.items():
            if symbol in current_prices:
                current_value = position['size_usd'] * current_prices[symbol] / position['entry_price']
                total_value += current_value
                
                open_positions.append({
                    'symbol': symbol,
                    'entry_price': position['entry_price'],
                    'current_price': current_prices[symbol],
                    'size_usd': position['size_usd'],
                    'current_value': current_value,
                    'pnl_pct': (current_prices[symbol] - position['entry_price']) / position['entry_price'],
                    'pnl_usd': current_value - position['size_usd'],
                    'stop_loss': position['stop_loss'],
                    'take_profit': position['take_profit']
                })
        
        # Calculate total PnL from trade history
        total_pnl = sum(t.get('pnl', 0) for t in self.trade_history)
        
        return {
            'total_value': total_value,
            'open_positions': open_positions,
            'n_open_positions': len(open_positions),
            'total_pnl': total_pnl,
            'total_trades': len(self.trade_history),
            'winning_trades': sum(1 for t in self.trade_history if t.get('pnl', 0) > 0),
            'losing_trades': sum(1 for t in self.trade_history if t.get('pnl', 0) < 0),
            'cooldown_symbols': list(self.cooldown.keys())
        }