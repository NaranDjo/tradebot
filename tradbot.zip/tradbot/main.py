# main.py
"""
Main entry point for v4.0 system.
Simplified version without problematic imports.
"""

import pandas as pd
import numpy as np
from datetime import datetime

# Импортируем из simulation
from simulation.latency_aware_backtest import LatencyAwareBacktest


def load_historical_data():
    """Load sample historical data."""
    print("📊 Generating synthetic historical data...")
    
    # Используем 'h' вместо 'H' для часовой частоты
    dates = pd.date_range(start='2024-01-01', end='2024-01-31', freq='h')
    
    # Для большей реалистичности создаем тренд + шум
    n_points = len(dates)
    trend = np.linspace(100, 110, n_points)  # Восходящий тренд
    noise = np.random.normal(0, 2, n_points)
    
    data = pd.DataFrame({
        'timestamp': dates,
        'open': trend + noise,
        'high': trend + noise + np.random.uniform(1, 3, n_points),
        'low': trend + noise - np.random.uniform(1, 3, n_points),
        'close': trend + noise + np.random.normal(0, 0.5, n_points),
        'volume': np.random.randint(1000, 10000, n_points),
        'symbol': 'AAPL'
    })
    
    print(f"✅ Generated {len(data)} data points (hourly from {dates[0]} to {dates[-1]})")
    return data


class MyTradingStrategy:
    """Example trading strategy."""
    def __init__(self):
        self.name = "Sample Trend Strategy"
    
    def generate_signals(self, data):
        """Generate trading signals based on simple trend."""
        print("🤖 Generating trading signals...")
        signals = []
        
        # Используем скользящие средние для сигналов
        short_ma = data['close'].rolling(window=10).mean()
        long_ma = data['close'].rolling(window=30).mean()
        
        for i in range(30, len(data)):  # Начинаем с 30-го элемента для расчета MA
            # Сигнал на покупку: короткая MA пересекает длинную снизу вверх
            if short_ma.iloc[i-1] < long_ma.iloc[i-1] and short_ma.iloc[i] > long_ma.iloc[i]:
                signals.append({
                    'action': 'BUY', 
                    'timestamp': data.iloc[i]['timestamp'],
                    'symbol': 'AAPL',
                    'price': data['close'].iloc[i],
                    'size': 100  # Buy 100 shares
                })
            # Сигнал на продажу: короткая MA пересекает длинную сверху вниз
            elif short_ma.iloc[i-1] > long_ma.iloc[i-1] and short_ma.iloc[i] < long_ma.iloc[i]:
                signals.append({
                    'action': 'SELL',
                    'timestamp': data.iloc[i]['timestamp'],
                    'symbol': 'AAPL',
                    'price': data['close'].iloc[i],
                    'size': 50  # Sell 50 shares
                })
        
        print(f"✅ Generated {len(signals)} trading signals")
        return signals


def main():
    """Run the v4.0 system."""
    print("=" * 60)
    print("Institutional Algorithmic Trading System v4.0")
    print("Latency-Aware Execution with Adverse Selection Modeling")
    print("=" * 60)
    
    # 1. Load historical data
    data = load_historical_data()
    
    # 2. Define trading strategy
    strategy = MyTradingStrategy()
    
    # 3. Run backtests with different latency scenarios
    print("\n⚡️ Running latency-aware backtests...")
    
    scenarios = [
        ('Optimal', 'optimal'),
        ('Realistic', 'realistic'),
        ('Degraded', 'degraded')
    ]
    
    all_results = {}
    
    for scenario_name, scenario_type in scenarios:
        print(f"\n--- Testing {scenario_name} Scenario ---")
        
        # Initialize backtest engine
        backtest = LatencyAwareBacktest(
            initial_capital=1000000,
            latency_scenario=scenario_type
        )
        
        # Run backtest
        try:
            results = backtest.run(
                data=data,
                strategy=strategy,
                symbols=['AAPL']
            )
            all_results[scenario_name] = results
            print(f"✅ {scenario_name} backtest completed")
            
            # Extract metrics
            metrics = results.get('metrics', {})
            pnl = metrics.get('total_pnl', 0)
            sharpe = metrics.get('sharpe_ratio', 0)
            adverse_cost = metrics.get('adverse_selection_cost', 0)
            
            print(f"   PnL: ${pnl:.2f}")
            print(f"   Sharpe: {sharpe:.2f}")
            print(f"   Adverse Selection Cost: ${adverse_cost:.2f}")
            
        except Exception as e:
            print(f"❌ Error in {scenario_name} scenario: {e}")
            import traceback
            traceback.print_exc()
    
    # 4. Compare results
    print("\n" + "=" * 60)
    print("📈 SCENARIO COMPARISON SUMMARY")
    print("=" * 60)
    
    if not all_results:
        print("No results to display. Check for errors above.")
        return
    
    print(f"\n{'Scenario':<12} {'PnL':<12} {'Sharpe':<10} {'Max DD':<10} {'Adverse Cost':<15}")
    print("-" * 60)
    
    for scenario_name, results in all_results.items():
        metrics = results.get('metrics', {})
        pnl = metrics.get('total_pnl', 0)
        sharpe = metrics.get('sharpe_ratio', 0)
        max_dd = metrics.get('max_drawdown', 0) * 100
        adverse_cost = metrics.get('adverse_selection_cost', 0)
        
        print(f"{scenario_name:<12} ${pnl:<11.2f} {sharpe:<10.2f} {max_dd:<10.1f}% ${adverse_cost:<14.2f}")
    
    # 5. Find best scenario
    if all_results:
        best_scenario = max(all_results.items(), 
                           key=lambda x: x[1].get('metrics', {}).get('total_pnl', -float('inf')))
        
        print(f"\n🏆 Best performing scenario: {best_scenario[0]}")
        print(f"   PnL: ${best_scenario[1].get('metrics', {}).get('total_pnl', 0):.2f}")
    
    # 6. Show key insights
    print("\n" + "=" * 60)
    print("💡 KEY INSIGHTS")
    print("=" * 60)
    
    for scenario_name, results in all_results.items():
        if 'latency_analysis' in results:
            analysis = results['latency_analysis']
            print(f"\n{scenario_name}:")
            
            for latency_level, stats in analysis.items():
                n_trades = stats.get('n_trades', 0)
                if n_trades > 0:
                    avg_loss = stats.get('avg_adverse_loss_bps', 0)
                    print(f"  {latency_level} latency trades: {n_trades}, Avg loss: {avg_loss:.2f} bps")
    
    # 7. Recommendations
    print("\n" + "=" * 60)
    print("🎯 OPTIMIZATION RECOMMENDATIONS")
    print("=" * 60)
    
    for scenario_name, results in all_results.items():
        if 'recommendations' in results and results['recommendations']:
            print(f"\n{scenario_name}:")
            for i, rec in enumerate(results['recommendations'], 1):
                print(f"  {i}. {rec}")


if __name__ == "__main__":
    main()
    input("\nНажмите Enter, чтобы выйти...")